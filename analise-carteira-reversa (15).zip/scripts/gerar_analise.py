# -*- coding: utf-8 -*-
"""Uso: python3 gerar_analise.py ENTRADA.xlsx [ENTRADA2.xlsx ...] --saida Carteira_Reversa.xlsx [--data 15/10/2026]"""
import argparse
import datetime as dt
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from calculo import parse_clientes, processar          # noqa: E402
from modelo_painel import montar_excel  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("entradas", nargs="+")
    ap.add_argument("--saida", default="Carteira_Reversa.xlsx")
    ap.add_argument("--rede", default="TODAS", help="rede inicial do painel")
    ap.add_argument("--aviso", default=None, help="texto de aviso no topo do painel")
    ap.add_argument("--data", default=None, help="data de referência dd/mm/aaaa (padrão: hoje)")
    ap.add_argument("--clientes", default=None, help='tabela de clientes e tipo: "BARBOSA=VD;SHIBATA=CD;CD SHIBATA=VD"')
    a = ap.parse_args()
    ref = dt.datetime.strptime(a.data, "%d/%m/%Y").date() if a.data else dt.date.today()
    res = processar(a.entradas, ref, config=dict(clientes=parse_clientes(a.clientes) or None))
    montar_excel(res, a.saida, rede_padrao=a.rede, loja_padrao=(a.rede if a.rede != 'TODAS' else None), aviso_modelo=a.aviso)
    falhas = [c for c in res["conferencias"] if not c[1]]
    print(f"{res['n_chaves']} chaves · {len(res['fora_carteira'])} marcações fora da carteira · "
          f"{len(falhas)} conferências com alerta · avisos: {len(res['avisos'])}")
    return res


if __name__ == "__main__":
    main()
