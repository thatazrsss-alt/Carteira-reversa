# -*- coding: utf-8 -*-
"""Gera um arquivo de ENTRADA fictício (todas as abas, nas colunas combinadas) para testar a análise.
Todos os números são inventados."""
import datetime as dt
import random
import sys

import openpyxl
from openpyxl.utils import column_index_from_string as ci

REF = dt.date(2026, 10, 15)


def put(row, letra, val):
    i = ci(letra) - 1
    while len(row) <= i:
        row.append(None)
    row[i] = val


def gerar(saida, seed=7):
    rnd = random.Random(seed)
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    # --------- SKUs (CAD): A=S4, C=EG, I=CX por PLT
    skus = []
    nomes = ["LATA 350ML C/12", "LATA 269ML C/15", "PET 2L C/6", "PET 600ML C/12", "LONG NECK 355ML C/24",
             "RETORNAVEL 600ML C/24", "LATA 473ML C/12", "PET 1,5L C/6", "AGUA 500ML C/12", "ENERGETICO 269ML C/12",
             "CHA 450ML C/12", "ISOTONICO 500ML C/12"]
    fatores = [100, 84, 60, 72, 90, 48, 90, 80, 120, 112, 96, 108]
    for i, (n, f) in enumerate(zip(nomes, fatores)):
        eg = f"{24100 + i * 7}{i % 10}"
        skus.append(dict(eg=eg, s4=f"S4{3000 + i}", sap=f"{70000 + i}", nome=n, f=f))
    ws = wb.create_sheet("CAD")
    ws.append(["Cod S4", "Cod_SAP", "Cód_Prod", "cod_prod_sku_s_dv", "cod_dv_prod_sku", "EAN13_SKU", "EAN13_Unitario", "dsc_produto_sku", "Quantidade_prod_pallet"])
    for s in skus:
        r = []
        put(r, "A", s["s4"]); put(r, "B", s["sap"]); put(r, "C", s["eg"]); put(r, "H", s["nome"]); put(r, "I", s["f"])
        ws.append(r)

    # --------- clientes
    clientes = []   # eg, sap, nome, rede, comercial
    def cli(eg, nome, rede, com="SP1"):
        clientes.append(dict(eg=eg, sap=f"1{eg}", nome=nome, rede=rede, com=com))
    cli("500101", "CD SONDA", "SONDA"); cli("500102", "CD NAGUMO", "NAGUMO"); cli("500103", "CD LOPES", "LOPES", "SP2")
    cli("500104", "CD BARBOSA", "BARBOSA", "SP2"); cli("500105", "CD SHIBATA", "SHIBATA")
    for i in range(1, 9):
        cli(f"5002{i:02d}", f"SHIBATA LJ {i:02d}", "SHIBATA")
    for i in range(1, 5):
        cli(f"5003{i:02d}", f"SK SUPERMERCADOS LJ {i:02d}", "SK", "SP2")
    for i in range(1, 4):
        cli(f"5004{i:02d}", f"OSVALDO LJ {i:02d}", "OSVALDO")
    for i in range(1, 4):
        cli(f"5005{i:02d}", f"NAGUMO LJ {i:02d}", "NAGUMO")

    # --------- Sheet3 (EG -> rede)
    ws = wb.create_sheet("Sheet3")
    ws.append(["Cliente EG", "Rede"])
    for c in clientes:
        ws.append([c["eg"], c["rede"]])

    # --------- DeParaCDD
    cdds = ["Louveira", "Diadema", "Guarulhos"]
    ws = wb.create_sheet("DeParaCDD")
    ws.append(["Cliente EG", "CDD"])
    for c in clientes:
        if c["rede"] in ("SHIBATA", "SK") and c["nome"] != "CD SHIBATA":
            ws.append([c["eg"], cdds[int(c["eg"][-1]) % 3]])

    # --------- Malha (SKU SAP, Destino Comercial, Origem, Nome fábrica)
    ws = wb.create_sheet("Malha")
    ws.append(["Nº Malha", "Data", "SKU SAP", "Descrição SKU SAP", "Fábrica Origem SAP", "Nome Fábrica Origem SAP", "Destino Comercial", "Quantidade", "Unidade"])
    origens = {"BR15": "F. Jundiai", "BR16": "F. Jacarei", "BR23": "F. Jaguariuna"}
    def mrow(s, com, org, nome):
        return [61010004000 + ws.max_row, REF, s["s4"], s["nome"], org, nome, com, 1000, "HL"]
    for i, s in enumerate(skus):
        for com in ("SP1", "SP2"):
            if i == 10 and com == "SP2":
                continue                       # sem malha
            if i == 11:
                ws.append(mrow(s, com, "nan (BR16)", None))   # origem inválida
            elif i in (2, 3, 4):
                ws.append(mrow(s, com, "BR15", origens["BR15"]))
                ws.append(mrow(s, com, "BR16", origens["BR16"]))   # duas origens
            else:
                o = ["BR15", "BR16", "BR23"][(i + (1 if com == "SP2" else 0)) % 3]
                ws.append(mrow(s, com, origens[o] if i % 2 else o, origens[o]))

    # --------- Estoque Fabricas (cabeçalhos reais; D1 em paletes)
    ws = wb.create_sheet("Estoque Fabricas")
    ws.append(["Orig. S4", "Orig. ECC", "Orig. PCA", "Fábrica", "Sku S4", "Sku ECC", "Sku PCA", "Descr. Abreviada", "Atributo", "D0", "D1", "D2"])
    centro = {"BR15": "892", "BR16": "260", "BR23": "952"}
    for o in origens:
        for s in skus:
            r = rnd.random()
            if r < 0.12:
                d1 = 0
            elif r < 0.32:
                d1 = rnd.uniform(1, 45)                 # crítico (<50 PLT)
            else:
                d1 = rnd.uniform(60, 400)
            ws.append([o, o, centro[o], origens[o], s["s4"], s["sap"], s["eg"], s["nome"], "Estoque Final", d1, d1, d1])

    # --------- Estoque CDD <cidade>
    for c in cdds:
        ws = wb.create_sheet(f"Estoque CDD {c}")
        ws.append(["Código do Produto", "Descrição", "SaldoDisponivel"])
        for s in skus:
            r = rnd.random()
            saldo = 0 if r < 0.1 else (rnd.randint(5, 300) if r < 0.5 else rnd.randint(500, 6000))
            ws.append([s["eg"][:-1], s["nome"], saldo])

    # --------- Produção (cabeçalhos reais: origem por nome, COD_PROD = SKU EG)
    ws = wb.create_sheet("Produção")
    ws.append(["ORIGEM", "COD_PROD", "NOME_PROD", "PRODUÇÃO", "ATV x DESC"])
    for o in origens:
        for s in skus:
            r = rnd.random()
            if r < 0.5:
                ws.append([origens[o], s["eg"], s["nome"], REF + dt.timedelta(days=rnd.randint(1, 12)), "Ativo"])
            elif r < 0.6:
                ws.append([origens[o], s["eg"], s["nome"], "Sem Previsão", "Ativo"])
            elif r < 0.68:
                ws.append([origens[o], s["eg"], s["nome"], REF + dt.timedelta(days=rnd.randint(1, 12)), "Descontinuado"])
            elif r < 0.78:
                ws.append([origens[o], s["eg"], s["nome"], REF + dt.timedelta(days=60), "Ativo"])

    # --------- Base Crua e Marcado
    cab_base = {}
    ws = wb.create_sheet("Base Crua")
    head = []
    for l, n in dict(B="Pedido ERP", G="Comercial", L="Nome Rede", M="Cliente EG", N="Cliente SAP", O="Nome da Loja",
                     Q="SKU EG", R="SKU SAP", S="Descrição", U="HL", V="PLT", W="Qtd Original CX",
                     Y="Data de Criação", Z="Data de Vencimento", AQ="Qtd Atualizada", AT="Carro sem Remessa",
                     AU="Carro com Remessa", AV="Faturado", BA="Data de Captação").items():
        put(head, l, n)
    ws.append(head)
    wm = wb.create_sheet("Marcado")
    mh = []
    for l, n in dict(B="Nº Pedido ERP", D="Cliente EG", E="Cliente SAP", F="Nome Cliente", G="SKU EG",
                     H="SKU SAP", I="Nome SKU", J="HL", K="PLT", L="CX", AH="Speed DRP", AI="Data Agenda",
                     AJ="Data Faturamento").items():
        put(mh, l, n)
    wm.append(mh)

    ped = 8000000
    for c in clientes:
        n_ped = rnd.randint(1, 3)
        grande = c["nome"].startswith("CD ")
        for _ in range(n_ped):
            ped += rnd.randint(1, 40)
            n_sku = rnd.randint(4, 8) if grande else rnd.randint(2, 4)
            for s in rnd.sample(skus, n_sku):
                plts = rnd.randint(3, 14) if grande else rnd.randint(1, 5)
                entrada = plts * s["f"]
                cria = REF - dt.timedelta(days=rnd.randint(6, 45))
                venc = REF + dt.timedelta(days=rnd.choice([-2, 1, 2, 3, 5, 8, 12, 20, 25]))
                fat = rnd.choice([0, 0, 0, entrada // 3, entrada // 2, entrada])
                sem_entrega = c["nome"] in ("SHIBATA LJ 05", "SHIBATA LJ 06", "OSVALDO LJ 03", "SK SUPERMERCADOS LJ 04")
                if sem_entrega:
                    fat = 0
                at = rnd.choice([0, 0, 0, entrada // 5])
                au = rnd.choice([0, 0, 0, entrada // 4])
                qtd = entrada
                if fat + at + au > qtd:
                    at = au = 0
                capt = rnd.choice([cria - dt.timedelta(days=2), cria - dt.timedelta(days=1), None, "N/D", "01/01/0001"])
                r = []
                for l, v in dict(B=str(ped), G=c["com"], L=c["rede"], M=c["eg"], N=c["sap"], O=c["nome"], Q=s["eg"], R=s["sap"],
                                 S=s["nome"], U=round(entrada * 0.0035, 2), V=round(plts + (3 if rnd.random() < 0.04 else 0), 1),
                                 W=entrada, Y=cria, Z=venc, AQ=qtd, AT=at, AU=au, AV=fat, BA=capt).items():
                    put(r, l, v)
                ws.append(r)
                # versão posterior da mesma chave (duplicada, criação mais nova)
                if rnd.random() < 0.15:
                    r2 = list(r)
                    put(r2, "Y", cria + dt.timedelta(days=3))
                    put(r2, "AQ", qtd - s["f"])
                    ws.append(r2)
                # marcações
                pend = max(0, qtd - fat - at - au)
                partes = []
                if fat:
                    partes.append(("fat", fat))
                if at + au:
                    partes.append(("fut", at + au))
                if pend and rnd.random() < 0.3:
                    partes.append(("fut", min(pend, s["f"] * 2)))
                if rnd.random() < 0.12 and not sem_entrega:
                    partes.append(("pas", s["f"]))
                for tipo, q in partes:
                    m = []
                    for l, v in dict(B=str(ped), D=c["eg"], E=c["sap"], F=c["nome"], G=s["eg"], H=s["sap"],
                                     I=s["nome"], J=round(q * 0.0035, 2), K=round(q / s["f"], 1), L=q,
                                     AH=f"DRP{rnd.randint(1000, 9999)}").items():
                        put(m, l, v)
                    if tipo == "fat":
                        put(m, "AI", REF - dt.timedelta(days=rnd.randint(1, 8)))
                        put(m, "AJ", REF - dt.timedelta(days=rnd.randint(1, 8)))
                    elif tipo == "pas":
                        put(m, "AI", REF - dt.timedelta(days=rnd.randint(1, 4)))
                    else:
                        put(m, "AI", REF + dt.timedelta(days=rnd.choice([0, 1, 2, 4, 6])))
                    wm.append(m)
    # marcações fora da carteira
    for _ in range(4):
        c = rnd.choice(clientes); s = rnd.choice(skus)
        m = []
        for l, v in dict(B="9999" + str(rnd.randint(100, 999)), D=c["eg"], E=c["sap"], F=c["nome"], G=s["eg"],
                         H=s["sap"], I=s["nome"], L=s["f"], AH="DRP0000", AI=REF + dt.timedelta(days=3)).items():
            put(m, l, v)
        wm.append(m)

    # --------- Planificadores (vales ativos na coluna AH)
    for aba, mult in (("Planificador_Pallet", 1), ("Planificador_Chapatex", 6)):
        ws = wb.create_sheet(aba)
        h = []
        put(h, "C", "Cliente"); put(h, "D", "Rede"); put(h, "AH", "Vales Ativos")
        ws.append(h)
        for rede in ("SONDA", "NAGUMO", "LOPES", "BARBOSA", "SHIBATA", "SK", "OSVALDO", "ATACADO XYZ"):
            for k in range(rnd.randint(1, 3)):
                r = []
                put(r, "C", f"{rede} {k+1}"); put(r, "D", rede); put(r, "AH", rnd.randint(20, 400) * mult)
                ws.append(r)
    wb.save(saida)
    return saida


if __name__ == "__main__":
    print(gerar(sys.argv[1] if len(sys.argv) > 1 else "exemplo_entrada.xlsx"))
