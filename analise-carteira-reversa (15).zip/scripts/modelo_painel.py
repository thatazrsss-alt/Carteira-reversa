# -*- coding: utf-8 -*-
"""Monta o Excel da Carteira Reversa (v4): painel dinâmico por rede, SKU, lojas e pedido.

Mesma estrutura da versão anterior (Painel_Gerencial, Por_*, Como_Funciona, abas de apoio ocultas),
agora com listas suspensas de rede, tipo (CD/VD), SKU, loja e pedido. Tudo que está nos painéis é
fórmula sobre as abas ocultas (Base_*), então muda quando o usuário escolhe nas listas.

    from modelo_painel import montar_excel
    montar_excel(res, "Carteira_Reversa.xlsx")      # res = calculo.processar(...)
"""
import datetime as dt
from collections import defaultdict

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference, Series
from openpyxl.chart.label import DataLabelList
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.chart.text import RichText
from openpyxl.drawing.text import CharacterProperties, Paragraph, ParagraphProperties, Font as DFont
from openpyxl.formatting.rule import CellIsRule, DataBarRule, FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.worksheet.datavalidation import DataValidation

NAVY, TEAL, GREEN, BLUE, AMBER, PURPLE = "1F3A5F", "00897B", "2E7D32", "90CAF9", "FFB74D", "B39DDB"
GRAY_BG, LINE, FONT = "F4F6F8", "D0D7DE", "Calibri"
F_PLT, F_CX, F_PCT = "#,##0.0", "#,##0", "0.0%"
P = "Painel_Gerencial"
N_DET, N_RANK_REDE, N_RANK_CLI, N_SKU, N_SKU_DET, N_LOJA, N_PED_LIN = 40, 12, 15, 30, 25, 40, 40
SKU_SEL_ROW = 8 + 30 + 2 + 1 + 24

PASSOS = [
    ("1. Quais linhas entram", "A Base Crua define a carteira ativa. A chave é Cliente EG + Pedido ERP + SKU EG e existe uma única linha por chave: a de menor data de criação (empate: menor vencimento). As demais vão para a auditoria. Marcações fora da carteira ficam só na aba Fora_Carteira."),
    ("2. Entrada", "Vem da linha escolhida: HL (U), PLT (V) e CX (W). Não é a soma de versões do pedido."),
    ("3. Pendente atual", "Qtd. atualizada − carro sem remessa − carro com remessa − faturado, em caixas (mínimo zero). Ele já desconta o que está marcado, mesmo que a entrega ainda não tenha chegado. Nunca é zerado por falta de estoque, produção ou carro."),
    ("4. Entregue", "O maior valor entre o faturado e o marcado já entregue (faturado na marcação ou agenda passada), limitado à entrada. No VD do Shibata, entregue é só o faturado."),
    ("5. Marcado / programado", "Carro sem remessa + carro com remessa + programação futura, do dia ou sem data, sem contar duas vezes o mesmo volume. É o que ainda vai ser entregue."),
    ("6. Fracionado", "Item com menos de 1 palete (pela conversão da CAD) é fracionado e só sai para cliente CD. No cliente VD ele continua na carteira e no pendente, mas fica fora do qualificado, da produção e do fill, com o motivo 'Fracionado: VD não entrega'. O pendente já é o que falta marcar: Entrada − Entregue − Marcado."),
    ("7. Origem e estoque", "Fábrica (Sonda, Lopes, Nagumo, Barbosa e CD Shibata): malha → origem → estoque D1 da fábrica. CDD (lojas do Shibata e clientes do DeParaCDD): saldo disponível da grade do CDD. Se a malha tiver mais de uma origem, o volume vai para a origem com estoque mais próxima de fechar 24 PLT."),
    ("8. Carro", "Fábrica: carro por Cliente EG + origem, mínimo 24 PLT e máximo 28; 22 ou 23 PLT são exceção e aparecem com asterisco (*). Abaixo do mínimo o estoque ainda é qualificado, mas com o alerta 'Abaixo do mínimo na origem'. CDD não tem mínimo. Origens diferentes não se somam."),
    ("9. Qualificado (estoque)", "Fábrica: menor valor entre pendente e estoque D1 da origem (já líquido). CDD: menor valor entre pendente e saldo. Pedidos do mesmo cliente e SKU consomem o estoque pelo vencimento mais próximo. Dois clientes no mesmo SKU não rateiam estoque: os dois enxergam o saldo e o painel só avisa 'Estoque disputado' / 'Estoque crítico'."),
    ("10. Produção", "Produção ativa, na mesma origem e no mesmo SKU S4, com data entre a data de referência e o vencimento do pedido cobre o que o estoque não cobriu (a quantidade não importa). O que sobra é Não atendido. Qualificado + Produção + Não atendido = Pendente."),
    ("11. Fill Rate", "% Entregue = Entregue ÷ Entrada. Fill Real = (Entregue + Marcado) ÷ Entrada. Fill c/ estoque hoje = Fill Real + o que o estoque de hoje qualifica. Fill c/ produção = + o que a produção válida cobre. Tudo recalculado dos totais, nunca média de percentuais."),
    ("12. Fill Rate VD", "Lojas atendidas ÷ total de lojas da rede (loja atendida = loja com volume entregue). Sinais: ▲ entregou e ainda tem mais de 2 PLT pendentes (possível segunda entrega) · ✓ entregou e pendente até 2 PLT · ○ sem entrega."),
    ("13. Vales", "Vales ativos de palete e chapatex por rede ficam no topo. Não entram na carteira, no estoque nem no fill."),
    ("14. Risco de validade", "Aparece quando o pedido ainda tem volume sem marcação e vence em até 2 dias (ou já venceu)."),
    ("Como usar", "Escolha a rede e o tipo (CD ou VD) nas listas amarelas. Tudo abaixo se atualiza. Em Por_SKU escolha rede e tipo e depois um SKU para ver quem o está pedindo. Em Lojas_VD escolha a rede. Em Pedido_Linhas escolha o pedido e veja linha a linha."),
]


# ------------------------------------------------------------------ estilo
def _fill(c):
    return PatternFill("solid", start_color=c, end_color=c)


def _border():
    s = Side(style="thin", color=LINE)
    return Border(left=s, right=s, top=s, bottom=s)


def _cell(ws, ref, value=None, bold=False, size=10, color="222222", bg=None, fmt=None, h="left", v="center",
          wrap=False, italic=False, border=False):
    c = ws[ref]
    if value is not None:
        c.value = value
    c.font = Font(name=FONT, bold=bold, size=size, color=color, italic=italic)
    c.alignment = Alignment(horizontal=h, vertical=v, wrap_text=wrap)
    if bg:
        c.fill = _fill(bg)
    if fmt:
        c.number_format = fmt
    if border:
        c.border = _border()
    return c


def _merge(ws, rng, **kw):
    a_, b_ = rng.split(":")
    if a_ != b_:
        ws.merge_cells(rng)
    c = _cell(ws, rng.split(":")[0], **kw)
    if kw.get("bg"):
        for row in ws[rng]:
            for x in row:
                x.fill = _fill(kw["bg"])
    return c


def _head(ws, row, col0, titles, size=9):
    for j, t in enumerate(titles):
        if t == "":
            continue
        _cell(ws, f"{L(col0 + j)}{row}", t, bold=True, size=size, color="FFFFFF", bg=NAVY, h="center", wrap=True, border=True)


def _cp(sz=800):
    return CharacterProperties(sz=sz, latin=DFont(typeface=FONT))


def _txt(sz=800):
    cp = _cp(sz)
    return RichText(p=[Paragraph(pPr=ParagraphProperties(defRPr=cp), endParaRPr=cp)])


def _cabecalho(ws, titulo, sub, ate="M"):
    ws.sheet_view.showGridLines = False
    ws.row_dimensions[1].height = 6
    ws.row_dimensions[2].height = 32
    _merge(ws, f"B2:{ate}2", value=titulo, bold=True, size=18, color="FFFFFF", bg=NAVY)
    ws["B2"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    _merge(ws, f"B3:{ate}3", value=sub, size=10, color="555555", bg=GRAY_BG)
    ws["B3"].alignment = Alignment(horizontal="left", vertical="center", indent=1)


def _card(ws, c1, c2, r, label, formula, fmt, sub=None, sub_fmt=None, big=20):
    _merge(ws, f"{c1}{r}:{c2}{r}", value=label, bold=True, size=9, color="FFFFFF", bg=TEAL, h="center")
    _merge(ws, f"{c1}{r+1}:{c2}{r+2}", value=formula, bold=True, size=big, color=NAVY, bg=GRAY_BG, h="center", fmt=fmt)
    _merge(ws, f"{c1}{r+3}:{c2}{r+3}", value=sub, size=9, color="777777", bg=GRAY_BG, h="center", fmt=sub_fmt)


def _fill_cf(ws, ref, size=20):
    ws.conditional_formatting.add(ref, CellIsRule(operator="greaterThanOrEqual", formula=["0.9"], font=Font(name=FONT, bold=True, size=size, color=GREEN)))
    ws.conditional_formatting.add(ref, CellIsRule(operator="between", formula=["0.7", "0.8999"], font=Font(name=FONT, bold=True, size=size, color="EF6C00")))
    ws.conditional_formatting.add(ref, CellIsRule(operator="lessThan", formula=["0.7"], font=Font(name=FONT, bold=True, size=size, color="C62828")))


def _bars(ws, ref):
    ws.conditional_formatting.add(ref, DataBarRule(start_type="num", start_value=0, end_type="num", end_value=1, color="9CCC65"))


def _dv(ws, cell, formula):
    dv = DataValidation(type="list", formula1=formula, allow_blank=False)
    ws.add_data_validation(dv)
    dv.add(cell)


def _selector(ws, row, label_col, label, rng, default, hint=None):
    _cell(ws, f"{label_col}{row}", label, bold=True, color=NAVY, h="right")
    return None


def _stack_chart(ws, calc, r1, r2, cat_col, cols, anchor, width, height=11.4, labels_first=True):
    ch = BarChart()
    ch.type, ch.grouping, ch.overlap, ch.gapWidth = "bar", "stacked", 100, 45
    ch.style = 10
    ch.visible_cells_only = False
    ch.legend.position = "b"
    ch.x_axis.delete = False
    ch.y_axis.delete = False
    ch.x_axis.scaling.orientation = "maxMin"
    ch.y_axis.scaling.min, ch.y_axis.scaling.max, ch.y_axis.majorUnit = 0, 1, 0.25
    ch.y_axis.number_format = "0%"
    ch.y_axis.majorGridlines.spPr = GraphicalProperties(ln=None)
    ch.x_axis.tickLblPos = "low"
    ch.x_axis.txPr = _txt(800)
    ch.y_axis.txPr = _txt(800)
    for i, (col, color, name) in enumerate(cols):
        s = Series(Reference(calc, min_col=col, min_row=r1, max_row=r2), title=name)
        s.graphicalProperties.solidFill = color
        s.graphicalProperties.line.solidFill = color
        if i == 0 and labels_first:
            s.dLbls = DataLabelList()
            s.dLbls.showVal, s.dLbls.showSerName, s.dLbls.showCatName = True, False, False
            s.dLbls.showLegendKey, s.dLbls.showPercent = False, False
            s.dLbls.numFmt = "0%"
            s.dLbls.txPr = _txt(750)
        ch.series.append(s)
    ch.set_categories(Reference(calc, min_col=cat_col, min_row=r1, max_row=r2))
    ch.width, ch.height = width, height
    ws.add_chart(ch, anchor)


# ------------------------------------------------------------------ montagem
def montar_excel(res, out_path, titulo="Carteira Reversa — Painel Gerencial", aviso_modelo=None,
                 rede_padrao="TODAS", loja_padrao=None):
    linhas = res["linhas"]
    data_ref = res["data_ref"]
    n = len(linhas)
    last = n + 1
    redes = sorted({x["rede"] for x in linhas})
    redes_vd = sorted({x["rede"] for x in linhas if x["tipo"] == "VD"})
    vales = res["vales"]

    wb = Workbook()
    ws = wb.active
    ws.title = P
    s_rede = wb.create_sheet("Por_Rede")
    s_sku = wb.create_sheet("Por_SKU")
    s_loja = wb.create_sheet("Lojas_VD")
    s_ped = wb.create_sheet("Por_Pedido")
    s_pl = wb.create_sheet("Pedido_Linhas")
    s_q = wb.create_sheet("Qualificado")
    s_cf = wb.create_sheet("Como_Funciona")
    bl = wb.create_sheet("Base_Linha")
    bp = wb.create_sheet("Base_Pedido")
    bc = wb.create_sheet("Base_Cliente")
    br = wb.create_sheet("Base_Rede")
    bs = wb.create_sheet("Base_SKU")
    bq = wb.create_sheet("Base_SKUP")
    bo = wb.create_sheet("Base_Orig")
    bj = wb.create_sheet("Base_Loja")
    calc = wb.create_sheet("Calc_Painel")
    lst = wb.create_sheet("Listas")
    fc = wb.create_sheet("Fora_Carteira")
    au = wb.create_sheet("Auditoria")
    cj = wb.create_sheet("Conferencias")
    wb.calculation.fullCalcOnLoad = True

    # ---------------------------------------------------------- Listas
    lst["A1"] = "TODAS"
    for i, r in enumerate(redes, 2):
        lst.cell(i, 1, r)
    n_redes_l = len(redes) + 1
    for i, t in enumerate(["Todos", "CD", "VD"], 1):
        lst.cell(i, 2, t)
    for i, r in enumerate(redes_vd, 1):
        lst.cell(i, 3, r)
    skus = sorted({(x["sku_eg"], x["descricao"]) for x in linhas})
    sku_lab = {k: f"{k[0]} · {k[1]}" for k in skus}
    for i, k in enumerate(skus, 1):
        lst.cell(i, 4, sku_lab[k])
    ped_lab = lambda x: f"{x['rede']} · {x['loja']} · {x['pedido']}"
    peds = sorted({ped_lab(x) for x in linhas})
    for i, t in enumerate(peds, 1):
        lst.cell(i, 5, t)

    # ---------------------------------------------------------- Base_Linha
    def v(x, k):
        return x[k]

    cols = [  # (id, cabeçalho, função -> valor | None, formato)
        ("rede", "Rede", lambda x: x["rede"], None),
        ("tipo", "Tipo", lambda x: x["tipo"], None),
        ("eg", "Cliente EG", lambda x: x["eg"], None),
        ("nome", "Nome", lambda x: x["loja"], None),
        ("pedido", "Pedido ERP", lambda x: x["pedido"], None),
        ("sku", "SKU EG", lambda x: x["sku_eg"], None),
        ("desc", "Descrição", lambda x: x["descricao"], None),
        ("ent", "Entrada CX", lambda x: x["entrada"], F_CX),
        ("entg", "Entregue CX", lambda x: x["entregue"], F_CX),
        ("prog", "Programado CX", lambda x: x["programado"], F_CX),
        ("pend", "Pendente CX", lambda x: x["pendente"], F_CX),
        ("falta", "Falta marcar CX", lambda x: x["falta_marcar"], F_CX),
        ("qual", "Qualificado CX", lambda x: x["qualificado"], F_CX),
        ("cest", "Cob estoque (fill) CX", lambda x: x["cob_estoque"], F_CX),
        ("cprodf", "Cob produção (fill) CX", lambda x: x["cob_prod_fill"], F_CX),
        ("cprod", "Cob produção CX", lambda x: x["cob_producao"], F_CX),
        ("descob", "Descoberto CX", lambda x: x["descoberto"], F_CX),
        ("ent_p", "Entrada PLT", lambda x: x["entrada_plt"], F_PLT),
        ("entg_p", "Entregue PLT", lambda x: x["entregue_plt"], F_PLT),
        ("prog_p", "Programado PLT", lambda x: x["programado_plt"], F_PLT),
        ("pend_p", "Pendente PLT", lambda x: x["pendente_plt"], F_PLT),
        ("falta_p", "Falta marcar PLT", lambda x: x["falta_marcar_plt"], F_PLT),
        ("entf", "Entrada p/ fill CX", lambda x: x["ent_f"], F_CX),
        ("entgf", "Entregue p/ fill CX", lambda x: x["entg_f"], F_CX),
        ("progf", "Programado p/ fill CX", lambda x: x["prog_f"], F_CX),
        ("orig_q", "Origem do qualificado", lambda x: x["orig_q"], None),
        ("naoat", "Não atendido CX", lambda x: x["nao_atendido_f"], F_CX),
        ("naoat_p", "Não atendido PLT", lambda x: x["nao_atendido_f_plt"], F_PLT),
        ("qual_p", "Qualificado PLT", lambda x: x["qualificado_plt"], F_PLT),
        ("cprod_p", "Cob produção PLT", lambda x: x["cob_producao_plt"], F_PLT),
        ("descob_p", "Descoberto PLT", lambda x: x["descoberto_plt"], F_PLT),
        ("f_semest", "Sem estoque", lambda x: 1 if x["motivo"] == "Sem estoque" else 0, None),
        ("f_naofecha", "Não fecha carro", lambda x: 1 if (x["motivo"] == "Não fecha carro" or "Não fecha carro" in x["alertas"]) else 0, None),
        ("f_crit", "Estoque crítico", lambda x: 1 if "Estoque crítico" in x["alertas"] else 0, None),
        ("f_semprod", "Sem produção válida", lambda x: 1 if "Sem produção válida" in x["alertas"] else 0, None),
        ("f_val", "Risco de validade", lambda x: 1 if ("Risco de validade" in x["alertas"] or "Vencido" in x["alertas"]) else 0, None),
        ("lab_sku", "Rótulo SKU", lambda x: sku_lab[(x["sku_eg"], x["descricao"])], None),
        ("lab_ped", "Rótulo pedido", ped_lab, None),
        ("situacao", "Situação", lambda x: x["situacao"], None),
        ("motivo", "Motivo", lambda x: x["motivo"], None),
        ("origem", "Origem", lambda x: x["origem"], None),
        ("alertas", "Alertas", lambda x: x["alertas"], None),
    ]
    C = {}
    for j, (cid, *_r) in enumerate(cols, 1):
        C[cid] = L(j)
    nxt = len(cols) + 1
    for k, name in enumerate(["sel_tipo", "sel_painel", "sel_sku", "sel_skudet", "sel_ped"]):
        C[name] = L(nxt + k)
    for j, (cid, h, fn, fm) in enumerate(cols, 1):
        _cell(bl, f"{L(j)}1", h, bold=True, color="FFFFFF", bg=NAVY)
    for name, h in (("sel_tipo", "Sel tipo"), ("sel_painel", "Sel painel"), ("sel_sku", "Sel SKU"),
                    ("sel_skudet", "Linha SKU escolhido"), ("sel_ped", "Linha pedido escolhido")):
        _cell(bl, f"{C[name]}1", h, bold=True, color="FFFFFF", bg=NAVY)

    for i, x in enumerate(linhas):
        r = i + 2
        for j, (cid, h, fn, fm) in enumerate(cols, 1):
            val = fn(x)
            if val is not None:
                c = bl.cell(r, j, val)
                if fm:
                    c.number_format = fm
        A, B = C["rede"], C["tipo"]
        bl[f"{C['sel_tipo']}{r}"] = f'=IF(OR({P}!$G$5="Todos",${B}{r}={P}!$G$5),1,0)'
        bl[f"{C['sel_painel']}{r}"] = f'=IF(AND(OR({P}!$C$5="TODAS",${A}{r}={P}!$C$5),{C["sel_tipo"]}{r}=1),1,0)'
        bl[f"{C['sel_sku']}{r}"] = f'=IF(AND(OR(Por_SKU!$C$5="TODAS",${A}{r}=Por_SKU!$C$5),OR(Por_SKU!$G$5="Todos",${B}{r}=Por_SKU!$G$5)),1,0)'
        bl[f"{C['sel_skudet']}{r}"] = f'=IF(AND({C["sel_sku"]}{r}=1,${C["lab_sku"]}{r}=Por_SKU!$C${SKU_SEL_ROW}),ROW(),"")'
        bl[f"{C['sel_ped']}{r}"] = f'=IF(${C["lab_ped"]}{r}=Pedido_Linhas!$C$5,ROW(),"")'

    def rl(cid):
        return f"Base_Linha!${C[cid]}$2:${C[cid]}${last}"

    # ---------------------------------------------------------- agregações em Python
    def soma(lst_, k):
        return sum((x[k] or 0) for x in lst_)

    ped_map = defaultdict(list)
    cli_map = defaultdict(list)
    for x in linhas:
        ped_map[(x["eg"], x["pedido"])].append(x)
        cli_map[x["eg"]].append(x)

    # ---------------------------------------------------------- Base_Pedido
    bpc = ["Rede", "Tipo", "Cliente EG", "Nome", "Pedido ERP", "Entrada CX", "Entregue CX", "Programado CX",
           "Pendente CX", "Falta marcar CX", "Entrada PLT", "Entregue PLT", "Programado PLT", "Pendente PLT",
           "Falta marcar PLT", "Ordem tipo", "Selecionado", "Chave detalhe", "Fill Real", "Fill Potencial"]
    for j, h in enumerate(bpc, 1):
        _cell(bp, f"{L(j)}1", h, bold=True, color="FFFFFF", bg=NAVY)
    ped_list = sorted(ped_map.items(), key=lambda kv: (kv[1][0]["rede"], kv[1][0]["loja"], kv[0][1]))
    for i, ((eg, pd_), ls) in enumerate(ped_list):
        r = i + 2
        x0 = ls[0]
        vals = [x0["rede"], x0["tipo"], eg, x0["loja"], pd_, soma(ls, "ent_f"), soma(ls, "entg_f"),
                soma(ls, "prog_f"), soma(ls, "pendente"), soma(ls, "falta_marcar"),
                soma(ls, "entrada_plt"), soma(ls, "entregue_plt"), soma(ls, "programado_plt"),
                soma(ls, "pendente_plt"), soma(ls, "falta_marcar_plt")]
        for j, val in enumerate(vals, 1):
            bp.cell(r, j, val)
        bp[f"U{r}"] = soma(ls, "qualificado_plt")
        bp[f"P{r}"] = f'=IF(B{r}="CD",1,2)'
        bp[f"Q{r}"] = f'=IF(AND(OR({P}!$C$5="TODAS",A{r}={P}!$C$5),OR({P}!$G$5="Todos",B{r}={P}!$G$5)),1,0)'
        bp[f"R{r}"] = f"=Q{r}*((3-P{r})*100000000+F{r}+ROW()/10000+1)"
        bp[f"S{r}"] = f"=IF(F{r}=0,0,G{r}/F{r})"
        bp[f"T{r}"] = f"=IF(F{r}=0,0,(G{r}+H{r})/F{r})"
    lp = len(ped_list) + 1

    def rp(col):
        return f"Base_Pedido!${col}$2:${col}${lp}"

    # ---------------------------------------------------------- Base_Cliente (selecionado em Painel)
    cl_list = sorted(cli_map.items(), key=lambda kv: (kv[1][0]["rede"], kv[1][0]["loja"]))
    for j, h in enumerate(["Rede", "Tipo", "Cliente EG", "Nome", "Entrada CX", "Entregue CX", "Programado CX",
                           "Cob estoque CX", "Cob produção CX", "Chave", "Fill Real", "Fill Potencial", "Fill estoque",
                           "Fill melhor", "Rótulo"], 1):
        _cell(bc, f"{L(j)}1", h, bold=True, color="FFFFFF", bg=NAVY)
    for i, (eg, ls) in enumerate(cl_list):
        r = i + 2
        x0 = ls[0]
        for j, val in enumerate([x0["rede"], x0["tipo"], eg, x0["loja"]], 1):
            bc.cell(r, j, val)
        for j, k in zip(range(5, 10), ["entf", "entgf", "progf", "cest", "cprodf"]):
            bc.cell(r, j, f"=SUMIFS({rl(k)},{rl('eg')},$C{r},{rl('sel_painel')},1)")
        bc[f"J{r}"] = f"=IF(E{r}>0,E{r}+ROW()/100000,0)"
        bc[f"K{r}"] = f"=IF(E{r}=0,0,F{r}/E{r})"
        bc[f"L{r}"] = f"=IF(E{r}=0,0,G{r}/E{r})"
        bc[f"M{r}"] = f"=IF(E{r}=0,0,H{r}/E{r})"
        bc[f"N{r}"] = f"=IF(E{r}=0,0,I{r}/E{r})"
        bc[f"O{r}"] = f'=TRIM(SUBSTITUTE(D{r},A{r}&" ",""))'
    lc = len(cl_list) + 1

    def rc(col):
        return f"Base_Cliente!${col}$2:${col}${lc}"

    # ---------------------------------------------------------- Base_Rede (filtra só pelo tipo do painel)
    for j, h in enumerate(["Rede", "Entrada CX", "Entregue CX", "Programado CX", "Cob estoque CX",
                           "Cob produção CX", "Chave", "Real", "+Programado", "+Estoque hoje", "+Produção"], 1):
        _cell(br, f"{L(j)}1", h, bold=True, color="FFFFFF", bg=NAVY)
    for i, rd in enumerate(redes):
        r = i + 2
        br.cell(r, 1, rd)
        for j, k in zip(range(2, 7), ["entf", "entgf", "progf", "cest", "cprodf"]):
            br.cell(r, j, f"=SUMIFS({rl(k)},{rl('rede')},$A{r},{rl('sel_tipo')},1)")
        br[f"G{r}"] = f"=IF(B{r}>0,B{r}+ROW()/100000,0)"
        br[f"H{r}"] = f"=IF(B{r}=0,0,C{r}/B{r})"
        br[f"I{r}"] = f"=IF(B{r}=0,0,D{r}/B{r})"
        br[f"J{r}"] = f"=IF(B{r}=0,0,E{r}/B{r})"
        br[f"K{r}"] = f"=IF(B{r}=0,0,F{r}/B{r})"
    lr = len(redes) + 1

    # ---------------------------------------------------------- Base_SKUP (SKUs da seleção do Painel: rede + tipo)
    for j, h in enumerate(["SKU EG", "Rótulo", "Entrada CX", "Entregue CX", "Programado CX", "Cob estoque CX",
                           "Cob produção CX", "Chave", "Real", "+Programado", "+Estoque hoje", "+Produção"], 1):
        _cell(bq, f"{L(j)}1", h, bold=True, color="FFFFFF", bg=NAVY)
    for i, (sku, desc) in enumerate(skus):
        r = i + 2
        bq.cell(r, 1, sku)
        bq.cell(r, 2, f"{sku} {desc}"[:34])
        for j, k in zip(range(3, 8), ["entf", "entgf", "progf", "cest", "cprodf"]):
            bq.cell(r, j, f"=SUMIFS({rl(k)},{rl('sku')},$A{r},{rl('sel_painel')},1)")
        bq[f"H{r}"] = f"=IF(C{r}>0,C{r}+ROW()/100000,0)"
        bq[f"I{r}"] = f"=IF(C{r}=0,0,D{r}/C{r})"
        bq[f"J{r}"] = f"=IF(C{r}=0,0,E{r}/C{r})"
        bq[f"K{r}"] = f"=IF(C{r}=0,0,F{r}/C{r})"
        bq[f"L{r}"] = f"=IF(C{r}=0,0,G{r}/C{r})"
    lq = max(len(skus), 1) + 1

    # ---------------------------------------------------------- Base_Orig (qualificado por origem, seleção do Painel)
    origs = sorted({x["orig_q"] for x in linhas})
    for j, h in enumerate(["Origem", "Pendente PLT", "Qualificado PLT", "Cob produção PLT", "Descoberto PLT", "Chave"], 1):
        _cell(bo, f"{L(j)}1", h, bold=True, color="FFFFFF", bg=NAVY)
    for i, og in enumerate(origs):
        r = i + 2
        bo.cell(r, 1, og)
        for j, k in zip(range(2, 6), ["pend_p", "qual_p", "cprod_p", "descob_p"]):
            bo.cell(r, j, f"=SUMIFS({rl(k)},{rl('orig_q')},$A{r},{rl('sel_painel')},1)")
        bo[f"F{r}"] = f"=IF(B{r}>0,B{r}+ROW()/100000,0)"
    lo = max(len(origs), 1) + 1

    # ---------------------------------------------------------- Base_SKU (seleção de Por_SKU)
    sh = ["SKU EG", "Descrição", "Linhas c/ pendente", "Pendente PLT", "Qualificado PLT", "Cob produção PLT",
          "Não atendido PLT", "Sem estoque", "Não fecha carro", "Estoque crítico", "Sem produção válida",
          "Pendente CX", "Chave", "Rótulo"]
    for j, h in enumerate(sh, 1):
        _cell(bs, f"{L(j)}1", h, bold=True, color="FFFFFF", bg=NAVY)
    for i, (sk, ds) in enumerate(skus):
        r = i + 2
        bs.cell(r, 1, sk)
        bs.cell(r, 2, ds)
        bs[f"C{r}"] = f'=COUNTIFS({rl("sku")},$A{r},{rl("sel_sku")},1,{rl("pend")},">0")'
        for j, k in zip(range(4, 8), ["pend_p", "qual_p", "cprod_p", "descob_p"]):
            bs.cell(r, j, f"=SUMIFS({rl(k)},{rl('sku')},$A{r},{rl('sel_sku')},1)")
        for j, k in zip(range(8, 12), ["f_semest", "f_naofecha", "f_crit", "f_semprod"]):
            bs.cell(r, j, f"=SUMIFS({rl(k)},{rl('sku')},$A{r},{rl('sel_sku')},1,{rl('pend')},\">0\")")
        bs[f"L{r}"] = f"=SUMIFS({rl('pend')},{rl('sku')},$A{r},{rl('sel_sku')},1)"
        bs[f"M{r}"] = f"=IF(L{r}>0,D{r}+L{r}/1000000+ROW()/100000000,0)"
        bs[f"N{r}"] = sku_lab[(sk, ds)]
    lsk = len(skus) + 1

    def rs(col):
        return f"Base_SKU!${col}$2:${col}${lsk}"

    # ---------------------------------------------------------- Base_Loja (VD)
    vd = [(eg, ls) for eg, ls in cl_list if ls[0]["tipo"] == "VD"]
    for j, h in enumerate(["Rede", "Cliente EG", "Nome", "Entrada PLT", "Entregue PLT", "Pendente PLT", "Entrada CX",
                           "Entregue CX", "Selecionada", "Chave", "Sinal", "Status", "Rótulo", "Programado CX",
                           "Cob estoque CX", "Cob produção CX", "Real", "+Programado", "+Estoque hoje", "+Produção"], 1):
        _cell(bj, f"{L(j)}1", h, bold=True, color="FFFFFF", bg=NAVY)
    for i, (eg, ls) in enumerate(vd):
        r = i + 2
        x0 = ls[0]
        for j, val in enumerate([x0["rede"], eg, x0["loja"], soma(ls, "entrada_plt"), soma(ls, "entregue_plt"),
                                 soma(ls, "pendente_plt"), soma(ls, "ent_f"), soma(ls, "entg_f")], 1):
            bj.cell(r, j, val)
        bj[f"I{r}"] = f"=IF(A{r}=Lojas_VD!$C$5,1,0)"
        bj[f"J{r}"] = f"=I{r}*(G{r}+ROW()/10000+1)"
        bj[f"K{r}"] = f'=IF(H{r}<=0,"○",IF(F{r}>{2},"▲","✓"))'
        bj[f"L{r}"] = f'=IF(H{r}<=0,"Sem entrega",IF(F{r}>{2},"Entregue · possível 2ª entrega","Entregue"))'
        bj[f"M{r}"] = f'=TRIM(SUBSTITUTE(C{r},A{r}&" ",""))'
        bj[f"N{r}"], bj[f"O{r}"], bj[f"P{r}"] = soma(ls, "prog_f"), soma(ls, "cob_estoque"), soma(ls, "cob_prod_fill")
        bj[f"Q{r}"] = f"=IF(G{r}=0,0,H{r}/G{r})"
        bj[f"R{r}"] = f"=IF(G{r}=0,0,N{r}/G{r})"
        bj[f"S{r}"] = f"=IF(G{r}=0,0,O{r}/G{r})"
        bj[f"T{r}"] = f"=IF(G{r}=0,0,P{r}/G{r})"
    ljj = max(len(vd), 1) + 1

    def rj(col):
        return f"Base_Loja!${col}$2:${col}${ljj}"

    # ---------------------------------------------------------- Calc_Painel (rankings)
    ranks = {}

    def rank_block(first, count, key_rng, kind):
        for k in range(1, count + 1):
            r = first + k - 1
            calc.cell(r, 1, k)
            calc.cell(r, 2, f"=IFERROR(LARGE({key_rng},A{r}),0)")
            calc.cell(r, 3, f"=IF(B{r}>0,MATCH(B{r},{key_rng},0),0)")

    r_rede = 2     # (bloco por SKU da seleção; o gráfico do Painel não mostra outras redes)
    rank_block(r_rede, N_RANK_REDE, f"Base_SKUP!$H$2:$H${lq}", "skup")
    for k in range(N_RANK_REDE):
        r = r_rede + k
        calc.cell(r, 4, f'=IF(C{r}=0,"",INDEX(Base_SKUP!$B$2:$B${lq},C{r}))')
        for j, col in zip(range(5, 9), "IJKL"):
            calc.cell(r, j, f"=IF(C{r}=0,NA(),INDEX(Base_SKUP!${col}$2:${col}${lq},C{r}))").number_format = "0%"
    r_cli = r_rede + N_RANK_REDE + 2
    rank_block(r_cli, N_RANK_CLI, rc("J"), "cli")
    for k in range(N_RANK_CLI):
        r = r_cli + k
        calc.cell(r, 4, f'=IF(C{r}=0,"",INDEX({rc("D")},C{r}))')
        for j, col in zip(range(5, 9), "KLMN"):
            calc.cell(r, j, f"=IF(C{r}=0,NA(),INDEX({rc(col)},C{r}))").number_format = "0%"
    r_det = r_cli + N_RANK_CLI + 2
    rank_block(r_det, N_DET, rp("R"), "det")
    r_sku = r_det + N_DET + 2
    rank_block(r_sku, N_SKU, rs("M"), "sku")
    r_loja = r_sku + N_SKU + 2
    rank_block(r_loja, N_LOJA, rj("J"), "loja")
    N_ORIG = 10
    r_orig = r_loja + N_LOJA + 2
    rank_block(r_orig, N_ORIG, f"Base_Orig!$F$2:$F${lo}", "orig")
    for k in range(N_ORIG):
        r = r_orig + k
        calc.cell(r, 4, f'=IF(C{r}=0,"",INDEX(Base_Orig!$A$2:$A${lo},C{r}))')
        for j, col in zip(range(5, 9), "BCDE"):
            calc.cell(r, j, f"=IF(C{r}=0,\"\",INDEX(Base_Orig!${col}$2:${col}${lo},C{r}))")
    r_skud = r_orig + N_ORIG + 2
    for k in range(1, N_SKU_DET + 1):
        r = r_skud + k - 1
        calc.cell(r, 1, k)
        calc.cell(r, 2, f'=IFERROR(SMALL({rl("sel_skudet")},A{r}),0)')
        calc.cell(r, 3, f"=IF(B{r}>0,B{r}-1,0)")
    r_pl = r_skud + N_SKU_DET + 2
    for k in range(1, N_PED_LIN + 1):
        r = r_pl + k - 1
        calc.cell(r, 1, k)
        calc.cell(r, 2, f'=IFERROR(SMALL({rl("sel_ped")},A{r}),0)')
        calc.cell(r, 3, f"=IF(B{r}>0,B{r}-1,0)")
    # séries para gráficos da Por_SKU (Qualificado/Produção/Descoberto em % do pendente) e Lojas
    r_sku_chart = r_pl + N_PED_LIN + 2
    for k in range(12):
        r = r_sku_chart + k
        ix = f"C{r_sku + k}"
        calc.cell(r, 4, f'=IF({ix}=0,"",INDEX({rs("A")},{ix}))')
        for j, col in zip((5, 6, 7), "EFG"):
            calc.cell(r, j, f"=IF({ix}=0,NA(),IF(INDEX({rs('D')},{ix})=0,0,INDEX({rs(col)},{ix})/INDEX({rs('D')},{ix})))").number_format = "0%"
    r_loja_chart = r_sku_chart + 14
    for k in range(N_LOJA):
        r = r_loja_chart + k
        ix = f"C{r_loja + k}"
        calc.cell(r, 4, f'=IF({ix}=0,"",INDEX({rj("M")},{ix}))')
        for j, col in zip(range(5, 9), "QRST"):
            calc.cell(r, j, f"=IF({ix}=0,NA(),INDEX({rj(col)},{ix}))").number_format = "0%"

    # ================================================================ Painel_Gerencial
    sub = (f"Data de referência: {data_ref.strftime('%d/%m/%Y')}   ·   volumes em paletes (PLT), caixas (CX) em cinza"
           f"   ·   vales de palete e chapatex não entram nos números")
    _cabecalho(ws, titulo, sub)
    for k, w in {"A": 2, "B": 13, "C": 13, "D": 13, "E": 13, "F": 15, "G": 13, "H": 13, "I": 13, "J": 13, "K": 13,
                 "L": 13, "M": 13, "N": 2}.items():
        ws.column_dimensions[k].width = w
    ws.sheet_view.zoomScale = 90
    if aviso_modelo:
        _merge(ws, "B4:M4", value=aviso_modelo, size=9, italic=True, color="9A3412", bg="FFF4E5", wrap=True)
        ws.row_dimensions[4].height = 28
    ws.row_dimensions[5].height = 26
    _cell(ws, "B5", "Rede ▾", bold=True, color=NAVY, h="right")
    _merge(ws, "C5:E5", value=rede_padrao, bold=True, size=12, color=NAVY, bg="FFF8E1", border=True, h="center")
    _cell(ws, "F5", "Tipo (CD / VD) ▾", bold=True, color=NAVY, h="right")
    _merge(ws, "G5:H5", value="Todos", bold=True, size=12, color=NAVY, bg="FFF8E1", border=True, h="center")
    _merge(ws, "I5:M5", value="← escolha nas listas; tudo abaixo se atualiza", italic=True, size=9, color="777777")
    _dv(ws, "C5", f"=Listas!$A$1:$A${n_redes_l}")
    _dv(ws, "G5", "=Listas!$B$1:$B$3")
    # vales
    ws.row_dimensions[6].height = 22
    for j, h in enumerate(["Rede", "Vales palete", "Vales chapatex"], 1):
        lst.cell(1, 7 + j - 1, h)
    for i, rd in enumerate(redes, 2):
        lst.cell(i, 7, rd)
        lst.cell(i, 8, vales[rd]["palete"])
        lst.cell(i, 9, vales[rd]["chapatex"])
    vp = f'=IF($C$5="TODAS",SUM(Listas!$H$2:$H${len(redes)+1}),SUMIFS(Listas!$H$2:$H${len(redes)+1},Listas!$G$2:$G${len(redes)+1},$C$5))'
    vc = f'=IF($C$5="TODAS",SUM(Listas!$I$2:$I${len(redes)+1}),SUMIFS(Listas!$I$2:$I${len(redes)+1},Listas!$G$2:$G${len(redes)+1},$C$5))'
    _merge(ws, "B6:D6", value="Pendente de palete (vales ativos)", bold=True, size=9, color=NAVY, bg="E8F5E9", h="right")
    _cell(ws, "E6", vp, bold=True, size=12, color=NAVY, bg="E8F5E9", fmt="#,##0", h="center")
    _merge(ws, "F6:H6", value="Pendente de chapatex (vales ativos)", bold=True, size=9, color=NAVY, bg="E8F5E9", h="right")
    _cell(ws, "I6", vc, bold=True, size=12, color=NAVY, bg="E8F5E9", fmt="#,##0", h="center")
    _merge(ws, "J6:M6", value="da rede selecionada · não somam à carteira, ao estoque nem ao fill", italic=True, size=8, color="777777")

    S = lambda cid: f"SUMIFS({rl(cid)},{rl('sel_painel')},1)"
    ws.row_dimensions[7].height = 18
    ws.row_dimensions[8].height = 22
    ws.row_dimensions[9].height = 22
    ws.row_dimensions[10].height = 16
    cards1 = [("B", "C", "Entrada", "ent"), ("D", "E", "Entregue", "entg"), ("F", "G", "Marcado / programado", "prog"),
              ("H", "I", "Pendente atual", "pend"), ("J", "K", "Qualificado c/ estoque", "qual"), ("L", "M", "Cobertura por produção", "cprod")]
    for c1, c2, lab, cid in cards1:
        _card(ws, c1, c2, 7, lab, f"={S(cid + '_p')}", F_PLT, f"={S(cid)}", '#,##0" CX"')
    for r in (12, 13, 14, 15):
        ws.row_dimensions[r].height = 18 if r in (12, 15) else 22
    fE = S("entf")
    _card(ws, "B", "C", 12, "% Entregue", f"=IF({fE}=0,0,{S('entgf')}/{fE})", F_PCT, "Entregue ÷ Entrada")
    _card(ws, "D", "E", 12, "Fill Real", f"=IF({fE}=0,0,({S('entgf')}+{S('progf')})/{fE})", F_PCT, "(entregue + marcado) ÷ entrada")
    _card(ws, "F", "G", 12, "Fill c/ estoque hoje", f"=IF({fE}=0,0,({S('entgf')}+{S('progf')}+{S('cest')})/{fE})", F_PCT, "+ estoque qualificado")
    _card(ws, "H", "I", 12, "Fill c/ produção", f"=IF({fE}=0,0,({S('entgf')}+{S('progf')}+{S('cest')}+{S('cprodf')})/{fE})", F_PCT, "+ produção válida")
    _card(ws, "J", "K", 12, "Qualificado total (estoque + produção)", f"={S('qual_p')}+{S('cprod_p')}", F_PLT, f"={S('qual')}+{S('cprod')}", '#,##0" CX"')
    _card(ws, "L", "M", 12, "Não atendido (provável)", f"={S('descob_p')}", F_PLT, f"={S('descob')}", '#,##0" CX"')
    for ref in ("B13", "D13", "F13", "H13"):
        _fill_cf(ws, ref)
    _merge(ws, "B16:M16", value="Pendente = Qtd. atualizada − carros − faturado (já desconta o marcado; é o que falta marcar). Qualificado + Produção + Não atendido = Pendente. "
           "Fill Real = entregue + marcado. Fill c/ estoque hoje soma o qualificado; Fill c/ produção soma a produção. Fracionado (< 1 PLT) em cliente VD fica fora do qualificado e do fill.",
           italic=True, size=8, color="777777", wrap=True)
    ws.row_dimensions[16].height = 26

    _merge(ws, "B18:M18", value="Resumo por tipo (PLT)", bold=True, size=12, color=NAVY)
    ws.row_dimensions[18].height = 22
    ws.merge_cells("B19:C19")
    _head(ws, 19, 2, ["Tipo", ""])
    _head(ws, 19, 4, ["Pedidos", "Entrada", "Entregue", "Marcado", "Pendente", "Qualificado (estoque)",
                      "Fill Real", "Fill c/ estoque hoje", "Fill c/ produção", "Não atendido"])
    for i, tp in enumerate(["CD", "VD"]):
        r = 20 + i
        ws.merge_cells(f"B{r}:C{r}")
        _cell(ws, f"B{r}", tp, bold=True, color=NAVY, border=True)
        ws[f"C{r}"].border = _border()
        crit = f'{rl("sel_painel")},1,{rl("tipo")},"{tp}"'
        _cell(ws, f"D{r}", f'=COUNTIFS({rp("Q")},1,{rp("B")},"{tp}")', fmt="#,##0", h="center", border=True)
        for col, cid in zip("EFGHI", ["ent_p", "entg_p", "prog_p", "pend_p", "qual_p"]):
            _cell(ws, f"{col}{r}", f"=SUMIFS({rl(cid)},{crit})", fmt=F_PLT, h="right", border=True)
        e = f"SUMIFS({rl('entf')},{crit})"
        g = lambda cid: f"SUMIFS({rl(cid)},{crit})"
        _cell(ws, f"J{r}", f"=IF({e}=0,0,({g('entgf')}+{g('progf')})/{e})", fmt=F_PCT, h="center", border=True)
        _cell(ws, f"K{r}", f"=IF({e}=0,0,({g('entgf')}+{g('progf')}+{g('cest')})/{e})", fmt=F_PCT, h="center", border=True)
        _cell(ws, f"L{r}", f"=IF({e}=0,0,({g('entgf')}+{g('progf')}+{g('cest')}+{g('cprodf')})/{e})", fmt=F_PCT, h="center", border=True)
        _cell(ws, f"M{r}", f"=SUMIFS({rl('descob_p')},{crit})", fmt=F_PLT, h="right", border=True)
    ws.merge_cells("B22:C22")
    _cell(ws, "B22", "Total da seleção", bold=True, color="FFFFFF", bg=TEAL, border=True)
    ws["C22"].fill = _fill(TEAL)
    _cell(ws, "D22", "=SUM(D20:D21)", bold=True, fmt="#,##0", h="center", bg=GRAY_BG, border=True)
    for col in "EFGHI":
        _cell(ws, f"{col}22", f"=SUM({col}20:{col}21)", bold=True, fmt=F_PLT, h="right", bg=GRAY_BG, border=True)
    for col, src in zip("JKL", ["D13", "F13", "H13"]):
        _cell(ws, f"{col}22", f"={src}", bold=True, fmt=F_PCT, h="center", bg=GRAY_BG, border=True)
    _cell(ws, "M22", "=SUM(M20:M21)", bold=True, fmt=F_PLT, h="right", bg=GRAY_BG, border=True)
    for r in (20, 21, 22):
        ws.row_dimensions[r].height = 20
    _bars(ws, "J20:L21")

    # gráficos
    _merge(ws, "B24:M24", value="Fill Rate: entregue + marcado, estoque hoje e produção", bold=True, size=12, color=NAVY)
    ws.row_dimensions[24].height = 22
    _merge(ws, "B25:G25", value="Por SKU da seleção (até 12 maiores por entrada)", size=9, italic=True, color="555555")
    _merge(ws, "H25:M25", value="Clientes da seleção (até 15 maiores por entrada)", size=9, italic=True, color="555555")
    series = [(5, GREEN, "Entregue"), (6, BLUE, "+ Marcado"), (7, AMBER, "+ Estoque hoje"), (8, PURPLE, "+ Produção")]
    _stack_chart(ws, calc, r_rede, r_rede + N_RANK_REDE - 1, 4, series, "B26", 15.6)
    _stack_chart(ws, calc, r_cli, r_cli + N_RANK_CLI - 1, 4, series, "H26", 15.4)

    ro = 50
    _merge(ws, f"B{ro}:M{ro}", value="Qualificado por origem (seleção atual, PLT)", bold=True, size=12, color=NAVY)
    ws.row_dimensions[ro].height = 22
    ws.merge_cells(f"B{ro+1}:D{ro+1}")
    _head(ws, ro + 1, 2, ["Origem", "", "", "Pendente", "Qualificado (estoque)", "Cob. produção", "Qualificado total",
                          "Não atendido", "% qual. estoque", "% qual. total"])
    ws.row_dimensions[ro + 1].height = 30
    for k in range(N_ORIG):
        r = ro + 2 + k
        ws.merge_cells(f"B{r}:D{r}")
        cc = f"Calc_Painel!{{}}{r_orig + k}"
        _cell(ws, f"B{r}", f'=IF({cc.format("$D$")}="","",{cc.format("$D$")})', size=9)
        for col, src in zip("EFG", "EFG"):
            _cell(ws, f"{col}{r}", f'=IF({cc.format("$C$")}=0,"",{cc.format("$" + src + "$")})', size=9, fmt=F_PLT, h="right")
        _cell(ws, f"H{r}", f'=IF(F{r}="","",F{r}+G{r})', size=9, fmt=F_PLT, h="right")
        _cell(ws, f"I{r}", f'=IF(F{r}="","",MAX(0,E{r}-H{r}))', size=9, fmt=F_PLT, h="right")
        _cell(ws, f"J{r}", f'=IF(OR(F{r}="",E{r}=0),"",F{r}/E{r})', size=9, fmt=F_PCT, h="center")
        _cell(ws, f"K{r}", f'=IF(OR(F{r}="",E{r}=0),"",H{r}/E{r})', size=9, fmt=F_PCT, h="center")
        if k % 2:
            for col in "BCDEFGHIJK":
                ws[f"{col}{r}"].fill = _fill(GRAY_BG)
    rt = ro + 2 + N_ORIG
    ws.merge_cells(f"B{rt}:D{rt}")
    _cell(ws, f"B{rt}", "Total da seleção", bold=True, color="FFFFFF", bg=TEAL, border=True)
    for col, cid in zip("EFG", ("pend_p", "qual_p", "cprod_p")):
        _cell(ws, f"{col}{rt}", f"={S(cid)}", bold=True, fmt=F_PLT, h="right", bg=GRAY_BG, border=True)
    _cell(ws, f"H{rt}", f"=F{rt}+G{rt}", bold=True, fmt=F_PLT, h="right", bg=GRAY_BG, border=True)
    _cell(ws, f"I{rt}", f"=MAX(0,E{rt}-H{rt})", bold=True, fmt=F_PLT, h="right", bg=GRAY_BG, border=True)
    _cell(ws, f"J{rt}", f"=IF(E{rt}=0,0,F{rt}/E{rt})", bold=True, fmt=F_PCT, h="center", bg=GRAY_BG, border=True)
    _cell(ws, f"K{rt}", f"=IF(E{rt}=0,0,H{rt}/E{rt})", bold=True, fmt=F_PCT, h="center", bg=GRAY_BG, border=True)
    _bars(ws, f"J{ro+2}:K{ro+1+N_ORIG}")

    r0 = rt + 3
    _merge(ws, f"B{r0}:M{r0}", value="Detalhe por pedido (CD primeiro, depois VD; PLT)", bold=True, size=12, color=NAVY)
    ws.row_dimensions[r0].height = 22
    hh = r0 + 1
    ws.merge_cells(f"D{hh}:E{hh}")
    _head(ws, hh, 2, ["Tipo", "Rede", "Cliente", "", "Pedido", "Entrada", "Entregue", "Marcado", "Pendente", "Qualificado", "% Entregue", ])
    _cell(ws, f"M{hh}", "Fill Real", bold=True, size=9, color="FFFFFF", bg=NAVY, h="center", border=True)
    for k in range(N_DET):
        r = hh + 1 + k
        ix = f"Calc_Painel!$C${r_det + k}"
        ws.merge_cells(f"D{r}:E{r}")
        _cell(ws, f"B{r}", f'=IF({ix}=0,"",INDEX({rp("B")},{ix}))', size=9, color="555555")
        _cell(ws, f"C{r}", f'=IF({ix}=0,"",INDEX({rp("A")},{ix}))', size=9)
        _cell(ws, f"D{r}", f'=IF({ix}=0,"",TRIM(SUBSTITUTE(INDEX({rp("D")},{ix}),INDEX({rp("A")},{ix})&" ","")))', size=9)
        _cell(ws, f"F{r}", f'=IF({ix}=0,"",INDEX({rp("E")},{ix}))', size=9, h="center")
        for col, src in zip("GHIJK", ["K", "L", "M", "N", "U"]):
            _cell(ws, f"{col}{r}", f'=IF({ix}=0,"",INDEX({rp(src)},{ix}))', size=9, fmt=F_PLT, h="right")
        _cell(ws, f"L{r}", f'=IF({ix}=0,"",INDEX({rp("S")},{ix}))', size=9, fmt=F_PCT, h="center")
        _cell(ws, f"M{r}", f'=IF({ix}=0,"",INDEX({rp("T")},{ix}))', size=9, fmt=F_PCT, h="center")
        if k % 2:
            for col in "BCDEFGHIJKLM":
                ws[f"{col}{r}"].fill = _fill(GRAY_BG)
    _bars(ws, f"L{hh+1}:M{hh+N_DET}")
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = 1, 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True

    # ================================================================ Por_Rede (gerencial por rede)
    _cabecalho(s_rede, "Gerencial por rede", f"Data de referência: {data_ref.strftime('%d/%m/%Y')}   ·   PLT   ·   use os filtros dos cabeçalhos", ate="W")
    ws2 = s_rede
    heads = ["Rede", "Clientes", "Pedidos", "Entrada", "Entregue", "Marcado", "Pendente", "Qualificado total",
             "Qualificado (estoque)", "Cob. produção", "Não atendido", "Sem estoque", "Não fecha carro",
             "% Entregue", "Fill Real", "Fill c/ estoque hoje", "Fill c/ produção", "Lojas VD", "Lojas atendidas",
             "Fill Rate VD (lojas)", "Pendente palete (vales)", "Pendente chapatex (vales)"]
    _head(ws2, 5, 2, heads)
    ws2.row_dimensions[5].height = 32
    rr = 6
    tot_rows = []
    for rd in redes:
        ls = [x for x in linhas if x["rede"] == rd]
        cl = {x["eg"] for x in ls}
        pd_ = {(x["eg"], x["pedido"]) for x in ls}
        vdl = [x for x in ls if x["tipo"] == "VD"]
        lojas = {x["eg"] for x in vdl}
        atend = {x["eg"] for x in vdl if x["entregue"] > 0}
        sem_est = sum((x["pendente_plt"] or 0) for x in ls if x["motivo"] == "Sem estoque")
        n_fecha = sum((x["pendente_plt"] or 0) for x in ls if x["motivo"] == "Não fecha carro")
        e = soma(ls, "ent_f")
        vals = [rd, len(cl), len(pd_), soma(ls, "entrada_plt"), soma(ls, "entregue_plt"), soma(ls, "programado_plt"),
                soma(ls, "pendente_plt"), soma(ls, "qualificado_plt") + soma(ls, "cob_producao_plt"), soma(ls, "qualificado_plt"),
                soma(ls, "cob_producao_plt"), soma(ls, "descoberto_plt"), sem_est, n_fecha]
        for j, val in enumerate(vals, 2):
            _cell(ws2, f"{L(j)}{rr}", val, border=True, fmt=(F_PLT if j >= 5 else (F_CX if j > 2 else None)),
                  h="left" if j == 2 else "right", bold=(j == 2))
        fe = (e, soma(ls, "entg_f"), soma(ls, "prog_f"), soma(ls, "cob_estoque"), soma(ls, "cob_prod_fill"))
        # percentuais por fórmula a partir de totais em CX guardados em colunas de apoio (Z:AC)
        for j, val in zip(range(26, 31), fe):
            ws2.cell(rr, j, val)
        _cell(ws2, f"O{rr}", f"=IF(Z{rr}=0,0,AA{rr}/Z{rr})", fmt=F_PCT, h="center", border=True)
        _cell(ws2, f"P{rr}", f"=IF(Z{rr}=0,0,(AA{rr}+AB{rr})/Z{rr})", fmt=F_PCT, h="center", border=True)
        _cell(ws2, f"Q{rr}", f"=IF(Z{rr}=0,0,(AA{rr}+AB{rr}+AC{rr})/Z{rr})", fmt=F_PCT, h="center", border=True)
        _cell(ws2, f"R{rr}", f"=IF(Z{rr}=0,0,(AA{rr}+AB{rr}+AC{rr}+AD{rr})/Z{rr})", fmt=F_PCT, h="center", border=True)
        _cell(ws2, f"S{rr}", len(lojas), fmt=F_CX, h="right", border=True)
        _cell(ws2, f"T{rr}", len(atend), fmt=F_CX, h="right", border=True)
        _cell(ws2, f"U{rr}", f'=IF(S{rr}=0,"",T{rr}/S{rr})', fmt=F_PCT, h="center", border=True)
        _cell(ws2, f"V{rr}", vales[rd]["palete"], fmt=F_CX, h="right", border=True)
        _cell(ws2, f"W{rr}", vales[rd]["chapatex"], fmt=F_CX, h="right", border=True)
        rr += 1
    fim = rr - 1
    _cell(ws2, f"B{rr}", "Total", bold=True, color="FFFFFF", bg=TEAL, border=True)
    for col in "CDEFGHIJKLMN":
        _cell(ws2, f"{col}{rr}", f"=SUM({col}6:{col}{fim})", bold=True, bg=GRAY_BG, border=True,
              fmt=F_CX if col in "CD" else F_PLT, h="right")
    for j in range(26, 31):
        ws2.cell(rr, j, f"=SUM({L(j)}6:{L(j)}{fim})")
    _cell(ws2, f"O{rr}", f"=IF(Z{rr}=0,0,AA{rr}/Z{rr})", bold=True, fmt=F_PCT, h="center", bg=GRAY_BG, border=True)
    _cell(ws2, f"P{rr}", f"=IF(Z{rr}=0,0,(AA{rr}+AB{rr})/Z{rr})", bold=True, fmt=F_PCT, h="center", bg=GRAY_BG, border=True)
    _cell(ws2, f"Q{rr}", f"=IF(Z{rr}=0,0,(AA{rr}+AB{rr}+AC{rr})/Z{rr})", bold=True, fmt=F_PCT, h="center", bg=GRAY_BG, border=True)
    _cell(ws2, f"R{rr}", f"=IF(Z{rr}=0,0,(AA{rr}+AB{rr}+AC{rr}+AD{rr})/Z{rr})", bold=True, fmt=F_PCT, h="center", bg=GRAY_BG, border=True)
    _cell(ws2, f"S{rr}", f"=SUM(S6:S{fim})", bold=True, fmt=F_CX, h="right", bg=GRAY_BG, border=True)
    _cell(ws2, f"T{rr}", f"=SUM(T6:T{fim})", bold=True, fmt=F_CX, h="right", bg=GRAY_BG, border=True)
    _cell(ws2, f"U{rr}", f'=IF(S{rr}=0,"",T{rr}/S{rr})', bold=True, fmt=F_PCT, h="center", bg=GRAY_BG, border=True)
    _cell(ws2, f"V{rr}", f"=SUM(V6:V{fim})", bold=True, fmt=F_CX, h="right", bg=GRAY_BG, border=True)
    _cell(ws2, f"W{rr}", f"=SUM(W6:W{fim})", bold=True, fmt=F_CX, h="right", bg=GRAY_BG, border=True)
    _head(ws2, 5, 26, ["Entrada CX", "Entregue CX", "Programado CX", "Cob estoque CX", "Cob produção fill CX"])
    ws2.column_dimensions["B"].width = 18
    for j in range(3, 24):
        ws2.column_dimensions[L(j)].width = 12.5
    for j in range(24, 26):
        ws2.column_dimensions[L(j)].width = 2
    for j in range(26, 31):
        ws2.column_dimensions[L(j)].width = 12
    ws2.column_dimensions["A"].width = 2
    for k_ in range(6, fim + 1):
        ws2.cell(k_, 31, f"=IF(Z{k_}=0,0,AA{k_}/Z{k_})").number_format = "0%"
        ws2.cell(k_, 32, f"=IF(Z{k_}=0,0,AB{k_}/Z{k_})").number_format = "0%"
        ws2.cell(k_, 33, f"=IF(Z{k_}=0,0,AC{k_}/Z{k_})").number_format = "0%"
        ws2.cell(k_, 34, f"=IF(Z{k_}=0,0,AD{k_}/Z{k_})").number_format = "0%"
    for j in range(26, 35):
        ws2.column_dimensions[L(j)].hidden = True
    ws2.freeze_panes = "C6"
    ws2.auto_filter.ref = f"B5:W{fim}"
    _bars(ws2, f"O6:R{fim}")
    _bars(ws2, f"U6:U{fim}")
    # breakdown rede × tipo
    r2 = rr + 3
    _merge(ws2, f"B{r2}:M{r2}", value="Por rede e tipo (CD / VD)", bold=True, size=12, color=NAVY)
    _head(ws2, r2 + 1, 2, ["Rede", "Tipo", "Pedidos", "Entrada", "Entregue", "Marcado", "Pendente", "Qualificado total",
                           "Qualificado (estoque)", "Cob. produção", "Não atendido", "% Entregue", "Fill Real"])
    ws2.row_dimensions[r2 + 1].height = 32
    r3 = r2 + 2
    for rd in redes:
        for tp in ("CD", "VD"):
            ls = [x for x in linhas if x["rede"] == rd and x["tipo"] == tp]
            if not ls:
                continue
            e = soma(ls, "ent_f")
            vals = [rd, tp, len({(x["eg"], x["pedido"]) for x in ls}), soma(ls, "entrada_plt"),
                    soma(ls, "entregue_plt"), soma(ls, "programado_plt"), soma(ls, "pendente_plt"),
                    soma(ls, "qualificado_plt") + soma(ls, "cob_producao_plt"), soma(ls, "qualificado_plt"), soma(ls, "cob_producao_plt"),
                    soma(ls, "descoberto_plt"), (soma(ls, "entg_f") / e if e else 0),
                    ((soma(ls, "entg_f") + soma(ls, "prog_f")) / e if e else 0)]
            for j, val in enumerate(vals, 2):
                _cell(ws2, f"{L(j)}{r3}", val, border=True, h="left" if j <= 3 else ("center" if j >= 13 else "right"),
                      fmt=(F_PCT if j >= 13 else (F_PLT if j >= 5 else (F_CX if j == 4 else None))))
            r3 += 1
    _bars(ws2, f"M{r2+2}:N{r3-1}")
    # gráfico: composição do pendente por rede
    ch = BarChart()
    ch.type, ch.grouping, ch.overlap, ch.gapWidth = "bar", "stacked", 100, 45
    ch.style = 10
    ch.legend.position = "b"
    ch.x_axis.delete = False
    ch.y_axis.delete = False
    ch.x_axis.scaling.orientation = "maxMin"
    ch.x_axis.tickLblPos = "low"
    ch.y_axis.number_format = "#,##0"
    ch.x_axis.txPr = _txt(800)
    ch.y_axis.txPr = _txt(800)
    ch.y_axis.majorGridlines.spPr = GraphicalProperties(ln=None)
    for col, color, name in ((10, GREEN, "Qualificado (estoque)"), (11, PURPLE, "Cobertura por produção"), (12, "E57373", "Não atendido")):
        s = Series(Reference(ws2, min_col=col, min_row=6, max_row=fim), title=name)
        s.graphicalProperties.solidFill = color
        s.graphicalProperties.line.solidFill = color
        ch.series.append(s)
    ch.set_categories(Reference(ws2, min_col=2, min_row=6, max_row=fim))
    ch.title = "Pendente por rede (PLT): estoque, produção e não atendido"
    alt = max(9.5, 0.7 * len(redes) + 3)
    ch.width, ch.height = 15.5, alt
    ws2.add_chart(ch, f"I{r3 + 2}")
    _merge(ws2, f"B{r3 + 1}:G{r3 + 1}", value="Todas as redes: do entregue ao melhor cenário (% da entrada)", bold=True, size=10, color=NAVY)
    _stack_chart(ws2, ws2, 6, fim, 2, [(31, GREEN, "Entregue"), (32, BLUE, "+ Marcado"), (33, AMBER, "+ Estoque hoje"), (34, PURPLE, "+ Produção")],
                 f"B{r3 + 2}", 15.5, height=alt)

    # ================================================================ Por_SKU
    s = s_sku
    _cabecalho(s, "Visão por SKU", f"Data de referência: {data_ref.strftime('%d/%m/%Y')}   ·   PLT   ·   escolha rede e tipo", ate="M")
    for k, w in {"A": 2, "B": 14, "C": 28, "D": 11, "E": 11, "F": 11, "G": 11, "H": 11, "I": 11, "J": 11, "K": 11, "L": 11, "M": 11}.items():
        s.column_dimensions[k].width = w
    s.row_dimensions[5].height = 26
    _cell(s, "B5", "Rede ▾", bold=True, color=NAVY, h="right")
    _cell(s, "C5", rede_padrao, bold=True, size=12, color=NAVY, bg="FFF8E1", border=True, h="center")
    _cell(s, "F5", "Tipo ▾", bold=True, color=NAVY, h="right")
    _merge(s, "G5:H5", value="Todos", bold=True, size=12, color=NAVY, bg="FFF8E1", border=True, h="center")
    _dv(s, "C5", f"=Listas!$A$1:$A${n_redes_l}")
    _dv(s, "G5", "=Listas!$B$1:$B$3")
    _merge(s, "I5:M5", value="← escolha nas listas; tabela, gráfico e detalhe se atualizam", italic=True, size=9, color="777777")
    _merge(s, "B7:M7", value="Maiores SKUs por pendente (até 30)", bold=True, size=12, color=NAVY)
    _head(s, 8, 2, ["SKU EG", "Descrição", "Linhas c/ pendente", "Pendente", "Qualificado (estoque)", "Cob. produção",
                    "Não atendido", "% não atendido", "Sem estoque (linhas)", "Não fecha carro (linhas)", "Estoque crítico (linhas)",
                    "Sem produção (linhas)"])
    s.row_dimensions[8].height = 42
    for k in range(N_SKU):
        r = 9 + k
        ix = f"Calc_Painel!$C${r_sku + k}"
        _cell(s, f"B{r}", f'=IF({ix}=0,"",INDEX({rs("A")},{ix}))', size=9)
        _cell(s, f"C{r}", f'=IF({ix}=0,"",INDEX({rs("B")},{ix}))', size=9)
        _cell(s, f"D{r}", f'=IF({ix}=0,"",INDEX({rs("C")},{ix}))', size=9, fmt=F_CX, h="center")
        for col, src in zip("EFGH", "DEFG"):
            _cell(s, f"{col}{r}", f'=IF({ix}=0,"",INDEX({rs(src)},{ix}))', size=9, fmt=F_PLT, h="right")
        _cell(s, f"I{r}", f'=IF({ix}=0,"",IF(E{r}=0,0,H{r}/E{r}))', size=9, fmt=F_PCT, h="center")
        for col, src in zip("JKLM", "HIJK"):
            _cell(s, f"{col}{r}", f'=IF({ix}=0,"",INDEX({rs(src)},{ix}))', size=9, fmt=F_CX, h="center")
        if k % 2:
            for col in "BCDEFGHIJKLM":
                s[f"{col}{r}"].fill = _fill(GRAY_BG)
    s.conditional_formatting.add(f"I9:I{8+N_SKU}", DataBarRule(start_type="num", start_value=0, end_type="num", end_value=1, color="E57373"))
    r_ch = 8 + N_SKU + 2          # 40
    _merge(s, f"B{r_ch}:M{r_ch}", value="Top 12 SKUs por pendente: como o pendente está coberto (% do pendente)", bold=True, size=12, color=NAVY)
    _stack_chart(s, calc, r_sku_chart, r_sku_chart + 11, 4,
                 [(5, GREEN, "Qualificado (estoque)"), (6, PURPLE, "Produção"), (7, "E57373", "Não atendido")],
                 f"B{r_ch + 1}", 24)
    r_sel = r_ch + 1 + 24          # linha do seletor de SKU (deve bater com SKU_SEL_ROW)
    assert r_sel == SKU_SEL_ROW, (r_sel, SKU_SEL_ROW)
    _merge(s, f"B{r_sel-1}:M{r_sel-1}", value="Quem pede o SKU escolhido (até 25 linhas)", bold=True, size=12, color=NAVY)
    _cell(s, f"B{r_sel}", "SKU ▾", bold=True, color=NAVY, h="right")
    _merge(s, f"C{r_sel}:H{r_sel}", value=sku_lab[skus[0]] if skus else "", bold=True, size=11, color=NAVY, bg="FFF8E1", border=True)
    _dv(s, f"C{r_sel}", f"=Listas!$D$1:$D${max(len(skus), 1)}")
    _merge(s, f"I{r_sel}:M{r_sel}", value="← escolha um SKU (respeita rede e tipo acima)", italic=True, size=9, color="777777")
    _head(s, r_sel + 2, 2, ["Rede", "Cliente", "Pedido", "Pendente", "Qualificado", "Cob. produção", "Não atendido", "Origem",
                            "Situação", "Motivo", "Alertas", ""])
    s.row_dimensions[r_sel + 2].height = 30
    for k in range(N_SKU_DET):
        r = r_sel + 3 + k
        ix = f"Calc_Painel!$C${r_skud + k}"
        ex = f"Calc_Painel!$B${r_skud + k}"
        g = lambda cid: f'INDEX({rl(cid)},{ix})'
        _cell(s, f"B{r}", f'=IF({ex}=0,"",{g("rede")})', size=9)
        _cell(s, f"C{r}", f'=IF({ex}=0,"",TRIM(SUBSTITUTE({g("nome")},{g("rede")}&" ","")))', size=9)
        _cell(s, f"D{r}", f'=IF({ex}=0,"",{g("pedido")})', size=9, h="center")
        for col, cid in zip("EFGH", ["pend_p", "qual_p", "cprod_p", "descob_p"]):
            _cell(s, f"{col}{r}", f'=IF({ex}=0,"",{g(cid)})', size=9, fmt=F_PLT, h="right")
        _cell(s, f"I{r}", f'=IF({ex}=0,"",{g("origem")}&"")', size=9, h="center")
        _cell(s, f"J{r}", f'=IF({ex}=0,"",{g("situacao")}&"")', size=9)
        _cell(s, f"K{r}", f'=IF({ex}=0,"",{g("motivo")}&"")', size=9)
        _merge(s, f"L{r}:M{r}", value=f'=IF({ex}=0,"",{g("alertas")}&"")', size=8, color="9A3412")
        if k % 2:
            for col in "BCDEFGHIJK":
                s[f"{col}{r}"].fill = _fill(GRAY_BG)

    # ================================================================ Lojas_VD
    s = s_loja
    _cabecalho(s, "Lojas VD por rede", f"Data de referência: {data_ref.strftime('%d/%m/%Y')}   ·   Fill Rate VD = lojas atendidas ÷ total de lojas (não é percentual de volume)", ate="M")
    for k, w in {"A": 2, "B": 30, "C": 13, "D": 13, "E": 13, "F": 13, "G": 9, "H": 30, "I": 13, "J": 13, "K": 13, "L": 13, "M": 13, "N": 13, "O": 13}.items():
        s.column_dimensions[k].width = w
    s.row_dimensions[5].height = 26
    _cell(s, "B5", "Rede ▾", bold=True, color=NAVY, h="right")
    _cell(s, "C5", loja_padrao or (redes_vd[0] if redes_vd else ""), bold=True, size=12, color=NAVY, bg="FFF8E1", border=True, h="center")
    s["C5"].alignment = Alignment(horizontal="center", vertical="center")
    _dv(s, "C5", f"=Listas!$C$1:$C${max(len(redes_vd), 1)}")
    _merge(s, "D5:F5", value="← uma rede por vez (redes nunca se misturam)", italic=True, size=9, color="777777")
    _cell(s, "H5", "Pendente de palete (vales) da rede:", bold=True, size=9, color=NAVY, h="right")
    _cell(s, "I5", f'=SUMIFS(Listas!$H$2:$H${len(redes)+1},Listas!$G$2:$G${len(redes)+1},$C$5)', bold=True, size=12, fmt="#,##0", h="center", bg="E8F5E9")
    _cell(s, "J5", "chapatex:", bold=True, size=9, color=NAVY, h="right")
    _cell(s, "K5", f'=SUMIFS(Listas!$I$2:$I${len(redes)+1},Listas!$G$2:$G${len(redes)+1},$C$5)', bold=True, size=12, fmt="#,##0", h="center", bg="E8F5E9")
    for r in (7, 8, 9, 10):
        s.row_dimensions[r].height = 18 if r in (7, 10) else 22
    _card(s, "B", "B", 7, "Lojas da rede", f'=COUNTIFS({rj("A")},$C$5)', F_CX, "lojas VD")
    _card(s, "C", "D", 7, "Lojas atendidas", f'=COUNTIFS({rj("A")},$C$5,{rj("H")},">0")', F_CX, "com volume entregue")
    _card(s, "E", "F", 7, "Fill Rate VD", '=IF(B8=0,0,C8/B8)', F_PCT, "lojas atendidas ÷ lojas")
    _card(s, "H", "H", 7, "Entregue / Entrada (PLT)", f'=SUMIFS({rj("E")},{rj("A")},$C$5)', F_PLT,
          f'="de "&TEXT(SUMIFS({rj("D")},{rj("A")},$C$5),"0.0")&" PLT de entrada"')
    _fill_cf(s, "E8")
    _merge(s, "B12:H12", value="Lojas (até 40 maiores por entrada)  ·  ▲ entregou e pendente > 2 PLT (possível 2ª entrega)  ·  ✓ entregou e pendente ≤ 2 PLT  ·  ○ sem entrega",
           bold=True, size=10, color=NAVY)
    _head(s, 13, 2, ["Loja", "Entrada PLT", "Entregue PLT", "Pendente PLT", "Fill (PLT)", "Sinal", "Status"])
    for k in range(N_LOJA):
        r = 14 + k
        ix = f"Calc_Painel!$C${r_loja + k}"
        _cell(s, f"B{r}", f'=IF({ix}=0,"",INDEX({rj("M")},{ix}))', size=9)
        for col, src in zip("CDE", "DEF"):
            _cell(s, f"{col}{r}", f'=IF({ix}=0,"",INDEX({rj(src)},{ix}))', size=9, fmt=F_PLT, h="right")
        _cell(s, f"F{r}", f'=IF({ix}=0,"",IF(C{r}=0,0,D{r}/C{r}))', size=9, fmt=F_PCT, h="center")
        _cell(s, f"G{r}", f'=IF({ix}=0,"",INDEX({rj("K")},{ix}))', size=11, h="center", bold=True)
        _cell(s, f"H{r}", f'=IF({ix}=0,"",INDEX({rj("L")},{ix}))', size=9)
        if k % 2:
            for col in "BCDEFGH":
                s[f"{col}{r}"].fill = _fill(GRAY_BG)
    s.conditional_formatting.add(f"G14:G{13+N_LOJA}", FormulaRule(formula=['G14="▲"'], font=Font(name=FONT, bold=True, color="EF6C00", size=11)))
    s.conditional_formatting.add(f"G14:G{13+N_LOJA}", FormulaRule(formula=['G14="✓"'], font=Font(name=FONT, bold=True, color=GREEN, size=11)))
    s.conditional_formatting.add(f"G14:G{13+N_LOJA}", FormulaRule(formula=['G14="○"'], font=Font(name=FONT, bold=True, color="C62828", size=11)))
    _bars(s, f"F14:F{13+N_LOJA}")
    _stack_chart(s, calc, r_loja_chart, r_loja_chart + N_LOJA - 1, 4,
                 [(5, GREEN, "Entregue"), (6, BLUE, "+ Marcado"), (7, AMBER, "+ Estoque hoje"), (8, PURPLE, "+ Produção")],
                 "J12", 17, height=0.55 * N_LOJA + 2)
    _merge(s, "J11:M11", value="Todas as lojas da rede: do entregue ao melhor cenário (% da entrada)", bold=True, size=9, color=NAVY)

    # ================================================================ Por_Pedido (linha de pedido)
    s = s_ped
    s.sheet_view.showGridLines = False
    _merge(s, "A1:S1", value="Visão por pedido", bold=True, size=14, color="FFFFFF", bg=NAVY)
    s.row_dimensions[1].height = 26
    hp = ["Rede", "Tipo", "Cliente EG", "Nome", "Pedido ERP", "SKUs", "Captação (ou criação)", "Vencimento",
          "Entrada (PLT)", "Entregue (PLT)", "Marcado (PLT)", "Pendente (PLT)", "Qualificado (PLT)",
          "Cob. produção (PLT)", "Não atendido (PLT)", "% Entregue", "Fill Real", "Situação", "Alertas"]
    _head(s, 3, 1, hp)
    s.row_dimensions[3].height = 32
    s.sheet_properties.outlinePr.summaryBelow = False       # linha-resumo do pedido em cima; SKUs agrupados embaixo
    r = 4
    for (eg, pd_), ls in ped_list:
        x0 = ls[0]
        e = soma(ls, "entrada")
        venc = min([x["venc"] for x in ls if x["venc"]], default=None)
        capt = min([x["captacao_final"] for x in ls if x.get("captacao_final")], default=None)
        als = sorted({a_.strip() for x in ls for a_ in x["alertas"].split(";") if a_.strip()})
        pend = soma(ls, "pendente")
        qual = soma(ls, "qualificado")
        sit = "Sem pendente" if pend <= 0 else ("Qualificado" if qual >= pend else ("Qualificado parcial" if qual > 0 else "Não qualificado"))

        def linha_ped(r_, vals_, sit_, alert_, resumo, cx3):
            for j, val in enumerate(vals_, 1):
                _cell(s, f"{L(j)}{r_}", val, size=9 if resumo else 8, bold=resumo, border=True,
                      color=None if resumo else "666666", bg=("E8EEF5" if resumo else None),
                      h="left" if j <= 6 else ("center" if j <= 8 else "right"),
                      fmt=("dd/mm/yyyy" if j in (7, 8) else (F_PLT if j >= 9 else None)))
            for j, val in zip((20, 21, 22), cx3):
                s.cell(r_, j, val)
            _cell(s, f"P{r_}", f"=IF(T{r_}=0,0,U{r_}/T{r_})", size=9 if resumo else 8, fmt=F_PCT, h="center", border=True, bold=resumo)
            _cell(s, f"Q{r_}", f"=IF(T{r_}=0,0,(U{r_}+V{r_})/T{r_})", size=9 if resumo else 8, fmt=F_PCT, h="center", border=True, bold=resumo)
            _cell(s, f"R{r_}", sit_, size=9 if resumo else 8, border=True, bold=resumo)
            _cell(s, f"S{r_}", alert_, size=8, color="9A3412", border=True)

        linha_ped(r, [x0["rede"], x0["tipo"], eg, x0["loja"], pd_, len(ls), capt, venc, soma(ls, "entrada_plt"),
                      soma(ls, "entregue_plt"), soma(ls, "programado_plt"), soma(ls, "pendente_plt"),
                      soma(ls, "qualificado_plt"), soma(ls, "cob_producao_plt"),
                      soma(ls, "descoberto_plt")], sit, "; ".join(als), True,
                  (soma(ls, "ent_f"), soma(ls, "entg_f"), soma(ls, "prog_f")))
        r += 1
        for x in sorted(ls, key=lambda y: y["sku_eg"]):
            linha_ped(r, [x["rede"], x["tipo"], eg, x["loja"], pd_, f"{x['sku_eg']} · {x['descricao']}", x.get("captacao_final"),
                          x["venc"], x["entrada_plt"], x["entregue_plt"], x["programado_plt"], x["pendente_plt"],
                          x["qualificado_plt"], x["cob_producao_plt"], x["descoberto_plt"]],
                      x["situacao"], x["alertas"] if not x["motivo"] else (x["motivo"] + ("; " + x["alertas"] if x["alertas"] else "")),
                      False, (x["ent_f"], x["entg_f"], x["prog_f"]))
            s.row_dimensions[r].outlineLevel = 1
            s.row_dimensions[r].hidden = True              # recolhido: clique no + para abrir os SKUs
            r += 1
    endp = r - 1
    for j, w in enumerate([14, 7, 11, 24, 12, 34, 13, 12, 11, 11, 11, 11, 12, 12, 12, 10, 10, 18, 44], 1):
        s.column_dimensions[L(j)].width = w
    for col in ("T", "U", "V"):
        s.column_dimensions[col].hidden = True
    s.freeze_panes = "G4"
    s.auto_filter.ref = f"A3:S{endp}"
    _bars(s, f"P4:Q{endp}")

    # ================================================================ Pedido_Linhas (dropdown de pedido)
    s = s_pl
    _cabecalho(s, "Linha a linha do pedido", f"Data de referência: {data_ref.strftime('%d/%m/%Y')}   ·   escolha o pedido e veja cada SKU", ate="M")
    for k, w in {"A": 2, "B": 12, "C": 30, "D": 11, "E": 11, "F": 11, "G": 11, "H": 11, "I": 11, "J": 11, "K": 11,
                 "L": 20, "M": 40}.items():
        s.column_dimensions[k].width = w
    s.row_dimensions[5].height = 26
    _cell(s, "B5", "Pedido ▾", bold=True, color=NAVY, h="right")
    _merge(s, "C5:G5", value=peds[0] if peds else "", bold=True, size=11, color=NAVY, bg="FFF8E1", border=True)
    _dv(s, "C5", f"=Listas!$E$1:$E${max(len(peds), 1)}")
    _merge(s, "H5:M5", value="← Rede · Cliente · Pedido", italic=True, size=9, color="777777")
    _head(s, 7, 2, ["SKU EG", "Descrição", "Entrada (PLT)", "Entregue", "Marcado", "Pendente",
                    "Qualificado", "Cob. produção", "Não atendido", "Origem", "Situação", "Motivo / alertas"])
    s.row_dimensions[7].height = 30
    for k in range(N_PED_LIN):
        r = 8 + k
        ix = f"Calc_Painel!$C${r_pl + k}"
        ex = f"Calc_Painel!$B${r_pl + k}"
        g = lambda cid: f'INDEX({rl(cid)},{ix})'
        _cell(s, f"B{r}", f'=IF({ex}=0,"",{g("sku")})', size=9)
        _cell(s, f"C{r}", f'=IF({ex}=0,"",{g("desc")})', size=9)
        for col, cid in zip("DEFGHIJ", ["ent_p", "entg_p", "prog_p", "pend_p", "qual_p", "cprod_p", "descob_p"]):
            _cell(s, f"{col}{r}", f'=IF({ex}=0,"",{g(cid)})', size=9, fmt=F_PLT, h="right")
        _cell(s, f"K{r}", f'=IF({ex}=0,"",{g("origem")}&"")', size=9, h="center")
        _cell(s, f"L{r}", f'=IF({ex}=0,"",{g("situacao")}&"")', size=9)
        _cell(s, f"M{r}", f'=IF({ex}=0,"",{g("motivo")}&""&IF({g("alertas")}&""="",""," · "&{g("alertas")}))', size=8, color="9A3412")
        if k % 2:
            for col in "BCDEFGHIJKLM":
                s[f"{col}{r}"].fill = _fill(GRAY_BG)
    s.conditional_formatting.add(f"L8:L{7+N_PED_LIN}", FormulaRule(formula=['L8="Qualificado"'], font=Font(name=FONT, color=GREEN, bold=True, size=9)))
    s.conditional_formatting.add(f"L8:L{7+N_PED_LIN}", FormulaRule(formula=['L8="Não qualificado"'], font=Font(name=FONT, color="C62828", bold=True, size=9)))
    s.conditional_formatting.add(f"L8:L{7+N_PED_LIN}", FormulaRule(formula=['L8="Qualificado parcial"'], font=Font(name=FONT, color="EF6C00", bold=True, size=9)))

    # ================================================================ Qualificado (linha a linha, spec)
    s = s_q
    s.sheet_view.showGridLines = False
    D_, X_, P_ = "d", "x", "p"      # tipos de formato: data, CX, PLT
    qcols = [
        ("Grupo (rede)", lambda x: x["rede"], None, 14), ("Tipo (CD/VD)", lambda x: x["tipo"], None, 8),
        ("Tipo de origem", lambda x: x["tipo_origem"], None, 10), ("Cliente EG", lambda x: x["eg"], None, 11),
        ("Cliente SAP", lambda x: x["sap"], None, 11), ("Nome da loja", lambda x: x["loja"], None, 26),
        ("Pedido ERP", lambda x: x["pedido"], None, 12), ("SKU EG", lambda x: x["sku_eg"], None, 10),
        ("SKU SAP", lambda x: x["sku_sap"], None, 10), ("SKU S4", lambda x: x["s4"], None, 10),
        ("Descrição", lambda x: x["descricao"], None, 26), ("Origem", lambda x: x["origem"], None, 9),
        ("Nome da origem", lambda x: x["origem_nome"], None, 15), ("Data de criação", lambda x: x["criacao"], D_, 11),
        ("Data de captação final", lambda x: x["captacao_final"], D_, 11),
        ("Fonte da data de captação", lambda x: x["fonte_captacao"], None, 22),
        ("Data de vencimento", lambda x: x["venc"], D_, 11), ("CX por PLT (CAD)", lambda x: x["fator"], X_, 9),
        ("Entrada CX", lambda x: x["entrada"], X_, 10), ("Entrada PLT", lambda x: x["entrada_plt"], P_, 10),
        ("Entregue CX", lambda x: x["entregue"], X_, 10), ("Programado CX", lambda x: x["programado"], X_, 10),
        ("Pendente CX", lambda x: x["pendente"], X_, 10), ("Pendente PLT", lambda x: x["pendente_plt"], P_, 10),
        ("Estoque disponível CX", lambda x: x["estoque_cx"] if x["estoque_cx"] else (0 if x["pendente"] > 0 else None), X_, 11),
        ("Estoque disponível PLT", lambda x: x["estoque_plt"], P_, 11), ("Estoque crítico", lambda x: x["estoque_critico"], None, 9),
        ("Estoque disputado", lambda x: x["disputa"], None, 9), ("Fecha carro", lambda x: x["fecha_carro"], None, 9),
        ("Volume do cliente na origem (PLT)", lambda x: x["vol_cliente_origem"], P_, 12),
        ("Nº origens válidas", lambda x: x["n_origens_validas"], None, 9),
        ("Origens possíveis na malha", lambda x: x["origens_possiveis"], None, 14),
        ("Qualificado hoje CX", lambda x: x["qualificado"], X_, 11), ("Qualificado hoje PLT", lambda x: x["qualificado_plt"], P_, 11),
        ("Produção válida até o vencimento", lambda x: x["producao_valida"], None, 11),
        ("Próxima produção válida", lambda x: x["prox_producao"], D_, 11),
        ("Cobertura por produção CX", lambda x: x["cob_producao"], X_, 11), ("Cobertura por produção PLT", lambda x: x["cob_producao_plt"], P_, 11),
        ("Não atendido provável CX", lambda x: x["descoberto"], X_, 11), ("Não atendido provável PLT", lambda x: x["descoberto_plt"], P_, 11),
        ("Situação", lambda x: x["situacao"], None, 17), ("Motivo da não qualificação", lambda x: x["motivo"], None, 26),
        ("Alertas (inclui validade D+2)", lambda x: x["alertas"], None, 40), ("Speed DRP", lambda x: x["speed_drp"], None, 10),
        ("Agenda de referência", lambda x: x["agenda_ref"], D_, 11), ("Data de entrega (faturado)", lambda x: x["data_entrega"], D_, 11),
        ("Qtd. atualizada (AQ)", lambda x: x["qtd_atual"], X_, 10), ("Carro s/ remessa (AT)", lambda x: x["sem_remessa"], X_, 10),
        ("Carro c/ remessa (AU)", lambda x: x["com_remessa"], X_, 10), ("Faturado (AV)", lambda x: x["faturado"], X_, 10),
        ("Fracionado (<1 PLT)", lambda x: ("Sim · VD não entrega" if x["frac_vd"] else ("Sim · CD entrega" if x["fracionado"] else "Não")), None, 14),
        ("Entrada p/ fill CX", lambda x: x["ent_f"], X_, 10), ("Entregue p/ fill CX", lambda x: x["entg_f"], X_, 10),
        ("Programado p/ fill CX", lambda x: x["prog_f"], X_, 10), ("Cobertura estoque p/ fill CX", lambda x: x["cob_estoque"], X_, 11),
        ("Cobertura produção p/ fill CX", lambda x: x["cob_prod_fill"], X_, 11),
    ]
    nq = len(qcols)
    qi = {h: j for j, (h, *_r) in enumerate(qcols, 1)}
    hq = [h for h, *_r in qcols] + ["% Entregue", "Fill Real (entregue + marcado)", "Fill c/ estoque hoje", "Fill c/ produção", "Não atendido (provável)"]
    FR0 = 6                                  # 1ª linha de dados (acima: resumo da seleção filtrada)
    last_q = FR0 + len(linhas) - 1
    _head(s, 5, 1, hq)
    s.row_dimensions[5].height = 46
    cE, cG, cP, cS, cR = (L(qi[h]) for h in ("Entrada p/ fill CX", "Entregue p/ fill CX", "Programado p/ fill CX",
                                                "Cobertura estoque p/ fill CX", "Cobertura produção p/ fill CX"))
    for i, x in enumerate(linhas):
        r = FR0 + i
        for j, (h, fn, kind, w) in enumerate(qcols, 1):
            val = fn(x)
            if val is None or val == "":
                continue
            c = s.cell(r, j, val)
            if kind == D_ or isinstance(val, dt.date):
                c.number_format = "dd/mm/yyyy"
            elif kind == X_:
                c.number_format = F_CX
            elif kind == P_:
                c.number_format = F_PLT
        f0 = nq + 1
        for k, f in enumerate((f"{cG}{r}", f"{cG}{r}+{cP}{r}", f"{cG}{r}+{cP}{r}+{cS}{r}", f"{cG}{r}+{cP}{r}+{cS}{r}+{cR}{r}")):
            if k == 0:
                fx = f'=IF({cE}{r}=0,"",MIN(1,({cG}{r})/{cE}{r}))'
            else:
                fx = f'=IF({cE}{r}=0,"",MIN(1,({f})/{cE}{r}))'
            s.cell(r, f0 + k, fx).number_format = F_PCT
        s.cell(r, f0 + 4, f'=IF({cE}{r}=0,"",1-{L(f0 + 3)}{r})').number_format = F_PCT
    for j, (h, fn, kind, w) in enumerate(qcols, 1):
        s.column_dimensions[L(j)].width = w
    for j in range(nq + 1, nq + 6):
        s.column_dimensions[L(j)].width = 13
    s.freeze_panes = f"H{FR0}"
    s.auto_filter.ref = f"A5:{L(len(hq))}{last_q}"
    # ---- Fill da seleção FILTRADA (SUBTOTAL só soma as linhas visíveis: filtre por cliente, SKU, pedido...)
    _merge(s, "A1:N1", value="Fill da seleção filtrada: use os filtros da linha 5 (cliente, SKU, pedido, rede...) e os números abaixo se atualizam",
           bold=True, size=11, color=NAVY)
    rngq = lambda col: f"{col}${FR0}:{col}${last_q}"
    labs = ["Entrada p/ fill (CX)", "Entregue (CX)", "Marcado (CX)", "Cob. estoque (CX)", "Cob. produção (CX)",
            "% Entregue", "Fill Real (entregue + marcado)", "Fill c/ estoque hoje", "Fill c/ produção", "Não atendido (provável)"]
    _head(s, 2, 1, labs)
    s.row_dimensions[2].height = 32
    sub = lambda col: f"SUBTOTAL(109,{rngq(col)})"
    for j, col in enumerate((cE, cG, cP, cS, cR), 1):
        _cell(s, f"{L(j)}3", f"={sub(col)}", fmt=F_CX, bold=True, h="center", bg=GRAY_BG, border=True)
    e3 = "$A$3"
    for j, f in zip(range(6, 10), ("$B$3", "$B$3+$C$3", "$B$3+$C$3+$D$3", "$B$3+$C$3+$D$3+$E$3")):
        _cell(s, f"{L(j)}3", f"=IF({e3}=0,0,MIN(1,({f})/{e3}))", fmt=F_PCT, bold=True, h="center", bg=GRAY_BG, border=True)
    _cell(s, "J3", f"=IF({e3}=0,0,1-I3)", fmt=F_PCT, bold=True, h="center", bg=GRAY_BG, border=True)
    _cell(s, "F3", f"=IF({e3}=0,0,MIN(1,$B$3/{e3}))", fmt=F_PCT, bold=True, h="center", bg=GRAY_BG, border=True)
    s.row_dimensions[3].height = 24
    s.conditional_formatting.add(f"{L(nq + 2)}{FR0}:{L(nq + 5)}{last_q}", DataBarRule(start_type="num", start_value=0, end_type="num", end_value=1, color="66BB6A"))
    sit_col = L(hq.index("Situação") + 1)
    rng_s = f"{sit_col}{FR0}:{sit_col}{last_q}"
    s.conditional_formatting.add(rng_s, FormulaRule(formula=[f'{sit_col}{FR0}="Qualificado"'], font=Font(name=FONT, color=GREEN, bold=True)))
    s.conditional_formatting.add(rng_s, FormulaRule(formula=[f'{sit_col}{FR0}="Não qualificado"'], font=Font(name=FONT, color="C62828", bold=True)))
    s.conditional_formatting.add(rng_s, FormulaRule(formula=[f'{sit_col}{FR0}="Qualificado parcial"'], font=Font(name=FONT, color="EF6C00", bold=True)))

    # ================================================================ Como_Funciona
    s = s_cf
    s.sheet_view.showGridLines = False
    s.column_dimensions["A"].width = 26
    s.column_dimensions["B"].width = 120
    _merge(s, "A1:B1", value="Como a análise funciona (passo a passo)", bold=True, size=14, color="FFFFFF", bg=NAVY)
    s.row_dimensions[1].height = 26
    for i, (t, d) in enumerate(PASSOS, 3):
        _cell(s, f"A{i}", t, bold=True, color=NAVY, v="top", wrap=True)
        _cell(s, f"B{i}", d, v="top", wrap=True)
        s.row_dimensions[i].height = 18 * (1 + len(d) // 125)

    # ================================================================ Fora_Carteira / Auditoria / Conferências
    _head(fc, 1, 1, ["Linha na aba Marcado", "Cliente EG", "Pedido ERP", "SKU EG", "Qtd CX", "Agenda", "Speed DRP", "Motivo"])
    for i, f in enumerate(res["fora_carteira"], 2):
        for j, k in enumerate(["linha", "cliente_eg", "pedido", "sku_eg", "qtd_cx", "agenda", "speed_drp", "motivo"], 1):
            fc.cell(i, j, f.get(k))
    _head(au, 1, 1, ["Categoria", "Ocorrências", "Detalhe"])
    ra = 2
    for nome, st in res["abas"]:
        au.cell(ra, 1, "Abas"); au.cell(ra, 2, 1); au.cell(ra, 3, f"{nome}: {st}")
        ra += 1
    for av in res["avisos"]:
        au.cell(ra, 1, "Aviso"); au.cell(ra, 2, 1); au.cell(ra, 3, av)
        ra += 1
    for cat, itens in sorted(res["auditoria"].items()):
        for it in itens[:300]:
            au.cell(ra, 1, cat)
            au.cell(ra, 2, len(itens))
            au.cell(ra, 3, "; ".join(f"{k}={v}" for k, v in it.items()))
            ra += 1
    au.column_dimensions["A"].width = 44
    au.column_dimensions["C"].width = 120
    au.auto_filter.ref = f"A1:C{ra-1}"
    _head(cj, 1, 1, ["Conferência", "Resultado", "Detalhe"])
    for i, (nm, ok, det) in enumerate(res["conferencias"], 2):
        cj.cell(i, 1, nm); cj.cell(i, 2, "OK" if ok else "ALERTA"); cj.cell(i, 3, det)
    cj.column_dimensions["A"].width = 60
    for sh in (fc, au, cj, bl, bp, bc, br, bs, bj):
        sh.freeze_panes = "A2"

    for sh_ in (s_rede, s_sku, s_loja, s_pl, s_cf, s_ped):
        sh_.page_setup.orientation = "landscape"
        sh_.page_setup.fitToWidth, sh_.page_setup.fitToHeight = 1, 0
        sh_.sheet_properties.pageSetUpPr.fitToPage = True
    for nm in ("Base_Linha", "Base_Pedido", "Base_Cliente", "Base_Rede", "Base_SKU", "Base_SKUP", "Base_Orig", "Base_Loja", "Calc_Painel",
               "Listas", "Fora_Carteira", "Auditoria", "Conferencias"):
        wb[nm].sheet_state = "hidden"
    wb.active = 0
    wb.save(out_path)
    return out_path
