# -*- coding: utf-8 -*-
"""Cálculo da Carteira Reversa (v4).

Lê as abas pelo NOME (nunca pela posição), monta uma linha por chave
(Cliente EG + Pedido ERP + SKU EG) e calcula entrada, entregue, programado,
pendente, qualificação (estoque fábrica/CDD, carro 24-28 PLT), produção e fill rates.

Uso:  from calculo import processar
      res = processar(["Base.xlsx"], data_ref=date(2026,10,15))
"""
import datetime as dt
import math
import re
import unicodedata
from collections import defaultdict

import openpyxl
from openpyxl.utils import column_index_from_string as ci

# ----------------------------------------------------------------- parâmetros
MIN_CARRO, MIN_CARRO_EXC, MAX_CARRO = 24.0, 22.0, 28.0
LIM_CRITICO_FABRICA_PLT = 50.0
MULT_CRITICO_CDD = 20
DIAS_ALERTA_VALIDADE = 2
# Clientes e tipo (único ponto a editar; no agente vem do descritivo via --clientes "NOME=TIPO;...").
# NOME = nome exato da loja OU trecho do nome da rede. A loja exata tem prioridade sobre a rede.
CLIENTES_PADRAO = [("949698", "VD"), ("CD SHIBATA", "VD"), ("BARBOSA", "VD"), ("LOPES", "VD"), ("NAGUMO", "VD"),
                   ("SONDA", "VD"), ("RHODIA", "VD"), ("SHIBATA", "CD")]


def parse_clientes(txt):
    """'BARBOSA=VD; SHIBATA=CD' -> [('BARBOSA','VD'), ('SHIBATA','CD')]"""
    out = []
    for p_ in re.split(r"[;\n]", txt or ""):
        if "=" in p_:
            n, t = p_.rsplit("=", 1)
            if n.strip() and t.strip().upper() in ("VD", "CD"):
                out.append((norm(n).upper(), t.strip().upper()))
    return out


def tipo_cliente(clientes, loja, rede, eg=""):
    """VD / CD conforme a tabela de clientes; None se o cliente não está na tabela.
    Ordem: Cliente EG exato > nome da loja (igual ou começando por) > trecho do nome da rede."""
    nl, nr = norm(loja).upper(), norm(rede).upper()
    for n, t in clientes:
        if eg and n == str(eg).strip().upper():
            return t
    for n, t in clientes:
        if nl == n or nl.startswith(n + " "):
            return t
    for n, t in clientes:
        if n in nr:
            return t
    return None
REDES_ENTREGA_SO_FATURADO = {"SHIBATA"}   # VD Shibata: entregue = faturado
LIM_PEND_LOJA_PLT = 2.0
LIM_FRACIONADO_PLT = 1.0         # item com menos de 1 palete (pela CAD) é fracionado: só CD entrega
UNID_ESTOQUE_FABRICA = "PLT"     # D1 do Estoque Fabricas vem em paletes (decimais); "CX" se vier em caixas

# colunas fixas da Base Crua (letras)
COL_BASE = dict(pedido="B", comercial="G", rede="L", eg="M", sap="N", loja="O", sku_eg="Q", sku_sap="R",
                descricao="S", hl="U", plt="V", cx="W", criacao="Y", venc="Z", qtd_atual="AQ",
                sem_remessa="AT", com_remessa="AU", faturado="AV", captacao="BA")
COL_MARC = dict(eg="D", sap="E", nome="F", sku_eg="G", sku_sap="H", sku_nome="I",
                q1="J", q2="K", q3="L", speed="AH")
COL_CAD = dict(s4="A", eg="C", cx_plt="I")
COL_VALES = "AH"

ABAS_OBRIGATORIAS = ["Base Crua", "CAD"]
ABAS_ESPERADAS = ["Base Crua", "Marcado", "Malha", "CAD", "Estoque Fabricas", "Produção",
                  "DeParaCDD", "Planificador_Pallet", "Planificador_Chapatex", "Sheet3"]


# ----------------------------------------------------------------- utilidades
def norm(s):
    s = "" if s is None else str(s)
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = re.sub(r"[^A-Za-z0-9]+", " ", s).strip().lower()
    return s


def texto(v):
    """Código como texto (preserva zeros à esquerda; 123.0 -> 123)."""
    if v is None:
        return ""
    if isinstance(v, float):
        if math.isnan(v):
            return ""
        return str(int(v)) if v == int(v) else str(v)
    s = str(v).strip()
    if s.lower() in ("nan", "none", "nat", "null"):
        return ""
    if re.fullmatch(r"\d+\.0+", s):
        s = s.split(".")[0]
    return s


def numero(v):
    """Número no padrão brasileiro ou americano; vazio = 0."""
    if v is None or isinstance(v, bool):
        return 0.0
    if isinstance(v, (int, float)):
        return 0.0 if (isinstance(v, float) and math.isnan(v)) else float(v)
    s = str(v).strip().replace("\xa0", "").replace(" ", "")
    if s == "" or s.lower() in ("nan", "none", "-"):
        return 0.0
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()")
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    elif re.fullmatch(r"-?\d{1,3}(\.\d{3})+", s):
        s = s.replace(".", "")
    try:
        x = float(s)
    except ValueError:
        return 0.0
    return -x if neg else x


def data(v):
    """Data válida ou None. 01/01/0001, 01/01/1970, 30/12/1899, vazio e textos = sem data."""
    if v is None:
        return None
    d = None
    if isinstance(v, dt.datetime):
        d = v.date()
    elif isinstance(v, dt.date):
        d = v
    elif isinstance(v, (int, float)) and not isinstance(v, bool):
        if 30000 < v < 80000:
            d = (dt.datetime(1899, 12, 30) + dt.timedelta(days=float(v))).date()
    else:
        s = str(v).strip()
        for fmt in ("%d/%m/%Y", "%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%Y-%m-%d", "%Y-%m-%d %H:%M:%S",
                    "%d-%m-%Y", "%d/%m/%y"):
            try:
                d = dt.datetime.strptime(s, fmt).date()
                break
            except ValueError:
                continue
    if d is None or d.year < 2000 or d.year > 2100:
        return None
    return d


def fmt_data(d):
    return d.strftime("%d/%m/%Y") if d else ""


def origem_valida(v):
    s = texto(v)
    if not s:
        return ""
    n = norm(s)
    if n in ("", "nan", "none", "n a", "na", "0", "null") or "nan" in n.split():
        return ""
    return s.strip()


# De-para de origens: (nome, BR, centro, tipo, lista). Bloco "TRAVA COMERCIAL" ignorado.
# Pode ser substituído por uma aba "DeParaOrigem" (cabeçalhos: Nome origem, BR Origem, Codigo centro, Tipo Origem, Lista).
ORIGENS_PADRAO = [
    ("F. Rio Janeiro", "BR19", "185", "VD", "185-VD"), ("F. Jacarei", "BR16", "260", "VD", "260-VD"),
    ("CDR Extrema", "BRCH", "324", "VD", "324-VD"), ("CDR LOUVEIRA", "BRDF", "424", "VD", "424-VD"),
    ("F. CCL Pirai", "BR13", "781", "VD", "781-VD"), ("F. Nova Minas", "BR27", "803", "VD", "803-VD"),
    ("F. Jundiai", "BR15", "892", "VD", "892-VD"), ("F. Agudos", "BR09", "893", "VD", "893-VD"),
    ("F. Jaguariuna", "BR23", "952", "VD", "952-VD"),
    ("CDD Diadema DC", "BRCR", "216", "CD", "216-CD"), ("CDD Maua DC", "BRCX", "301", "CD", "301-CD"),
    ("CDI Louveira DC", "BRDF", "475", "CD", "475-CD"), ("CDD Presidente Prudente DC", "BRD0", "543", "CD", "543-CD"),
    ("CDD Praia Grande DC", "BRD7", "578", "CD", "578-CD"), ("CDD Araraquara DC", "BRCN", "763", "CD", "763-CD"),
    ("CDD Guarulhos DC", "BRCT", "764", "CD", "764-CD"), ("CDD Aracatuba DC", "BRCM", "811", "CD", "811-CD"),
    ("CDD Agudos Int DC", "BR09", "902", "CD", "902-CD"), ("CDD Ribeirao Preto DC", "BRD1", "956", "CD", "956-CD"),
    ("CDD Jau", "BRCU", "977", "CD", "977-CD"), ("CDD Campinas", "BRCQ", "230", "CD", "230-CD"),
    ("CDD Suzano", "BRD3", "297", "CD", "297-CD"), ("CDD S J Campos", "BRD2", "966", "CD", "966-CD"),
    ("CDL Taubate", "BRD5", "968", "CD", "968-CD"),
]


def resolver_origem(v, tab):
    """Linha do de-para (nome, BR, centro, tipo, lista) para um valor que pode ser nome, BR, centro ou lista."""
    s = origem_valida(v)
    if not s:
        return None
    n = norm(s)
    for r in tab:
        if norm(r[0]) == n:
            return r
    for r in tab:
        if norm(r[4]) == n:
            return r
    for r in tab:
        if str(r[2]).strip() == s.strip():
            return r
    brs = [r for r in tab if str(r[1]).upper() == s.strip().upper()]
    if brs:
        return next((r for r in brs if r[3] == "VD"), brs[0])      # BR repetido (BRDF, BR09): fábrica = VD
    return None


def plt_de(cx, fator):
    return cx / fator if fator and fator > 0 else None


# ----------------------------------------------------------------- leitura de abas
class Pasta:
    """Conjunto de abas de um ou mais arquivos, localizadas pelo nome normalizado."""

    def __init__(self, caminhos):
        self.abas = {}
        for c in caminhos:
            wb = openpyxl.load_workbook(c, read_only=True, data_only=True)
            for ws in wb.worksheets:
                self.abas.setdefault(norm(ws.title), (ws.title, ws))

    def get(self, nome):
        t = self.abas.get(norm(nome))
        return t[1] if t else None

    def nomes(self):
        return [t[0] for t in self.abas.values()]

    def com_prefixo(self, prefixo):
        p = norm(prefixo)
        return {k: v[1] for k, v in self.abas.items() if k.startswith(p)}


def linhas(ws, max_cols=None):
    return [list(r) for r in ws.iter_rows(values_only=True)]


def achar_cabecalho(rows, minimo=3):
    for i, r in enumerate(rows[:10]):
        if sum(1 for c in r if isinstance(c, str) and c.strip()) >= minimo:
            return i
    return 0


def achar_col(cab, candidatos, exato=False):
    """Posição (0-based) da primeira coluna cujo cabeçalho casa com algum candidato (em ordem de prioridade)."""
    ns = [norm(c) for c in cab]
    for cand in candidatos:
        n = norm(cand)
        for i, h in enumerate(ns):
            if h and (h == n if exato else (h == n or n in h)):
                return i
    return None


def col_letra(r, letra):
    i = ci(letra) - 1
    return r[i] if i < len(r) else None


# ----------------------------------------------------------------- processamento
def processar(caminhos, data_ref=None, config=None):
    cfg = dict(config or {})
    clientes = [(norm(n).upper(), t) for n, t in (cfg.get("clientes") or CLIENTES_PADRAO)]
    hoje = dt.date.today()
    data_ref = data_ref or hoje
    aud = defaultdict(list)       # categoria -> lista de dicts
    avisos = []

    def A(cat, **kw):
        aud[cat].append(kw)

    pasta = Pasta(caminhos if isinstance(caminhos, (list, tuple)) else [caminhos])
    status_abas = []
    for n in ABAS_ESPERADAS:
        ok = pasta.get(n) is not None
        status_abas.append((n, "Localizada" if ok else "Aba não localizada"))
        if not ok:
            A("Aba não localizada", aba=n, obrigatoria="Sim" if n in ABAS_OBRIGATORIAS else "Não")
    for n in ABAS_OBRIGATORIAS:
        if pasta.get(n) is None:
            raise ValueError(f"Aba obrigatória não localizada: {n}")

    # ---------------- CAD
    cad_s4, cad_fator = {}, {}
    rows = linhas(pasta.get("CAD"))
    h0 = achar_cabecalho(rows)
    for r in rows[h0 + 1:]:
        eg = texto(col_letra(r, COL_CAD["eg"]))
        if not eg:
            continue
        s4 = texto(col_letra(r, COL_CAD["s4"]))
        f = numero(col_letra(r, COL_CAD["cx_plt"]))
        cad_s4[eg] = s4
        if f > 0:
            cad_fator[eg] = f
        else:
            A("Fator CX/PLT inválido", sku_eg=eg, valor=col_letra(r, COL_CAD["cx_plt"]))

    # ---------------- Sheet3 (EG -> rede)
    eg_rede = {}
    ws = pasta.get("Sheet3")
    if ws is not None:
        rows = linhas(ws)
        h0 = achar_cabecalho(rows, 2)
        cab = rows[h0]
        ce = achar_col(cab, ["cliente eg", "eg", "cod eg", "cliente"])
        cr = achar_col(cab, ["rede", "grupo"])
        if ce is not None and cr is not None:
            for r in rows[h0 + 1:]:
                e, g = texto(r[ce]), texto(r[cr])
                if e and g:
                    eg_rede[e] = g.upper()
        else:
            avisos.append("Sheet3: colunas de Cliente EG e Rede não identificadas; rede inferida pelo nome.")

    # ---------------- De-para de origens
    tab_orig = list(ORIGENS_PADRAO)
    ws = pasta.get("DeParaOrigem")
    if ws is not None:
        rows = linhas(ws)
        h0 = achar_cabecalho(rows, 3)
        cab = rows[h0]
        ix = [achar_col(cab, c) for c in (["nome origem"], ["br origem"], ["codigo centro", "centro"], ["tipo origem", "tipo"], ["lista"])]
        if None not in ix:
            novo = []
            for r in rows[h0 + 1:]:
                if texto(r[ix[0]]).upper().startswith("TRAVA"):
                    break                                   # bloco TRAVA COMERCIAL é ignorado
                if texto(r[ix[1]]):
                    novo.append(tuple(texto(r[i]) for i in ix))
            if novo:
                tab_orig = novo
        else:
            avisos.append("DeParaOrigem: colunas não identificadas; usado o de-para padrão do script.")

    def br_de(v):
        r = resolver_origem(v, tab_orig)
        return r[1] if r else origem_valida(v)

    # ---------------- Base Crua
    rows = linhas(pasta.get("Base Crua"))
    h0 = achar_cabecalho(rows, 5)
    cab_base = rows[h0]
    col_unid = achar_col(cab_base, ["unidade"])
    # Rede = coluna L (Nome Rede); a coluna O traz o nome das lojas da rede
    col_rede = ord("L") - ord("A")
    if not norm(texto(cab_base[col_rede]) if col_rede < len(cab_base) else "").startswith(("nome rede", "rede", "nome da rede")):
        avisos.append(f"Base Crua: cabeçalho da coluna L é '{texto(cab_base[col_rede]) if col_rede < len(cab_base) else ''}' (esperado 'Nome Rede'); conferir se L é mesmo a rede.")
    grupos = defaultdict(list)
    n_base = 0
    for k, r in enumerate(rows[h0 + 1:], start=h0 + 2):
        g = lambda nome: col_letra(r, COL_BASE[nome])
        eg, ped, sku = texto(g("eg")), texto(g("pedido")), texto(g("sku_eg"))
        if not (eg or ped or sku):
            continue
        n_base += 1
        if not (eg and ped and sku):
            A("Linha sem chave completa", linha=k, cliente_eg=eg, pedido=ped, sku_eg=sku)
            continue
        rec = dict(
            linha=k, eg=eg, pedido=ped, sku_eg=sku, comercial=texto(g("comercial")),
            sap=texto(g("sap")), loja=texto(g("loja")).strip(), sku_sap=texto(g("sku_sap")),
            rede_base=(texto(r[col_rede]).strip().upper() if (col_rede is not None and col_rede < len(r)) else ""),
            descricao=texto(g("descricao")), hl=numero(g("hl")), plt_v=numero(g("plt")),
            cx=numero(g("cx")), criacao=data(g("criacao")), venc=data(g("venc")),
            qtd_atual=(numero(g("qtd_atual")) if texto(g("qtd_atual")) != "" else None), sem_remessa=numero(g("sem_remessa")),
            com_remessa=numero(g("com_remessa")), faturado=numero(g("faturado")),
            captacao=data(g("captacao")),
        )
        if rec["qtd_atual"] is None:                      # Qtd. Atualizada vazia: usa a quantidade original
            rec["qtd_atual"] = rec["cx"]
            A("Qtd. atualizada vazia (usada a Qtd. original)", linha=k, cliente_eg=eg, pedido=ped, sku_eg=sku, cx=rec["cx"])
        if col_unid is not None:
            u = norm(r[col_unid]) if col_unid < len(r) else ""
            if u and u not in ("cx", "caixa", "caixas"):
                A("Unidade diferente de CX", linha=k, pedido=ped, sku_eg=sku, unidade=r[col_unid])
        grupos[(eg, ped, sku)].append(rec)

    sel = []
    for key, lst in grupos.items():
        validas = [x for x in lst if x["criacao"]]
        if validas:
            validas.sort(key=lambda x: (x["criacao"], x["venc"] or dt.date(2100, 1, 1), x["linha"]))
            escolhida = validas[0]
        else:
            escolhida = lst[0]
            A("Data de criação ausente ou inválida", linha=escolhida["linha"], cliente_eg=key[0],
              pedido=key[1], sku_eg=key[2],
              obs="Erro de integridade: data de criação ausente ou inválida")
        for x in lst:
            if x is not escolhida:
                motivo = ("Duplicada: data de criação posterior/igual" if x["criacao"]
                          else "Erro de integridade: data de criação ausente ou inválida")
                A("Linhas duplicadas descartadas", linha=x["linha"], cliente_eg=key[0], pedido=key[1],
                  sku_eg=key[2], motivo=motivo)
        menor_criacao = validas[0]["criacao"] if validas else None
        escolhida["criacao_min"] = menor_criacao
        if escolhida["captacao"]:
            escolhida["captacao_final"], escolhida["fonte_captacao"] = escolhida["captacao"], "Captação original"
        else:
            escolhida["captacao_final"] = menor_criacao
            escolhida["fonte_captacao"] = "Substituída pela primeira data de criação"
            A("Captação substituída pela data de criação", cliente_eg=key[0], pedido=key[1], sku_eg=key[2])
        sel.append(escolhida)
    sel.sort(key=lambda x: x["linha"])

    # ---------------- Grupo (rede) / Tipo (CD, VD) / Tipo de origem
    sem_sheet3 = {}

    def rede_de(x):
        if x.get("rede_base"):
            return x["rede_base"]
        if x["eg"] in eg_rede:
            return eg_rede[x["eg"]]
        toks = [t for t in re.findall(r"[A-Z]+", norm(x["loja"]).upper())
                if t not in {"CD", "LJ", "LOJA", "FILIAL", "DE", "DA", "DO", "SUPERMERCADO", "SUPERMERCADOS"}]
        rede = toks[0] if toks else (x["loja"].upper() or x["eg"])
        sem_sheet3[x["eg"]] = (x["loja"], rede)
        return rede

    for x in sel:
        x["rede"] = rede_de(x)
        nm = norm(x["loja"]).upper()
        eh_cd = bool(re.search(r"\bCD\b", nm))
        tc = tipo_cliente(clientes, x["loja"], x["rede"], x["eg"])
        x["tipo_cfg"] = tc
        x["tipo"] = tc or ("CD" if eh_cd else "VD")      # fora da tabela: "CD" no nome = CD
    for eg, (loja, rede) in sem_sheet3.items():
        A("Rede inferida pelo nome (conferir)", cliente_eg=eg, nome=loja, rede=rede)

    # ---------------- DeParaCDD
    de_para = {}
    ws = pasta.get("DeParaCDD")
    if ws is not None:
        rows = linhas(ws)
        h0 = achar_cabecalho(rows, 2)
        cab = rows[h0]
        ce = achar_col(cab, ["clienteg", "cliente eg", "client eg", "eg", "cod cliente", "cliente"])
        cd = achar_col(cab, ["cdd footprint", "cdd footptint", "footprint", "footptint", "cdd", "centro de distribuicao", "destino"])
        if ce is not None and cd is not None:
            for r in rows[h0 + 1:]:
                e, c = texto(r[ce]), texto(r[cd]).strip()
                if e and c:
                    de_para[e] = c
        else:
            avisos.append("DeParaCDD: colunas de cliente e CDD não identificadas.")

    def tipo_origem(x):
        if x.get("tipo_cfg") == "VD":
            return "Fábrica"
        if x.get("tipo_cfg") == "CD":
            return "CDD"
        return "CDD" if x["eg"] in de_para else "Fábrica"

    for x in sel:
        x["tipo_origem"] = tipo_origem(x)
        if not x.get("tipo_cfg"):
            x["tipo"] = "CD" if x["tipo_origem"] == "CDD" else x["tipo"]   # fora da tabela: origem CDD = loja a loja = CD

    # ---------------- Marcado
    marc = defaultdict(lambda: dict(total=0.0, fat=0.0, passada=0.0, futuro=0.0, dia=0.0, semdata=0.0,
                                    prog_passada=0.0, n=0, agendas=[], speeds=[], datas_fat=[]))
    fora = []
    ws = pasta.get("Marcado")
    if ws is None:
        avisos.append("Aba Marcado não localizada: marcado/entregue por agenda = 0.")
    else:
        rows = linhas(ws)
        h0 = achar_cabecalho(rows, 5)
        cab = rows[h0]
        c_ped = achar_col(cab, ["pedido erp", "nº pedido erp", "n pedido erp", "pedido"])
        c_agenda = achar_col(cab, ["data agenda", "agenda", "data de entrega", "data entrega"])
        c_fat = achar_col(cab, ["data faturamento", "faturamento", "faturado", "nota fiscal", "nf"])
        c_cx = ci(COL_MARC["q3"]) - 1
        hcx = norm(cab[c_cx]) if c_cx < len(cab) else ""
        if hcx and not any(t in hcx for t in ("cx", "caixa", "qtd", "quant")):
            avisos.append(f"Marcado: coluna L ('{cab[c_cx]}') não parece ser caixas; conferir J/K/L.")
        if c_ped is None:
            avisos.append("Marcado: coluna de Pedido ERP não identificada pelo cabeçalho; marcações irão para Fora_Carteira.")
        chaves = {(x["eg"], x["pedido"], x["sku_eg"]): x for x in sel}
        pedidos_ativos = {(x["eg"], x["pedido"]) for x in sel}
        for k, r in enumerate(rows[h0 + 1:], start=h0 + 2):
            eg = texto(col_letra(r, COL_MARC["eg"]))
            sku = texto(col_letra(r, COL_MARC["sku_eg"]))
            ped = texto(r[c_ped]) if (c_ped is not None and c_ped < len(r)) else ""
            if not (eg or sku or ped):
                continue
            qcx = numero(col_letra(r, COL_MARC["q3"]))
            ag = data(r[c_agenda]) if c_agenda is not None else None
            fat_v = r[c_fat] if c_fat is not None else None
            fat = bool(data(fat_v)) or numero(fat_v) > 0 or (isinstance(fat_v, str) and bool(fat_v.strip())
                                                           and norm(fat_v) not in ("nao", "n", "0"))
            key = (eg, ped, sku)
            if key not in chaves:
                motivo = ("SKU sem entrada no pedido" if (eg, ped) in pedidos_ativos
                          else "Pedido fora da carteira")
                fora.append(dict(linha=k, cliente_eg=eg, pedido=ped, sku_eg=sku, qtd_cx=qcx,
                                 agenda=fmt_data(ag), speed_drp=texto(col_letra(r, COL_MARC["speed"])),
                                 motivo=motivo))
                continue
            x = chaves[key]
            m = marc[key]
            m["total"] += qcx
            m["n"] += 1
            sp = texto(col_letra(r, COL_MARC["speed"]))
            if sp:
                m["speeds"].append(sp)
            if ag:
                m["agendas"].append(ag)
            so_fat = x["rede"] in REDES_ENTREGA_SO_FATURADO
            if fat:
                m["fat"] += qcx
                if ag:
                    m["datas_fat"].append(ag)
            elif ag and ag < data_ref:
                if so_fat:
                    m["prog_passada"] += qcx
                else:
                    m["passada"] += qcx
            elif ag and ag == data_ref:
                m["dia"] += qcx
            elif ag:
                m["futuro"] += qcx
            else:
                m["semdata"] += qcx
        for f in fora:
            A("Marcações fora da carteira", **f)

    # ---------------- Malha
    malha = defaultdict(list)
    ws = pasta.get("Malha")
    if ws is not None:
        rows = linhas(ws)
        h0 = achar_cabecalho(rows, 3)
        cab = rows[h0]
        cs = achar_col(cab, ["sku sap", "cod sku sap", "material sap", "sku"], exato=False)
        cc = achar_col(cab, ["destino comercial", "comercial", "destino"])
        co = achar_col(cab, ["fabrica origem sap", "origem", "cod fabrica", "codigo fabrica", "centro", "fabrica"])
        cn = achar_col(cab, ["nome fabrica origem sap", "nome fabrica", "nome origem", "descricao fabrica", "fabrica nome"])
        if None in (cs, cc, co):
            avisos.append("Malha: colunas SKU SAP / Destino Comercial / Origem não identificadas pelo cabeçalho.")
        else:
            for r in rows[h0 + 1:]:
                s, c = texto(r[cs]), texto(r[cc])
                if not (s and c):
                    continue
                bruto = origem_valida(r[co])
                nome = texto(r[cn]) if cn is not None else ""
                row = resolver_origem(bruto, tab_orig)
                if row:
                    o, tp, nome = row[1], row[3], (nome or row[0])
                elif re.fullmatch(r"BR[0-9A-Z]{2,3}", bruto.upper()):
                    o, tp = bruto.upper(), ""
                    A("Origem fora do de-para", origem=bruto, sku_sap=s)
                else:
                    o, tp = "", ""
                    if bruto:
                        A("Origem fora do de-para", origem=bruto, sku_sap=s)
                malha[(s, c.upper())].append((o, nome, tp))
    else:
        avisos.append("Aba Malha não localizada: fábrica sem origem (Sem malha).")

    # ---------------- Estoque Fábricas
    est_fab, est_fab_ok = defaultdict(float), set()
    ws = pasta.get("Estoque Fabricas")
    if ws is not None:
        rows = linhas(ws)
        h0 = achar_cabecalho(rows, 3)
        cab = rows[h0]
        co = achar_col(cab, ["orig s4", "origem s4", "origem", "centro", "fabrica"])
        ca = achar_col(cab, ["atributo"])
        cp = achar_col(cab, ["sku pca", "pca", "sku eg", "sku"])
        cd1 = achar_col(cab, ["d1"], exato=True)
        if cd1 is None:
            cd1 = ci("D") - 1
        if None in (co, cp):
            avisos.append("Estoque Fabricas: colunas de origem e Sku PCA (= SKU EG) não identificadas.")
        else:
            for r in rows[h0 + 1:]:
                o, p = br_de(r[co]), texto(r[cp])
                if ca is not None and ca < len(r) and r[ca] and "estoque final" not in norm(r[ca]):
                    continue                                   # só a linha "Estoque Final"
                if o and p:
                    d1 = max(0.0, numero(r[cd1]) if cd1 < len(r) else 0.0)   # D1 negativo = 0
                    if UNID_ESTOQUE_FABRICA == "PLT":
                        f_ = cad_fator.get(p)
                        d1 = d1 * f_ if f_ else 0.0
                    est_fab[(o, p)] += d1
                    est_fab_ok.add((o, p))
    else:
        avisos.append("Aba Estoque Fabricas não localizada: estoque de fábrica = 0.")

    # ---------------- Estoque CDD
    est_cdd = {}
    for k, ws in {k: v[1] for k, v in pasta.abas.items() if k.startswith("estoque") and "fabrica" not in k}.items():
        rows = linhas(ws)
        h0 = achar_cabecalho(rows, 3)
        cab = rows[h0]
        cp = achar_col(cab, ["codigoproduto", "codigo do produto", "cod produto", "codigo"])
        cs = achar_col(cab, ["saldodisponivel", "saldo disponivel", "saldo"])
        d = {}
        if cp is None or cs is None:
            avisos.append(f"{pasta.abas[k][0]}: colunas Código do Produto / SaldoDisponivel não identificadas.")
        else:
            for r in rows[h0 + 1:]:
                p = texto(r[cp])
                if p:
                    d[p] = d.get(p, 0.0) + numero(r[cs])
        est_cdd[k] = d

    def aba_cdd(nome_cdd):
        def limpo(t):
            t = norm(t).replace("_", " ")
            ant = None
            while ant != t:                      # tira prefixos: estoque / cdd / cdl / cdi / cd
                ant = t
                for pre in ("estoque", "cdd", "cdl", "cdi", "cd"):
                    if t.startswith(pre + " ") or t == pre:
                        t = t[len(pre):].strip()
            return t
        n = limpo(nome_cdd)
        for k, d in est_cdd.items():            # igualdade exata no nome limpo
            if limpo(k) == n:
                return d
        for k, d in est_cdd.items():            # aceita um nome contido no outro (ex.: "Barueri" x "CDD Barueri SP")
            kk = limpo(k)
            if n and kk and (n in kk or kk in n):
                return d
        return None

    # ---------------- Produção
    producao = defaultdict(list)
    ws = pasta.get("Produção")
    if ws is not None:
        rows = linhas(ws)
        h0 = achar_cabecalho(rows, 3)
        cab = rows[h0]
        co = achar_col(cab, ["origem", "fabrica", "centro"])
        cp = achar_col(cab, ["cod prod", "sku pca", "sku eg", "sku s4", "codigo s4", "produto s4", "codigo do produto", "cod produto", "sku"])
        cdt = achar_col(cab, ["data de producao", "data producao", "producao", "data"])
        cst = achar_col(cab, ["atv x desc", "situacao", "status", "ativo"])
        if None in (co, cp, cdt):
            avisos.append("Produção: colunas de origem, SKU S4 e data não identificadas.")
        else:
            for r in rows[h0 + 1:]:
                o, p = br_de(r[co]), texto(r[cp])
                if p and not o and texto(r[co]):
                    A("Produção com origem fora do de-para (ignorada)", origem=texto(r[co]), sku=p)
                if not (o and p):
                    continue
                bruto = r[cdt]
                d = data(bruto)
                st = norm(r[cst]) if cst is not None else "ativo"
                ativo = st.startswith("ativ") or st in ("", "sim", "s")
                producao[(o, p)].append(dict(data=d, ativo=ativo, bruto=bruto, situacao=st))
                if not ativo:
                    A("Produção descontinuada", origem=o, sku_s4=p)
                elif not d:
                    A("Produção sem previsão", origem=o, sku_s4=p, valor=bruto)
    else:
        avisos.append("Aba Produção não localizada: sem cobertura por produção.")

    # ---------------- Vales
    vales = {}
    for aba, rotulo in (("Planificador_Pallet", "palete"), ("Planificador_Chapatex", "chapatex")):
        ws = pasta.get(aba)
        if ws is None:
            continue
        rows = linhas(ws)
        # cabeçalho = linha que tem "Vales Ativos"; rede e vales pelo NOME da coluna (fallback: D e AH)
        h0, cr, cv = None, None, None
        for i, r in enumerate(rows[:15]):
            ns = [norm(c) for c in r]
            if any(n == "vales ativos" for n in ns):
                h0 = i
                cv = next(j for j, n in enumerate(ns) if n == "vales ativos")
                cr = next((j for j, n in enumerate(ns) if n in ("rede", "nome rede")), None)
                break
        if h0 is None:
            h0, cr, cv = achar_cabecalho(rows, 3), ci("D") - 1, ci(COL_VALES) - 1
            avisos.append(f"{aba}: cabeçalho 'Vales Ativos' não encontrado; usei a coluna D (rede) e AH (vales).")
        elif cr is None:
            cr = ci("D") - 1
        for r in rows[h0 + 1:]:
            nome = texto(r[cr]).upper() if cr < len(r) else ""
            if not nome or norm(nome) in ("total", "rede", "nome rede"):
                continue
            v = numero(r[cv]) if cv < len(r) else 0.0
            vales.setdefault(norm(nome), dict(nome=nome, palete=0.0, chapatex=0.0))[rotulo] += v

    # ---------------- Cálculo por linha
    for x in sel:
        fator = cad_fator.get(x["sku_eg"])
        x["cad_ok"] = x["sku_eg"] in cad_s4
        x["s4"] = cad_s4.get(x["sku_eg"], "")
        x["fator"] = fator
        if not x["cad_ok"]:
            A("SKU não localizado na CAD", sku_eg=x["sku_eg"], pedido=x["pedido"], cliente_eg=x["eg"],
              obs="Erro crítico: SKU não localizado na CAD")
        elif not fator:
            A("Fator CX/PLT inválido", sku_eg=x["sku_eg"], pedido=x["pedido"], cliente_eg=x["eg"])
        calc = plt_de(x["cx"], fator)
        x["plt_cad"] = calc
        x["diverge_plt"] = bool(calc is not None and abs(calc - x["plt_v"]) > 0.5)
        if x["diverge_plt"]:
            A("Divergência entre PLT informado e fator CAD", pedido=x["pedido"], sku_eg=x["sku_eg"],
              plt_informado=x["plt_v"], plt_cad=round(calc, 2))
        x["entrada"] = x["cx"]
        plt_ent = calc if calc is not None else x["plt_v"]
        x["fracionado"] = bool(plt_ent and 0 < plt_ent < LIM_FRACIONADO_PLT)       # menos de 1 palete (pela CAD)
        x["frac_vd"] = bool(x["fracionado"] and x["tipo"] == "VD")                  # VD não entrega fracionado
        x["pendente"] = max(0.0, x["qtd_atual"] - x["sem_remessa"] - x["com_remessa"] - x["faturado"])
        m = marc.get((x["eg"], x["pedido"], x["sku_eg"]))
        m = m or dict(total=0.0, fat=0.0, passada=0.0, futuro=0.0, dia=0.0, semdata=0.0, prog_passada=0.0,
                      n=0, agendas=[], speeds=[], datas_fat=[])
        soma = m["fat"] + m["passada"] + m["futuro"] + m["dia"] + m["semdata"] + m["prog_passada"]
        x["marc_total"], x["marc_check"] = m["total"], round(m["total"] - soma, 6)
        marc_ent = m["fat"] + m["passada"]
        marc_aent = m["futuro"] + m["dia"] + m["semdata"] + m["prog_passada"]
        x["marc_ent"], x["marc_aent"] = marc_ent, marc_aent
        x["speed_drp"] = ", ".join(sorted(set(m["speeds"])))
        ag = sorted(m["agendas"])
        x["agenda_ref"] = ag[0] if ag else None
        x["data_entrega"] = max(m["datas_fat"]) if m["datas_fat"] else None
        x["entregue"] = min(x["entrada"], max(x["faturado"], marc_ent))
        carros = x["sem_remessa"] + x["com_remessa"]
        extra = max(0.0, marc_aent - carros)       # marcado ainda fora de AT/AU (sem duplicar)
        x["programado"] = min(carros + extra, max(0.0, x["entrada"] - x["entregue"]))
        x["aproveitavel"] = x["programado"]
        x["falta_marcar"] = max(0.0, min(x["pendente"] - extra, x["entrada"] - x["entregue"] - x["programado"]))
        x["dup_carros"] = bool(marc_aent > 0 and carros > 0 and marc_aent <= carros)
        # origem(ns)
        cands = (malha.get((x["sku_sap"], x["comercial"].upper()))
                 or malha.get((x["s4"], x["comercial"].upper())) or [])      # SKU SAP da Malha = Cod S4 da CAD
        x["cands"] = [c for c in cands if c[0]]
        if x["tipo_origem"] == "Fábrica":
            so_vd = [c for c in x["cands"] if c[2] != "CD"]
            if x["cands"] and not so_vd:
                A("Origem CD na malha (ignorada para fábrica)", pedido=x["pedido"], sku_eg=x["sku_eg"],
                  origens=", ".join(sorted({c[0] for c in x["cands"]})))
            x["cands"] = so_vd
        x["status_malha"] = ("Sem malha" if not cands else ("Sem origem válida" if not x["cands"] else "OK"))
        x["origem"], x["origem_nome"] = "", ""
        x["n_origens_malha"] = len({c[0] for c in x["cands"]})

    # ---------------- Alocação de origem (fábrica) por proximidade de 24 PLT
    por_eg = defaultdict(list)
    for x in sel:
        if x["pendente"] > 0 and x["cad_ok"] and x["fator"]:
            por_eg[x["eg"]].append(x)
    for eg, lst in por_eg.items():
        tot = defaultdict(float)
        multi = []
        for x in lst:
            if x["tipo_origem"] != "Fábrica" or x["status_malha"] != "OK":
                continue
            orig = sorted({c[0] for c in x["cands"]})
            if len(orig) == 1:
                o = orig[0]
                x["origem"] = o
                x["origem_nome"] = next(c[1] for c in x["cands"] if c[0] == o)
                tot[o] += 0 if x["frac_vd"] else x["pendente"] / x["fator"]
            else:
                multi.append((x, orig))
        multi.sort(key=lambda t: -t[0]["pendente"] / t[0]["fator"])
        for x, orig in multi:
            def chave(o):
                gap = max(0.0, MIN_CARRO - tot[o])
                tem = est_fab.get((o, x["sku_eg"]), 0) > 0
                return (0 if tem else 1, gap, o)     # origem COM estoque primeiro; entre elas, a mais perto de 24 PLT
            o = min(orig, key=chave)
            x["origem"] = o
            x["origem_nome"] = next(c[1] for c in x["cands"] if c[0] == o)
            x["origens_possiveis"] = ", ".join(orig)
            tot[o] += x["pendente"] / x["fator"]
    for x in sel:
        x.setdefault("origens_possiveis", x["origem"])
        if x["tipo_origem"] == "CDD" and x["status_malha"] == "OK" and not x["origem"]:
            # CDD: a origem da malha só serve de referência para produção
            x["origem"] = sorted({c[0] for c in x["cands"]})[0]
            x["origem_nome"] = next(c[1] for c in x["cands"] if c[0] == x["origem"])

    # volume do cliente por origem (fábrica) + fecha carro
    vol = defaultdict(float)
    for x in sel:
        if x["tipo_origem"] == "Fábrica" and x["origem"] and x["pendente"] > 0 and x["fator"] and not x["frac_vd"]:
            vol[(x["eg"], x["origem"])] += x["pendente"] / x["fator"]
    n_orig = defaultdict(set)
    for (eg, o), v in vol.items():
        n_orig[eg].add(o)
    for x in sel:
        x["vol_cliente_origem"] = vol.get((x["eg"], x["origem"]), 0.0) if x["tipo_origem"] == "Fábrica" else None
        x["n_origens_validas"] = len(n_orig.get(x["eg"], ())) if x["tipo_origem"] == "Fábrica" else None
        v = x["vol_cliente_origem"]
        if v is None:
            x["fecha_carro"] = "n/a (CDD)"
        elif not x["origem"] or x["pendente"] <= 0:
            x["fecha_carro"] = "—"
        elif v >= MIN_CARRO:
            x["fecha_carro"] = "Sim"
        elif v >= MIN_CARRO_EXC:
            x["fecha_carro"] = "Sim*"
        else:
            x["fecha_carro"] = "Não"
        x["carros_estimados"] = (math.ceil(v / MAX_CARRO) if (v and v >= MIN_CARRO_EXC) else 0)
    for (eg, o), v in vol.items():
        if v < MIN_CARRO_EXC:
            A("Cliente abaixo de 24 PLT na origem", cliente_eg=eg, origem=o, plt=round(v, 2),
              origens_do_cliente=len(n_orig[eg]))

    # ---------------- Qualificação (consumo por cliente + SKU, vencimento mais próximo)
    grupos_q = defaultdict(list)
    for x in sel:
        x["estoque_cx"] = 0.0
        x["estoque_plt"] = None
        x["qualificado"] = 0.0
        x["estoque_critico"] = ""
        x["disputa"] = ""
        if x["pendente"] <= 0 or not x["cad_ok"] or x["frac_vd"]:
            continue
        if x["tipo_origem"] == "Fábrica":
            if not x["origem"]:
                continue
            grupos_q[("F", x["eg"], x["origem"], x["sku_eg"])].append(x)
        else:
            cdd = de_para.get(x["eg"])
            if cdd:
                grupos_q[("C", x["eg"], cdd, x["sku_eg"])].append(x)
    pedido_total_cdd = defaultdict(float)
    for (t, eg, o, p), lst in grupos_q.items():
        if t == "C":
            pedido_total_cdd[(eg, o, p)] = sum(y["pendente"] for y in lst)
    uso = defaultdict(float)   # (tipo, local, produto) -> total qualificado por todos os clientes
    for (t, eg, o, p), lst in sorted(grupos_q.items()):
        lst.sort(key=lambda y: (y["venc"] or dt.date(2100, 1, 1), y["pedido"]))
        if t == "F":
            if (o, p) not in est_fab_ok:
                A("Produto não localizado no estoque de fábrica", origem=o, sku_eg=p, cliente_eg=eg)
            saldo = est_fab.get((o, p), 0.0)
            fator = lst[0]["fator"]
            crit = (saldo / fator < LIM_CRITICO_FABRICA_PLT) if fator else False
            fecha = lst[0]["fecha_carro"] in ("Sim", "Sim*")
            restante = saldo
            for y in lst:
                y["estoque_cx"], y["estoque_plt"] = saldo, plt_de(saldo, y["fator"])
                y["estoque_critico"] = "Sim" if (crit and saldo > 0) else "Não"
                # abaixo do mínimo na origem: qualifica o que há em estoque e sinaliza (não zera)
                q = min(y["pendente"], restante)
                restante -= q
                y["qualificado"] = q
            uso[("F", o, p)] += saldo - restante
            if crit and saldo > 0:
                A("Estoque crítico de fábrica", origem=o, sku_eg=p, estoque_plt=round(saldo / fator, 1))
        else:
            aba = aba_cdd(o)
            if aba is None:
                A("Aba de CDD não localizada", cdd=o, cliente_eg=eg)
                continue
            codigo = o_sku = p[:-1]
            if o_sku not in aba:
                A("Produto não localizado no estoque do CDD", cdd=o, sku_eg=p, codigo=o_sku)
            saldo = aba.get(o_sku, 0.0)
            tot_pend = pedido_total_cdd[(eg, o, p)]
            crit = saldo < tot_pend * MULT_CRITICO_CDD
            restante = saldo
            for y in lst:
                y["estoque_cx"], y["estoque_plt"] = saldo, plt_de(saldo, y["fator"])
                y["estoque_critico"] = "Sim" if (crit and saldo > 0) else "Não"
                q = min(y["pendente"], restante)
                restante -= q
                y["qualificado"] = q
            uso[("C", o, o_sku)] += saldo - restante
            if crit and saldo > 0:
                A("Estoque crítico de CDD", cdd=o, sku_eg=p, saldo_cx=saldo, pendente_cx=tot_pend)
    # disputa de estoque entre clientes (não há rateio: só sinaliza)
    demanda = defaultdict(set)
    for (t, eg, o, p), lst in grupos_q.items():
        chave = (t, o, p if t == "F" else p[:-1])
        if sum(y["pendente"] for y in lst) > 0:
            demanda[chave].add(eg)
    for (t, eg, o, p), lst in grupos_q.items():
        chave = (t, o, p if t == "F" else p[:-1])
        if len(demanda[chave]) > 1:
            tot = sum(y["pendente"] for e2 in demanda[chave] for y in grupos_q.get((t, e2, o, p), []))
            if tot > lst[0]["estoque_cx"]:
                for y in lst:
                    y["disputa"] = "Sim"

    # ---------------- Produção, descoberto, motivo, situação
    for x in sel:
        x["cob_producao"] = 0.0
        x["producao_valida"] = "Não"
        x["prox_producao"] = None
        saldo = max(0.0, x["pendente"] - x["qualificado"])
        x["saldo_apos_estoque"] = saldo
        if x["pendente"] > 0 and x["cad_ok"] and x["origem"] and saldo > 0:
            cand = producao.get((x["origem"], x["sku_eg"]), []) or producao.get((x["origem"], x["s4"]), [])
            if not cand and (x["origem"] and x["s4"]):
                A("Produção sem correspondência", origem=x["origem"], sku_s4=x["s4"], pedido=x["pedido"])
            validas = [p for p in cand if p["ativo"] and p["data"] and x["venc"]
                       and data_ref <= p["data"] <= x["venc"]]
            for p in cand:
                if p["ativo"] and p["data"] and x["venc"] and p["data"] > x["venc"]:
                    A("Produção após o vencimento", origem=x["origem"], sku_s4=x["s4"],
                      pedido=x["pedido"], data=fmt_data(p["data"]))
            if validas:
                x["producao_valida"] = "Sim"
                x["prox_producao"] = min(p["data"] for p in validas)
                x["cob_producao"] = saldo      # a quantidade não importa: produção válida cobre o saldo
        x["descoberto"] = max(0.0, x["pendente"] - x["qualificado"] - x["cob_producao"])
        # coberturas para os fills (sobre o que falta marcar)
        x["cob_estoque"] = min(x["qualificado"], x["falta_marcar"])
        x["cob_prod_fill"] = min(x["cob_producao"], x["falta_marcar"] - x["cob_estoque"])

        # motivo e situação
        p = x["pendente"]
        alertas = []
        if p <= 0:
            x["situacao"], x["motivo"] = "Sem pendente", ""
        else:
            motivo = ""
            if not x["cad_ok"]:
                motivo = "Erro crítico de CAD"
            elif x["frac_vd"]:
                motivo = "Fracionado: VD não entrega"
            elif x["tipo_origem"] == "Fábrica":
                if x["status_malha"] != "OK":
                    motivo = x["status_malha"]
                elif x["estoque_cx"] <= 0:
                    motivo = "Sem estoque"
                elif x["fecha_carro"] == "Não":
                    motivo = "Não fecha carro"
                elif x["qualificado"] < p:
                    motivo = "Estoque insuficiente"
                if x["fecha_carro"] == "Não" and motivo == "Sem estoque":
                    alertas.append("Não fecha carro")
            else:
                cdd = de_para.get(x["eg"])
                if not cdd:
                    motivo = "Sem DeParaCDD"
                    A("Cliente sem DeParaCDD", cliente_eg=x["eg"], nome=x["loja"])
                elif aba_cdd(cdd) is None:
                    motivo = "Aba de CDD não localizada"
                elif x["estoque_cx"] <= 0:
                    motivo = "Sem estoque"
                elif x["qualificado"] < p:
                    motivo = "Estoque insuficiente"
            x["motivo"] = motivo
            if x["qualificado"] >= p:
                x["situacao"] = "Qualificado"
            elif x["qualificado"] > 0:
                x["situacao"] = "Qualificado parcial"
            else:
                x["situacao"] = "Não qualificado"
            if x["estoque_critico"] == "Sim":
                alertas.append("Estoque crítico")
            if x["saldo_apos_estoque"] > 0 and x["cad_ok"] and x["origem"] and x["producao_valida"] == "Não":
                alertas.append("Sem produção válida")
            if x["disputa"] == "Sim":
                alertas.append("Estoque disputado")
            if x["tipo_origem"] == "Fábrica" and x["fecha_carro"] == "Não" and x["estoque_cx"] > 0:
                alertas.append("Abaixo do mínimo na origem")
            if x["fecha_carro"] == "Sim*":
                alertas.append("Carro de exceção (22-23 PLT)*")
            if x["falta_marcar"] > 0 and x["venc"]:
                dias = (x["venc"] - data_ref).days
                if dias < 0:
                    alertas.append("Vencido")
                elif dias <= DIAS_ALERTA_VALIDADE:
                    alertas.append("Risco de validade (D+2)")
        if x["diverge_plt"]:
            alertas.append("Divergência PLT × CAD")
        if x["dup_carros"]:
            A("Possível duplicidade Base Crua × carros", pedido=x["pedido"], sku_eg=x["sku_eg"],
              carros_cx=x["sem_remessa"] + x["com_remessa"], marcado_cx=x["marc_aent"])
        x["alertas"] = "; ".join(alertas)
        # conversões PLT
        f = x["fator"]
        for nome in ("entregue", "programado", "pendente", "falta_marcar", "qualificado", "cob_producao",
                     "descoberto", "cob_estoque", "cob_prod_fill", "aproveitavel"):
            x[nome + "_plt"] = plt_de(x[nome], f)
        x["entrada_plt"] = x["plt_v"] if x["plt_v"] else plt_de(x["entrada"], f)
        x["entrada_plt_cad"] = plt_de(x["entrada"], f)
        k_ = 0.0 if x["frac_vd"] else 1.0              # fracionado em cliente VD fica fora do fill
        x["ent_f"], x["entg_f"], x["prog_f"] = x["entrada"] * k_, x["entregue"] * k_, x["programado"] * k_
        x["nao_atendido_f"] = max(0.0, x["ent_f"] - x["entg_f"] - x["prog_f"] - x["cob_estoque"] - x["cob_prod_fill"])
        x["nao_atendido_f_plt"] = plt_de(x["nao_atendido_f"], f)
        if x["tipo_origem"] == "Fábrica":
            x["orig_q"] = x["origem_nome"] or x["origem"] or "(sem origem)"
        else:
            x["orig_q"] = de_para.get(x["eg"]) or "(sem CDD)"

    for x in sel:
        dif = x["pendente"] - max(0.0, x["entrada"] - x["entregue"] - x["programado"])
        if abs(dif) > 0.5:
            A("Pendente difere de Entrada − Entregue − Programado", cliente_eg=x["eg"], pedido=x["pedido"], sku_eg=x["sku_eg"],
              pendente=x["pendente"], entrada=x["entrada"], entregue=x["entregue"], programado=x["programado"])
        if x["frac_vd"]:
            A("Fracionado em cliente VD (fora do qualificado e do fill)", cliente_eg=x["eg"], pedido=x["pedido"],
              sku_eg=x["sku_eg"], pendente_plt=None if x["pendente_plt"] is None else round(x["pendente_plt"], 2))

    # ---------------- Vales por rede
    redes = sorted({x["rede"] for x in sel})
    vales_rede, sem_corresp = {}, []
    for r in redes:
        v = vales.get(norm(r))
        vales_rede[r] = dict(palete=v["palete"] if v else 0.0, chapatex=v["chapatex"] if v else 0.0,
                             achou=bool(v))
    for k, v in vales.items():
        if k not in {norm(r) for r in redes}:
            A("Rede sem correspondência nos vales", rede=v["nome"], palete=v["palete"], chapatex=v["chapatex"])
            sem_corresp.append(v["nome"])

    # ---------------- Conferências finais
    conf = []

    def C(nome, ok, detalhe=""):
        conf.append((nome, bool(ok), detalhe))

    C("Uma linha por chave", len({(x["eg"], x["pedido"], x["sku_eg"]) for x in sel}) == len(sel),
      f"{len(sel)} chaves")
    C("Entregue ≤ Entrada", all(x["entregue"] <= x["entrada"] + 1e-6 for x in sel))
    C("Programado ≤ Entrada − Entregue", all(x["programado"] <= x["entrada"] - x["entregue"] + 1e-6 for x in sel))
    C("Sem valores negativos", all(min(x["entregue"], x["programado"], x["pendente"], x["falta_marcar"],
                                       x["qualificado"], x["descoberto"]) >= -1e-9 for x in sel))
    C("Qualificado + Produção + Descoberto = Pendente",
      all(abs(x["qualificado"] + x["cob_producao"] + x["descoberto"] - x["pendente"]) < 1e-6 for x in sel))
    C("Fill c/ produção ≤ 100%",
      all(x["entregue"] + x["programado"] + x["cob_estoque"] + x["cob_prod_fill"] <= x["entrada"] + 1e-6 for x in sel))
    C("Marcado: soma das classes = total", all(abs(x["marc_check"]) < 1e-6 for x in sel))
    C("Estoque consumido ≤ disponível (por cliente/origem/SKU)",
      all(sum(y["qualificado"] for y in lst) <= lst[0]["estoque_cx"] + 1e-6 for lst in grupos_q.values()))
    C("Nenhuma origem 'nan' válida", all(origem_valida(x["origem"]) == x["origem"] for x in sel))
    C("Nenhum pendente zerado por falta de qualificação",
      all(abs(x["pendente"] - max(0.0, x["qtd_atual"] - x["sem_remessa"] - x["com_remessa"] - x["faturado"])) < 1e-9
          for x in sel))
    C("Fábrica abaixo do mínimo de carro está sinalizada",
      all(x["qualificado"] == 0 or x["tipo_origem"] != "Fábrica" or x["fecha_carro"] in ("Sim", "Sim*")
          or "Abaixo do mínimo na origem" in x["alertas"] for x in sel))
    C("CDD sem regra de 24 PLT", all(x["fecha_carro"] == "n/a (CDD)" for x in sel if x["tipo_origem"] == "CDD"))
    C("Produção só até o vencimento",
      all(x["cob_producao"] == 0 or (x["prox_producao"] and x["venc"] and x["prox_producao"] <= x["venc"]) for x in sel))
    C("Marcações fora da carteira fora dos totais", True, f"{len(fora)} registros em Fora_Carteira")
    C("Todo SKU na CAD (ou erro crítico destacado)", True,
      f"{sum(1 for x in sel if not x['cad_ok'])} sem CAD")

    return dict(linhas=sel, fora_carteira=fora, auditoria=dict(aud), avisos=avisos, abas=status_abas,
                conferencias=conf, vales=vales_rede, data_ref=data_ref, n_base=n_base,
                n_chaves=len(sel), de_para=de_para)
