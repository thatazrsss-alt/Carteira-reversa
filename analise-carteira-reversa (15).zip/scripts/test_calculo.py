# -*- coding: utf-8 -*-
"""Testes das regras (cenários pequenos e conhecidos). Rodar: python3 -I test_calculo.py"""
import datetime as dt
import os
import sys
import tempfile

import openpyxl
from openpyxl.utils import column_index_from_string as ci

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from calculo import ORIGENS_PADRAO, parse_clientes, data, numero, origem_valida, processar, resolver_origem  # noqa: E402

import calculo  # noqa: E402
calculo.UNID_ESTOQUE_FABRICA = "CX"   # fixtures de estoque em caixas
REF = dt.date(2026, 10, 15)
D = lambda n: REF + dt.timedelta(days=n)


def put(row, letra, val):
    i = ci(letra) - 1
    while len(row) <= i:
        row.append(None)
    row[i] = val


def linha(h, **kw):
    r = []
    for k, v in kw.items():
        put(r, k, v)
    return r


def base(eg="1", ped="P1", sku="1001", com="SP1", nome="NAGUMO LJ 01", cx=2400, cria=-10, venc=10, fat=0, at=0,
         au=0, qtd=None, capt=None, sap="7001"):
    return linha(None, B=ped, G=com, M=eg, N="s" + eg, O=nome, Q=sku, R=sap, S="X", U=1, V=cx / 100, W=cx,
                 Y=D(cria), Z=D(venc), AQ=cx if qtd is None else qtd, AT=at, AU=au, AV=fat, BA=capt)


def construir(base_rows, marcado=None, malha=None, estoque=None, cdd=None, producao=None, de_para=None, sheet3=None,
              cad=None):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet("Base Crua")
    h = []
    for l, n in dict(B="Pedido ERP", G="Comercial", M="Cliente EG", N="Cliente SAP", O="Nome", Q="SKU EG", R="SKU SAP",
                     S="Desc", U="HL", V="PLT", W="CX", Y="Criacao", Z="Venc", AQ="Atualizada", AT="Sem", AU="Com",
                     AV="Fat", BA="Captacao").items():
        put(h, l, n)
    ws.append(h)
    for r in base_rows:
        ws.append(r)
    ws = wb.create_sheet("CAD")
    ws.append(["S4", "d", "EG", "m", "e", "", "", "", "CX/PLT"])
    for eg, s4, f in (cad or [("1001", "S41001", 100), ("1002", "S41002", 100)]):
        ws.append(linha(None, A=s4, C=eg, I=f))
    ws = wb.create_sheet("Malha")
    ws.append(["SKU SAP", "Destino Comercial", "Origem", "Nome Fabrica"])
    for m in (malha or [("7001", "SP1", "BR01", "F1"), ("7002", "SP1", "BR01", "F1")]):
        ws.append(list(m))
    ws = wb.create_sheet("Estoque Fabricas")
    ws.append(["Origem S4", "Sku PCA", "Desc", "D1"])
    for e in (estoque or []):
        ws.append([e[0], e[1], "d", e[2]])
    ws = wb.create_sheet("Marcado")
    h = []
    for l, n in dict(B="Pedido ERP", D="Cliente EG", G="SKU EG", L="CX", AH="Speed", AI="Data Agenda",
                     AJ="Data Faturamento").items():
        put(h, l, n)
    ws.append(h)
    for r in (marcado or []):
        ws.append(linha(None, B=r[0], D=r[1], G=r[2], L=r[3], AH=r[4], AI=r[5], AJ=r[6]))
    ws = wb.create_sheet("Produção")
    ws.append(["Origem", "SKU S4", "Produto", "Data de Produção", "Situação"])
    for p in (producao or []):
        ws.append([p[0], p[1], "prod", p[2], p[3]])
    ws = wb.create_sheet("DeParaCDD")
    ws.append(["Cliente EG", "CDD"])
    for p in (de_para or []):
        ws.append(list(p))
    for nome, rows in (cdd or {}).items():
        w = wb.create_sheet(f"Estoque CDD {nome}")
        w.append(["Código do Produto", "Desc", "SaldoDisponivel"])
        for r in rows:
            w.append(list(r))
    ws = wb.create_sheet("Sheet3")
    ws.append(["Cliente EG", "Rede"])
    for p in (sheet3 or []):
        ws.append(list(p))
    f = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False).name
    wb.save(f)
    return f


def rodar(*a, **k):
    return processar([construir(*a, **k)], REF)


def uma(res):
    assert len(res["linhas"]) >= 1
    return res["linhas"][0]


ok = 0


def T(nome, cond):
    global ok
    assert cond, nome
    ok += 1
    print("OK ", nome)


# --- utilidades
T("data: marcadores inválidos", all(data(v) is None for v in (None, "", dt.datetime(1, 1, 1) if False else "01/01/0001", "01/01/1970", 25569, "N/D")))
T("data: dd/mm/aaaa", data("05/11/2026") == dt.date(2026, 11, 5))
T("numero pt-BR", numero("1.234,5") == 1234.5 and numero("12,5") == 12.5 and numero("1.234") == 1234)
T("origem nan inválida", origem_valida("nan (BR16)") == "" and origem_valida("nan") == "" and origem_valida("BR01") == "BR01")

# --- de-para de origens
br = lambda v: (resolver_origem(v, ORIGENS_PADRAO) or [None, None])[1]
T("origem: nome, lista, centro e BR resolvem para o BR", br("F. Jacarei") == "BR16" and br("260-VD") == "BR16" and br("260") == "BR16" and br("BR16") == "BR16")
T("BR repetido (BRDF) usa a linha VD", resolver_origem("BRDF", ORIGENS_PADRAO)[3] == "VD" and resolver_origem("CDI Louveira DC", ORIGENS_PADRAO)[3] == "CD")
r = rodar([base()], malha=[("7001", "SP1", "CDI Louveira DC", None)])
T("origem CD na malha não vale para fábrica", uma(r)["motivo"] == "Sem origem válida")

# --- uma linha por chave: menor data de criação, não soma versões
r = rodar([base(cria=-5, cx=1000), base(cria=-20, cx=2400), base(cria=-30, cx=0) if False else base(cria=-3, cx=500)])
x = uma(r)
T("menor criação vence, versões não somam", len(r["linhas"]) == 1 and x["entrada"] == 2400)
T("duplicadas na auditoria", len(r["auditoria"]["Linhas duplicadas descartadas"]) == 2)

# --- pendente e entregue
x = uma(rodar([base(cx=2400, fat=600, at=300, au=200)]))
T("pendente = atualizada - AT - AU - AV", x["pendente"] == 1300)
x = uma(rodar([base(cx=2400, fat=3000, qtd=2400)]))
T("pendente nunca negativo", x["pendente"] == 0)

# --- fábrica: 24 PLT fecha carro, 22-23 exceção, <22 não fecha; qualificado = min(pend, estoque)
est = [("BR01", "1001", 999999)]
x = uma(rodar([base(cx=2400)], estoque=est))
T("24 PLT fecha e qualifica", x["fecha_carro"] == "Sim" and x["qualificado"] == 2400)
x = uma(rodar([base(cx=2300)], estoque=est))
T("23 PLT = exceção com asterisco", x["fecha_carro"] == "Sim*" and x["qualificado"] == 2300 and "exceção" in x["alertas"].lower())
x = uma(rodar([base(cx=2000)], estoque=est))
T("20 PLT não fecha: qualifica o que tem e sinaliza abaixo do mínimo", x["fecha_carro"] == "Não" and x["qualificado"] == 2000 and x["pendente"] == 2000 and x["motivo"] == "Não fecha carro" and "Abaixo do mínimo na origem" in x["alertas"])
x = uma(rodar([base(cx=2400)], estoque=[("BR01", "1001", 0)]))
T("sem estoque", x["motivo"] == "Sem estoque" and x["qualificado"] == 0)
x = uma(rodar([base(cx=2400)], estoque=[("BR01", "1001", 1000)]))
T("estoque parcial + crítico (<50 PLT) não desqualifica", x["qualificado"] == 1000 and "Estoque crítico" in x["alertas"] and x["situacao"] == "Qualificado parcial")

# --- origens não se somam; multi-origem vai para a mais próxima de 24
rows = [base(ped="A", sku="1001", cx=1000, sap="7001"), base(ped="B", sku="1002", cx=1000, sap="7002")]
ml = [("7001", "SP1", "BR01", "F1"), ("7002", "SP1", "BR01", "F1"), ("7002", "SP1", "BR16", "F2")]
r = rodar(rows, malha=ml, estoque=[("BR01", "1001", 9e6), ("BR01", "1002", 9e6), ("BR16", "1002", 9e6)],
          cad=[("1001", "S41001", 100), ("1002", "S41002", 100)])
T("multi-origem: aloca na origem já mais próxima de fechar", all(x["origem"] == "BR01" for x in r["linhas"]) and r["linhas"][0]["vol_cliente_origem"] == 20)
rows = [base(ped="A", sku="1001", cx=800, sap="7001"), base(ped="B", sku="1002", cx=800, sap="7002"),
        base(ped="C", sku="1001", cx=800, sap="7003")]
ml = [("7001", "SP1", "BR01", "F1"), ("7002", "SP1", "BR16", "F2"), ("7003", "SP1", "BR24", "F3")]
r = rodar(rows, malha=ml, estoque=[], cad=[("1001", "S41001", 100), ("1002", "S41002", 100)])
T("origens diferentes não se somam", all(x["fecha_carro"] == "Não" for x in r["linhas"]) and r["linhas"][0]["n_origens_validas"] == 3)

# --- malha
r = rodar([base(sap="9999")])
T("sem malha", uma(r)["motivo"] == "Sem malha")
r = rodar([base()], malha=[("7001", "SP1", "nan (BR16)", None)])
T("origem nan = sem origem válida", uma(r)["motivo"] == "Sem origem válida" and uma(r)["origem"] == "")
r = rodar([base(sku="5555")])
T("SKU fora da CAD = erro crítico, sem inventar S4", uma(r)["motivo"] == "Erro crítico de CAD" and uma(r)["s4"] == "" and uma(r)["pendente_plt"] is None)

# --- produção
pr = [("BR01", "S41001", D(5), "Ativo")]
x = uma(rodar([base(cx=2400)], estoque=[("BR01", "1001", 0)], producao=pr))
T("produção válida cobre o saldo; fecha com descoberto", x["cob_producao"] == 2400 and x["descoberto"] == 0 and x["qualificado"] + x["cob_producao"] + x["descoberto"] == x["pendente"])
x = uma(rodar([base(cx=2400, venc=3)], estoque=[("BR01", "1001", 0)], producao=pr))
T("produção após o vencimento não vale", x["cob_producao"] == 0 and x["descoberto"] == 2400 and "Sem produção válida" in x["alertas"])
x = uma(rodar([base(cx=2400)], estoque=[("BR01", "1001", 0)], producao=[("BR01", "S41001", "Sem previsão", "Ativo")]))
T("produção sem previsão não vale", x["cob_producao"] == 0)
x = uma(rodar([base(cx=2400)], estoque=[("BR01", "1001", 0)], producao=[("BR01", "S41001", D(5), "Descontinuado")]))
T("produção descontinuada não vale", x["cob_producao"] == 0)

# --- consumo de estoque por vencimento (mesmo cliente + SKU)
r = rodar([base(ped="A", cx=1500, venc=20), base(ped="B", cx=1500, venc=5)], estoque=[("BR01", "1001", 2000)])
q = {x["pedido"]: x["qualificado"] for x in r["linhas"]}
T("estoque vai primeiro ao vencimento mais próximo, sem reuso", q["B"] == 1500 and q["A"] == 500)

# --- CDD: sem regra de 24 PLT, crítico < pendente x 20
r = rodar([base(eg="9", nome="SHIBATA LJ 01", cx=500, sap="7001", sku="1001")], cdd={"Louveira": [("100", "x", 500)]},
          de_para=[("9", "Louveira")], sheet3=[("9", "SHIBATA")])
x = uma(r)
T("CDD qualifica sem mínimo e é crítico", x["tipo_origem"] == "CDD" and x["qualificado"] == 500 and x["estoque_critico"] == "Sim" and x["fecha_carro"].startswith("n/a"))
r = rodar([base(eg="9", nome="SHIBATA LJ 01", cx=500)], cdd={"Louveira": [("100", "x", 10000)]}, de_para=[("9", "Louveira")], sheet3=[("9", "SHIBATA")])
# malha com 2 origens: prefere a que tem estoque, entre elas a mais perto de 24 PLT
rows = [base(ped="A", sku="1001", cx=1000, sap="7001"), base(ped="B", sku="1002", cx=1000, sap="7002")]
ml = [("7001", "SP1", "BR15", "F1"), ("7002", "SP1", "BR15", "F1"), ("7002", "SP1", "BR16", "F2")]
r = rodar(rows, malha=ml, estoque=[("BR15", "1001", 9e6), ("BR16", "1002", 9e6)])
T("malha 2 origens: aloca na origem com estoque", {x["sku_eg"]: x["origem"] for x in r["linhas"]}["1002"] == "BR16")
T("CDD com saldo >= 20x não é crítico", uma(r)["estoque_critico"] == "Não")

# --- tipo CD / VD e CD Shibata
r = rodar([base(eg="1", nome="CD BARBOSA SANTANA"), base(eg="2", nome="CD SHIBATA", ped="P2"), base(eg="3", nome="SHIBATA LJ 02", ped="P3"),
           base(eg="4", nome="COOP RHODIA", ped="P4")],
          sheet3=[("1", "BARBOSA"), ("2", "SHIBATA"), ("3", "SHIBATA"), ("4", "COOPERATIVA RHODIA")])
t = {x["eg"]: (x["tipo"], x["tipo_origem"]) for x in r["linhas"]}
T("VD: Barbosa, CD Shibata, Rhodia; CD: lojas do Shibata", t["1"] == ("VD", "Fábrica") and t["2"] == ("VD", "Fábrica") and t["3"] == ("CD", "CDD") and t["4"] == ("VD", "Fábrica"))

# --- marcado: agenda passada = entregue (exceto VD Shibata); futuro = a entregar; fora da carteira não entra
mc = [["P1", "1", "1001", 500, "DRP1", D(-2), None], ["P1", "1", "1001", 300, "DRP2", D(3), None],
      ["PX", "1", "1001", 999, "DRP3", D(3), None]]
r = rodar([base(cx=2400)], marcado=mc)
x = uma(r)
T("agenda passada = entregue; futuro = programado", x["entregue"] == 500 and x["programado"] == 300)
T("marcação fora da carteira fica fora dos totais", len(r["fora_carteira"]) == 1 and x["marc_total"] == 800)
T("falta marcar = pendente - programado", x["falta_marcar"] == 2400 - 500 - 300 or x["falta_marcar"] == x["pendente"] - 300)
r = rodar([base(eg="9", nome="SHIBATA LJ 01", cx=2400)], marcado=[["P1", "9", "1001", 500, "D", D(-2), None]], sheet3=[("9", "SHIBATA")])
x = uma(r)
T("VD Shibata: agenda passada NÃO é entregue", x["entregue"] == 0 and x["programado"] == 500)
r = rodar([base(cx=2400, at=300)], marcado=[["P1", "1", "1001", 300, "D", D(3), None]])
T("não duplica marcado já refletido em AT/AU", uma(r)["programado"] == 300)

# --- validade D+2
x = uma(rodar([base(cx=2400, venc=2)]))
T("risco de validade D+2", "Risco de validade (D+2)" in x["alertas"])
x = uma(rodar([base(cx=2400, venc=9)]))
T("sem alerta de validade longe do vencimento", "validade" not in x["alertas"].lower())

# --- captação
x = uma(rodar([base(capt="N/D", cria=-12)]))
T("captação inválida usa a primeira criação", x["fonte_captacao"].startswith("Substituída") and x["captacao_final"] == D(-12))
x = uma(rodar([base(capt=D(-14), cria=-12)]))
T("captação válida é mantida", x["fonte_captacao"] == "Captação original" and x["captacao_final"] == D(-14))

# --- aba por nome, não por posição
wb = openpyxl.load_workbook(construir([base()]))
wb.move_sheet("CAD", offset=-5)
f = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False).name
wb.save(f)
T("abas localizadas pelo nome", len(processar([f], REF)["linhas"]) == 1)
wb = openpyxl.load_workbook(construir([base()]))
del wb["Malha"]
f = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False).name
wb.save(f)
r = processar([f], REF)
T("aba ausente é registrada", any(a["aba"] == "Malha" for a in r["auditoria"]["Aba não localizada"]))
# --- tabela de clientes editável (config)
r = processar([construir([base(eg="1", nome="LOJA X", ped="P1"), base(eg="2", nome="CD BARBOSA", ped="P2")],
                         sheet3=[("1", "NOVA REDE"), ("2", "BARBOSA")])], REF,
              config=dict(clientes=parse_clientes("NOVA REDE=CD; BARBOSA=CD")))
t = {x["eg"]: (x["tipo"], x["tipo_origem"]) for x in r["linhas"]}
T("tabela de clientes editável: CD vira CDD, rede nova reconhecida", t["1"] == ("CD", "CDD") and t["2"] == ("CD", "CDD"))
T("parse_clientes ignora linhas inválidas", parse_clientes("A=VD;B=XX;lixo; C = cd") == [("A", "VD"), ("C", "CD")])

# --- CDD: grade do CDD do DeParaCDD, código = EG sem o último dígito, cabeçalho real
f = construir([base(eg="9", nome="SHIBATA LJ 01", ped="P1", sku="1001", cx=500), base(eg="9", nome="SHIBATA LJ 01", ped="P2", sku="1021", cx=300)],
              sheet3=[("9", "SHIBATA")], de_para=[("9", "CDD Barueri SP")], cad=[("1001", "S41001", 100), ("1021", "S41021", 100)])
wb = openpyxl.load_workbook(f)
w = wb.create_sheet("Estoque CDD Barueri")
w.append(["CodigoProduto", "DescricaoProduto", "UnidadeMedida", "GradeEstoque", "GradeCadastrada", "Reserva", "Saida", "SaldoDisponivel"])
w.append([100, "X", "Caixa", 1, 547, 0, 32, 515]); w.append([100, "X2", "Caixa", 1, 10, 0, 0, 5])
wb.save(f)
r = processar([f], REF)
t = {x["sku_eg"]: x for x in r["linhas"]}
T("CDD: código = EG sem último dígito, saldo da grade do CDD do DeParaCDD (soma 520), aba achada por nome parcial",
  t["1001"]["estoque_cx"] == 520 and t["1001"]["qualificado"] == 500 and t["1001"]["situacao"] == "Qualificado")
T("CDD: produto fora da grade = sem estoque", t["1021"]["qualificado"] == 0 and t["1021"]["motivo"] == "Sem estoque")

# --- CD Shibata real ("CD SHIBATA - MOGI DA", EG 949698) é VD; lojas do DeParaCDD são CD; Qtd. atualizada vazia
r = rodar([base(eg="949698", nome="CD SHIBATA - MOGI DA", ped="P1"), base(eg="161349", nome="SHIBATA H1 - ITAGUA", ped="P2"),
           base(eg="866679", nome="SK SUPERMERCADOS LTDA", ped="P3")],
          sheet3=[("949698", "SHIBATA"), ("161349", "SHIBATA"), ("866679", "SK")],
          de_para=[("161349", "CDD Suzano"), ("866679", "CDD Guarulhos")])
t = {x["eg"]: (x["tipo"], x["tipo_origem"]) for x in r["linhas"]}
T("CD SHIBATA - MOGI DA = VD/Fábrica; loja do Shibata e SK no DeParaCDD = CD/CDD",
  t["949698"] == ("VD", "Fábrica") and t["161349"] == ("CD", "CDD") and t["866679"] == ("CD", "CDD"))
b = base(eg="1055810", ped="P9", sku="1001", nome="CD BARBOSA", cx=546); put(b, "AQ", None)
x = uma(rodar([b], sheet3=[("1055810", "BARBOSA")]))
T("Qtd. atualizada vazia: pendente usa a quantidade original e é auditado", x["pendente"] == 546 and x["tipo"] == "VD")

# --- fracionado (< 1 PLT): VD não entrega; CD entrega
r = rodar([base(eg="1", nome="CD BARBOSA", ped="P1", cx=50), base(eg="2", nome="SHIBATA LJ 01", ped="P2", cx=50)],
          estoque=[("BR01", "1001", 9999)], sheet3=[("1", "BARBOSA"), ("2", "SHIBATA")], de_para=[("2", "CDD X")],
          cdd={"X": [("100", "d", 9999)]})
t = {x["eg"]: x for x in r["linhas"]}
T("fracionado em VD: fica no pendente, sem qualificado e fora do fill",
  t["1"]["frac_vd"] and t["1"]["pendente"] == 50 and t["1"]["qualificado"] == 0 and t["1"]["motivo"] == "Fracionado: VD não entrega"
  and t["1"]["ent_f"] == 0)
T("fracionado em CD: entrega e qualifica normalmente", (not t["2"]["frac_vd"]) and t["2"]["fracionado"] and t["2"]["qualificado"] == 50 and t["2"]["ent_f"] == 50)

print(f"\n{ok} testes OK")
