# -*- coding: utf-8 -*-
"""Renderiza o painel para PNG com seleções diferentes (verificação visual).
Uso: python3 render_demo.py ARQ.xlsx PASTA_SAIDA"""
import os, subprocess, sys, openpyxl

SELECOES = {
    "shibata": dict(rede="SHIBATA", tipo="Todos", loja="SHIBATA", sku=None, ped=None),
    "nagumo_cd": dict(rede="NAGUMO", tipo="CD", loja="NAGUMO", sku=1, ped=3),
    "todos": dict(rede="TODAS", tipo="Todos", loja="SONDA", sku=0, ped=0),
}
ABAS_TXT = {"Painel_Gerencial": "Carteira Reversa", "Por_Rede": "Gerencial por rede", "Por_SKU": "Visão por SKU",
            "Lojas_VD": "Lojas VD por rede", "Pedido_Linhas": "Linha a linha do pedido"}


def run(arq, pasta, nomes=None):
    os.makedirs(pasta, exist_ok=True)
    saidas = []
    for nome, sel in SELECOES.items():
        if nomes and nome not in nomes:
            continue
        wb = openpyxl.load_workbook(arq)
        wb["Painel_Gerencial"]["C5"] = sel["rede"]; wb["Painel_Gerencial"]["G5"] = sel["tipo"]
        wb["Por_SKU"]["C5"] = sel["rede"]; wb["Por_SKU"]["G5"] = sel["tipo"]
        wb["Lojas_VD"]["C5"] = sel["loja"]
        lst = wb["Listas"]
        if sel["sku"] is not None:
            skus = [c.value for c in lst["D"] if c.value]
            for r in range(1, wb["Por_SKU"].max_row + 1):
                if wb["Por_SKU"].cell(r, 2).value == "SKU ▾":
                    wb["Por_SKU"].cell(r, 3).value = skus[sel["sku"]]
        if sel["ped"] is not None:
            peds = [c.value for c in lst["E"] if c.value]
            wb["Pedido_Linhas"]["C5"] = peds[sel["ped"]]
        f = os.path.join(pasta, f"{nome}.xlsx")
        wb.save(f)
        subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", pasta, f],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=240)
        pdf = os.path.join(pasta, f"{nome}.pdf")
        n = int([l for l in subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout.splitlines() if l.startswith("Pages")][0].split()[1])
        achou = {}
        for p in range(1, n + 1):
            t = subprocess.run(["pdftotext", "-f", str(p), "-l", str(p), pdf, "-"], capture_output=True, text=True).stdout
            for aba, marca in ABAS_TXT.items():
                if marca in t and aba not in achou:
                    achou[aba] = p
        for aba, p in achou.items():
            prefixo = os.path.join(pasta, f"{nome}_{aba}")
            subprocess.run(["pdftoppm", "-r", "70", "-png", "-f", str(p), "-l", str(p), pdf, prefixo],
                           stderr=subprocess.DEVNULL)
            saidas.append(prefixo)
    return saidas


if __name__ == "__main__":
    print(run(sys.argv[1], sys.argv[2]))
