# Layout do Excel (v4)

Pergunta que o painel responde em 30 segundos: **"Para esta rede, quanto já entregamos, o que está marcado, o que falta e o que dá para atender hoje?"**

Use `scripts/modelo_painel.py` (função `montar_excel`). Grade oculta, Calibri, azul-escuro `1F3A5F`, verde-água `00897B`. Listas suspensas em células amarelas; tudo abaixo é fórmula sobre as abas ocultas `Base_*`.

## Abas visíveis
- Painel_Gerencial: o gráfico da esquerda é **por SKU da seleção** (até 12 maiores por entrada) e o da direita por cliente; nenhum gráfico do Painel mostra outras redes, para o painel poder ser enviado ao cliente. A aba Por_Rede é gerencial interna (todas as redes).
2. **Por_Rede** — tabela por rede (clientes, pedidos, volumes, qualificado, produção, descoberto, sem estoque, não fecha carro, 4 indicadores de fill, lojas VD, lojas atendidas, Fill Rate VD, vales) e por rede × tipo; dois gráficos: todas as redes (Real, + Programado, + Estoque hoje, + Produção) e composição do pendente (Qualificado, Produção, Descoberto).
3. **Por_SKU** — listas de rede e tipo; ranking dos 30 maiores SKUs por pendente com qualificado, produção, descoberto e contagem de linhas sem estoque, não fecha carro, crítico e sem produção; gráfico dos 12 maiores; lista de SKU: escolher o SKU mostra cada cliente/pedido que o pede.
4. **Lojas_VD** — lista de rede (uma por vez); cartões Lojas, Atendidas e Fill Rate VD; vales da rede; tabela de lojas com Entrada/Entregue/Pendente PLT e sinais ▲ ✓ ○; gráfico com TODAS as lojas (até 40) empilhando Real, + Programado, + Estoque hoje e + Produção (% da entrada).
5. **Por_Pedido** — todos os pedidos com filtros, fills e alertas.
6. **Pedido_Linhas** — lista de pedido; mostra cada SKU com entrada, entregue, programado, pendente, qualificado, produção, não atendido, origem, situação, motivo e alertas.
7. **Qualificado** — uma linha por chave com todas as colunas da especificação (grupo, tipo, origem, datas, CX por PLT, pendente, estoque, crítico, fecha carro, volume do cliente na origem, nº de origens válidas, qualificado, produção, descoberto, situação, motivo, alertas); filtros e congelamento.
8. **Como_Funciona** — passo a passo em linguagem simples.

## Abas ocultas
`Base_Linha`, `Base_Pedido`, `Base_Cliente`, `Base_Rede`, `Base_SKU`, `Base_Loja`, `Calc_Painel`, `Listas`, `Fora_Carteira`, `Auditoria`, `Conferencias`.

## Anti-"encavalado" (obrigatório)
- Área reservada por bloco; gráficos ancorados em células fixas com a próxima seção começando só depois deles (Painel: gráficos em B26/H26, detalhe na linha 50; Por_SKU: gráfico na linha 41, lista de SKU na linha 65).
- Dados de gráfico só em abas ocultas (`Calc_Painel`) ou na própria tabela visível (Por_Rede).
- Rótulo de gráfico: nome completo do cliente; fonte 8; máximo 12 e 15 barras.
- Percentual `0.0%`, PLT `#,##0.0`, CX `#,##0`. Nunca aplicar % em coluna de volume. Planilha abre com `fullCalcOnLoad`.

## Verificação visual obrigatória
1. `python3 scripts/render_demo.py Carteira_Reversa.xlsx PASTA` (LibreOffice → PDF → PNG) com 3 seleções: rede com CD e lojas (SHIBATA), só CD (NAGUMO, tipo CD) e TODAS.
2. Olhar cada gráfico: nomes legíveis, nada sobreposto, valores batendo com as tabelas.
3. Conferir: painel (TODAS/Todos) = soma de Por_Rede = Por_Pedido (diferença 0).
4. Corrigir o que estiver feio antes de entregar.


## Atualização v4.6
- Painel: cards de Entrada/Entregue/Marcado/Pendente/Qualificado estoque/Produção; % Entregue, Fill Real, Fill c/ estoque, Fill c/ produção, Qualificado total, Não atendido. Gráfico por SKU (nunca mostra outras redes) e bloco 'Qualificado por origem'.
- Por_Pedido: uma linha-resumo por pedido (com captação ou criação); SKUs recolhidos (agrupamento).
- Qualificado: fill por linha SKU/cliente, coluna Fracionado e resumo do filtro nas linhas 1–3 (SUBTOTAL).
