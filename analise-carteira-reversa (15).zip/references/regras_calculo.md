# Regras de cálculo, colunas e premissas (v4)

## 1. Abas (localizadas pelo NOME, espaços e maiúsculas normalizados)
Base Crua · Marcado · Malha · CAD · Estoque Fabricas · Produção · DeParaCDD · Estoque CDD <cidade> · Planificador_Pallet · Planificador_Chapatex · Sheet3.
Obrigatórias: Base Crua e CAD. As demais ausentes viram "Aba não localizada" na auditoria. Nunca usar "primeira/segunda aba". Não aproximar nomes por semelhança parcial (a aba do CDD só é aceita se for exatamente "Estoque CDD " + nome do CDD no DeParaCDD).

## 2. Colunas fixas (letras)
| Aba | Colunas |
|---|---|
| Base Crua | B Pedido ERP · G Comercial · M Cliente EG · N Cliente SAP · O Nome da loja · Q SKU EG · R SKU SAP · S Descrição · U HL · V PLT · W CX original · Y Criação · Z Vencimento · AQ Qtd atualizada · AT Carro sem remessa · AU Carro com remessa · AV Faturado · BA Data de captação |
| Marcado | D Cliente EG · E Cliente SAP · F Nome · G SKU EG · H SKU SAP · I Nome do SKU · J, K, L quantidade marcada (L usada como CX) · AH Speed DRP · data da agenda (data de entrega) |
| CAD | A S4 · C EG · I CX por PLT |
| Planificadores | nome da rede + AH Vales Ativos |

Por cabeçalho (o script procura pelo nome; se não achar, avisa): Marcado → Pedido ERP, Data Agenda, Data Faturamento. Malha → SKU SAP, Destino Comercial, Origem, Nome da fábrica. Estoque Fabricas → Origem (BR), **Sku PCA (= SKU EG)**, **D1** (CX, já líquido do marcado). Produção → Origem, SKU S4, Data de produção, Situação. DeParaCDD → Cliente EG, CDD. Estoque CDD → Código do Produto, SaldoDisponivel. Sheet3 → Cliente EG, Rede. **Se o cabeçalho real for diferente, o script avisa e o agente deve perguntar ao usuário a coluna certa.**

## 2b. De-para de origens
Nome origem · BR Origem · Código centro · Tipo Origem (VD = fábrica, CD = CDD) · Lista (ex. 260-VD). A Malha pode trazer nome ou código BR; o script resolve para o BR. BRDF e BR09 aparecem em VD e CD: fábrica usa a linha VD. Origem CD na malha não vale para fábrica (auditoria). Origem que não está no de-para mas parece BR (BR + 2 ou 3 caracteres) é mantida e registrada. O bloco "TRAVA COMERCIAL" da tabela é ignorado. Para trocar a tabela, enviar uma aba `DeParaOrigem` com esses cabeçalhos.

## 3. Fluxo
1. Ler Base Crua como texto nos códigos. Chave EG + Pedido + SKU. Escolher a linha de menor criação (empate: menor vencimento). Demais → auditoria "Linhas duplicadas descartadas".
2. Captação final = captação (BA) se válida; senão a menor data de criação da chave. Gravar "Fonte da data de captação": "Captação original" ou "Substituída pela primeira data de criação".
3. Datas inválidas: vazio, 01/01/0001, 01/01/1970, 30/12/1899 e textos. Nunca viram data válida.
4. Pendente CX = MÁX(0; AQ − AT − AU − AV). PLT = CX ÷ fator CAD. Entrada PLT = coluna V (original), conferida contra W ÷ fator (divergência > 0,5 PLT vai para a auditoria).
5. Marcado: classes (para cálculo/auditoria) = faturado · agenda passada · futuro · agenda do dia · sem data. A soma das classes tem de fechar com o total marcado. Entregue por marcação = faturado + agenda passada (no VD do Shibata só faturado; a agenda passada fica como programado).
6. Entregue = MÍN(Entrada; MÁX(Faturado AV; Marcado entregue)).
7. Programado (a entregar) = MÍN(AT + AU + extra; Entrada − Entregue), onde extra = MÁX(0; marcado a entregar − (AT + AU)). Assim o mesmo volume não é contado duas vezes.
8. (Falta marcar é interno, só limita as coberturas; não é exibido. Pendente = MÁX(0; AQ − AT − AU − AV).)
9. Grupo (rede) = coluna **L (Nome Rede)** da Base Crua (coluna O = nome da loja); sem ela, Sheet3 (EG → rede); sem ela, inferido do nome e listado na auditoria "Rede inferida pelo nome". Tipo e origem: tabela de clientes (`--clientes`; padrão CD Shibata, Barbosa, Lopes, Nagumo, Sonda e Rhodia = VD/fábrica; Shibata = CD/CDD; loja exata > rede); fora da tabela, "CD" no nome = CD e o resto VD.
10. Tipo de origem: Fábrica para Sonda, Lopes, Nagumo, Barbosa e CD Shibata; CDD para as lojas do Shibata; demais: CDD se estiver no DeParaCDD, senão Fábrica.
11. Origem (fábrica): origem(ns) da Malha; mais de uma → entre as origens COM estoque do SKU, a cujo volume do cliente já está mais próximo de 24 PLT (sem estoque em nenhuma: só a proximidade).
12. Volume do cliente na origem = soma do pendente PLT da EG na origem. Fecha carro: ≥ 24 Sim · ≥ 22 e < 24 Sim* (exceção) · < 22 Não (qualifica mesmo assim e leva o alerta "Abaixo do mínimo na origem"). Máximo 28 PLT por carro (informativo: carros estimados).
13. Qualificado: ver SKILL.md. Consumo por Cliente EG + origem + SKU (CDD: + CDD), ordenado por vencimento. Sem rateio entre clientes (flag "Estoque disputado").
14. Produção (qualquer quantidade) cobre o saldo = MÁX(0; Pendente − Qualificado) quando existe linha ativa, mesma origem e S4, com data entre a data de referência e o vencimento. Descoberto = Pendente − Qualificado − Cobertura.
15. Coberturas para os fills: cob_estoque = MÍN(Qualificado; Falta marcar); cob_produção = MÍN(Cobertura; Falta marcar − cob_estoque).
16. Motivo principal (um por linha): Erro crítico de CAD › Sem malha › Sem origem válida › Sem DeParaCDD › Aba de CDD não localizada › Sem estoque › Não fecha carro › Estoque insuficiente. Alertas adicionais: Estoque crítico, Sem produção válida, Estoque disputado, Carro de exceção (22-23 PLT)*, Risco de validade (D+2), Vencido, Divergência PLT × CAD.

## 4. Diferenças em relação à versão anterior
- A linha de referência da chave passou a ser a de **menor data de criação** (antes: menor diferença entre entrada e vencimento).
- A captação deixou de ser a base da "Data de Entrada": é só informação (BA), com fonte rastreada.
- Novo: malha, origem, estoque de fábrica/CDD, carro 24-28, qualificado, produção, descoberto, vales, CD/VD e Fill Rate VD por lojas.
- Grupo/Tipo: só CD e VD (some "Loja a Loja" e "Direto").
- O painel principal passou a ser por **rede**; visões novas por SKU, lojas e pedido.

## 5. Premissas a confirmar com o usuário quando a base não deixar claro
- Cabeçalhos de Marcado (pedido, agenda, faturamento) e das abas de estoque, malha e produção.
- Se J, K, L da Marcado são HL, PLT e CX (o script usa a L como caixas).
- Produção: só conta data ≥ data de referência (o que já foi produzido está no D1).
- "Programado" não está limitado pelo Pendente porque o Pendente já desconta o marcado; a fórmula original MÍN(A entregar; Pendente; ...) foi trocada por MÍN(A entregar; Entrada − Entregue).

16. Fracionado: Entrada PLT < 1 (conversão CAD). Em cliente VD fica fora do qualificado e do fill (entrada/entregue/programado do fill = 0); em CD segue normal.
17. Não atendido = Pendente − qualificado estoque − cobertura produção. Origem do qualificado: fábrica (malha) ou CDD.
