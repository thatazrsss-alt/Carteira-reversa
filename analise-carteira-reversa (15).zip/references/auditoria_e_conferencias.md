# Auditorias e conferências finais (v4)

## Auditorias (aba oculta `Auditoria`, uma linha por ocorrência)
Marcações fora da carteira · Linhas duplicadas descartadas · Data de criação ausente ou inválida · Captação substituída pela data de criação · SKU não localizado na CAD · Fator CX/PLT inválido · Unidade diferente de CX · Divergência entre PLT informado e fator CAD · Sem malha / origem inválida (no `Qualificado`) · Cliente sem DeParaCDD · Aba de CDD não localizada · Produto não localizado no estoque do CDD · Produto não localizado no estoque de fábrica · Produção sem correspondência · Produção descontinuada · Produção sem previsão · Produção após o vencimento · Cliente abaixo de 24 PLT na origem (com nº de origens do cliente) · Estoque crítico de fábrica · Estoque crítico de CDD · Redes sem correspondência nos vales · Possível duplicidade Base Crua × carros · Rede inferida pelo nome (conferir) · Aba não localizada.
A aba `Auditoria` também lista o status de cada aba e os avisos de colunas não identificadas.

## Conferências (aba oculta `Conferencias`, resultado OK/ALERTA)
- Uma linha por chave.
- Entregue ≤ Entrada; Programado ≤ Entrada − Entregue; nenhum valor negativo.
- Qualificado + Produção + Descoberto = Pendente.
- Fill c/ produção ≤ 100% (e Fill Real ≤ Fill c/ estoque ≤ Fill c/ produção).
- Soma das classes do marcado = total marcado.
- Qualificado por cliente/origem/SKU ≤ estoque disponível.
- Nenhuma origem "nan" válida; nenhum pendente zerado por falta de qualificação.
- Fábrica só qualifica quando o cliente fecha carro na origem; CDD sem regra de 24 PLT.
- Produção só até o vencimento; marcações fora da carteira fora dos totais; todo SKU na CAD ou destacado.

## Conferências manuais antes de entregar
- Painel TODAS/Todos = Por_Rede (total) = Por_Pedido (diferença 0).
- Percentuais recalculados dos totais.
- Números em texto sem separador de milhar; Excel numérico com formato pt-BR.
- Painel renderizado com 3 seleções.

- Pendente difere de Entrada − Entregue − Programado (lista as linhas).
- Fracionado em cliente VD (fora do qualificado e do fill).
- Qtd. atualizada vazia (usada a Qtd. original).
