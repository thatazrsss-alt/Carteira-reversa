---
name: analise-carteira-reversa
description: Analisa a Carteira Reversa a partir de uma pasta de bases (Base Crua, Marcado, Malha, CAD, Estoque Fabricas, Produção, DeParaCDD, Estoque CDD, Planificadores, Sheet3) localizadas pelo nome da aba. Calcula por Cliente EG + Pedido ERP + SKU EG a entrada, entregue, marcado/programado, pendente, qualificado (estoque, total e por origem) (fábrica com carro de 24 a 28 PLT; CDD pelo saldo), cobertura por produção e não atendido (provável), com % Entregue, Fill Real (entregue + marcado), Fill c/ estoque hoje e Fill c/ produção. Gera Excel visual e dinâmico com listas suspensas por rede, tipo CD/VD, SKU, loja e pedido, vales de palete e chapatex e auditoria. Use quando o usuário pedir carteira reversa, fill rate, pendente, qualificado, marcado, risco de validade ou análise por rede, SKU, loja ou pedido.
---

# Análise de Carteira Reversa (v4)

## Quando usar
O usuário envia as bases da carteira (um ou mais arquivos Excel) e quer saber, por rede, SKU, loja e pedido: quanto entrou, quanto foi entregue, quanto está marcado, quanto está pendente, o que dá para atender hoje com o estoque e o que falta. Se faltar a Base Crua ou a CAD, pedir antes de calcular. As demais abas ausentes são registradas como "Aba não localizada" e a análise segue.

## Como executar
1. Rodar o script (ele lê as abas **pelo nome**, nunca pela posição):
   `python3 scripts/gerar_analise.py ARQ1.xlsx [ARQ2.xlsx ...] --saida Carteira_Reversa.xlsx --data dd/mm/aaaa [--clientes "BARBOSA=VD;SHIBATA=CD;..."]` (a tabela Cliente/Tipo vem do descritivo; sem ela vale a padrão)
   Sem `--data`, usa a data de hoje e declara no painel. `--rede SHIBATA` define a rede que abre selecionada.
2. Ler o resumo impresso, `avisos` e a aba oculta `Conferencias`. Qualquer "ALERTA" deve ser corrigido ou explicado.
3. **Renderizar e conferir o visual** (`scripts/render_demo.py`) com 3 seleções (rede com CD e lojas, só CD, TODAS) e ver `references/layout_excel.md`.
4. Entregar o Excel e responder (ver "Resposta").

Dependências: Python 3, `openpyxl`. As regras estão em `scripts/calculo.py`; o Excel em `scripts/modelo_painel.py`. Não redesenhar o layout do zero: ajustar cores, títulos e limites mantendo a estrutura. `python3 -I scripts/test_calculo.py` roda 37 testes das regras.

## Regras inegociáveis
1. A **Base Crua define a carteira ativa**. Chave = Cliente EG (M) + Pedido ERP (B) + SKU EG (Q), lida como texto. Uma linha por chave: a de **menor data de criação** (Y); empate, menor vencimento (Z). Não somar versões. Data de criação ausente = "Erro de integridade" (não inventar data).
2. **Pendente** = MÁX(0; Qtd. atualizada (AQ) − carro sem remessa (AT) − carro com remessa (AU) − faturado (AV)), em caixas. Já desconta o marcado, mesmo o ainda "a entregar". **Nunca** é zerado por estoque, produção, carro, criticidade ou falta de malha.
3. **Entrada** vem da linha escolhida: HL (U), PLT (V), CX (W). Cancelamento não é considerado.
4. **CAD** (A = S4, C = EG, I = CX por PLT) é a única fonte de S4 e de conversão PLT = CX ÷ fator. SKU fora da CAD = **erro crítico**: manter CX, não inventar S4 nem fator, não converter, não cruzar estoque.
5. **Marcado** (aba Marcado): chave igual à da carteira; o que não casa vai para `Fora_Carteira` e não entra em nenhum total. Faturado ou agenda passada = entregue (exceto **VD do Shibata: entregue = só faturado**). Futuro, do dia e sem data = a entregar. Não contar duas vezes o que já está em AT/AU.
6. **Fábrica** (clientes VD da tabela de clientes: padrão Sonda, Lopes, Nagumo, Barbosa, Rhodia e **CD Shibata**) usa Malha + Estoque Fabricas (D1). **CDD** (clientes CD da tabela e clientes do DeParaCDD) usam a grade do CDD indicado no DeParaCDD (aba Estoque CDD; código = EG sem o último dígito; SaldoDisponivel). Os demais: DeParaCDD se houver, senão fábrica pela malha.
7. **Malha** = SKU SAP (R) + Comercial (G). A origem pode vir como nome, lista (260-VD), centro (260) ou código BR: tudo é convertido para o **código BR** pelo de-para de origens (`ORIGENS_PADRAO` em `calculo.py`, ou aba `DeParaOrigem`; o bloco TRAVA COMERCIAL é ignorado). **Fábrica usa só origens VD** (BRDF e BR09 repetem em CD: a linha VD vale para fábrica; origem CD na malha é ignorada para fábrica). O Estoque Fabricas usa o código BR + **Sku PCA (= SKU EG)**, coluna **D1 em CX, já líquida** do que foi marcado. Origem vazia, "nan" ou inconsistente = "Sem origem válida"; sem correspondência = "Sem malha". Origem inválida nunca cruza estoque nem produção. Com mais de uma origem, alocar na origem **com estoque** do SKU mais próxima de fechar 24 PLT.
8. **Carro (fábrica)**: por **Cliente EG + origem** (não por rede): mínimo 24 e máximo 28 PLT; **22 ou 23 PLT são exceção, qualificam e levam asterisco (*)**. Somar o pendente da EG na origem, checar o mínimo e só depois aplicar o estoque por SKU. Se não fecha: **qualifica a quantidade em estoque e sinaliza "Abaixo do mínimo na origem"** (motivo "Não fecha carro"). Origens não se somam. CDD não tem mínimo de 24 PLT.
9. **Qualificado hoje**: fábrica = MÍN(pendente; estoque D1), mesmo abaixo do mínimo (sinalizado); CDD = MÍN(pendente; saldo). Pedidos do mesmo cliente e SKU consomem o estoque pelo vencimento mais próximo, sem reuso. **Entre clientes não há rateio**: se dois disputam o SKU, os dois têm pendente; o painel só marca "Estoque disputado" / crítico.
10. **Criticidade não desqualifica**: fábrica < 50 PLT por origem + SKU; CDD quando saldo < pendente × 20.
11. **Produção**: não importa a quantidade. Se existe produção ativa, na mesma origem e S4, com data entre a data de referência e o vencimento (Z), ela cobre o saldo após o estoque. Qualificado + Produção + Descoberto = Pendente.
12. **Risco de validade (D+2)**: há volume sem marcação e o pedido vence em até 2 dias (ou já venceu).
13. **Rede** = coluna **L (Nome Rede)** da Base Crua (nome da rede, não código); a coluna **O** traz o nome das lojas da rede. Sem L, Sheet3 e depois o nome da loja. **Vales** = Planificador_Pallet / Planificador_Chapatex: rede e **Vales Ativos** localizados pelo nome do cabeçalho (rede também na coluna D e vales na AH quando o layout é o padrão). **CD × VD e origem:** vêm da tabela de clientes (`--clientes`, do descritivo): VD = origem na fábrica, CD = origem no CDD; a loja exata vale mais que a rede. Fora da tabela: CDD se estiver no DeParaCDD, senão fábrica; "CD" no nome = CD. Só existem CD e VD. Dúvidas vão para a auditoria. Só existem CD e VD.
14. **Pendente de palete e chapatex (vales ativos)**: Planificadores, coluna AH, **só por rede**. Aparecem no topo do painel, em Por_Rede e em Lojas_VD; nunca somam à carteira, ao estoque nem ao fill.
15. % Entregue = Entregue ÷ Entrada. **Fill Real = (Entregue + Marcado) ÷ Entrada.** Fill c/ estoque hoje = Fill Real + o que o estoque de hoje qualifica. Fill c/ produção = + o que a produção válida cobre (máx. 100%). Sempre recalculado dos totais, nunca média de percentuais.

## Indicadores
Entregue = MÍN(Entrada; MÁX(Faturado; Marcado entregue)). Programado = AT + AU + marcado a entregar ainda fora de AT/AU, limitado a Entrada − Entregue. Pendente = Entrada − Entregue − Programado (inclui o desqualificado; não existe 'falta marcar' separado). Fracionado = Entrada < 1 PLT na CAD: VD não entrega (fica no pendente, fora do qualificado e do fill); CD entrega. Não atendido = Pendente − Qualificado estoque − Cobertura por produção. % Entregue = Entregue ÷ Entrada · **Fill Real = (Entregue + Marcado) ÷ Entrada** · **Fill c/ estoque hoje** soma o qualificado · **Fill c/ produção** soma também a produção. Sinais por loja: ▲ entregou e pendente > 2 PLT (possível 2ª entrega) · ✓ entregou e pendente ≤ 2 PLT · ○ sem entrega. Nunca misturar redes na visão de lojas.

## Formato brasileiro
No Excel, células numéricas (nunca texto) com formato pt-BR: PLT 1 casa, % 1 casa, contagens sem casa, CX com unidade, datas dd/mm/aaaa. **No chat e em textos: vírgula decimal e sem separador de milhar** (14,2 PLT; 1945 paletes; 132202 CX; 42,9%).

## Estrutura do arquivo
- **Visíveis**: `Painel_Gerencial` (listas de rede e tipo, vales, cartões, resumo CD/VD, 2 gráficos, detalhe por pedido) · `Por_Rede` (gerencial por rede, com Fill Rate VD, pendente de palete/chapatex e gráfico de todas as redes) · `Por_SKU` (listas de rede e tipo, ranking de SKUs, gráfico e lista de quem pede o SKU escolhido) · `Lojas_VD` (lista de rede, Fill Rate VD, ▲ ✓ ○, gráfico com todas as lojas: Real, Programado, Estoque hoje e Produção) · `Por_Pedido` · `Pedido_Linhas` (lista de pedido, linha a linha) · `Qualificado` (todas as colunas, com filtros) · `Como_Funciona`.
- **Ocultas** (podem ser reexibidas): `Base_Linha`, `Base_Pedido`, `Base_Cliente`, `Base_Rede`, `Base_SKU`, `Base_Loja`, `Calc_Painel`, `Listas`, `Fora_Carteira`, `Auditoria`, `Conferencias`. Dado de gráfico fica só em abas ocultas.

## Referências
- `references/regras_calculo.md`: fórmulas, colunas de cada aba, premissas e diferenças em relação à versão anterior.
- `references/layout_excel.md`: layout das abas, regras anti-sobreposição e verificação visual obrigatória.
- `references/auditoria_e_conferencias.md`: lista de auditorias e conferências finais.

## Resposta
5 a 8 linhas: números-chave (formato de chat), 3 maiores riscos (ex.: descoberto, não fecha carro, risco de validade), redes/clientes com classificação duvidosa e ações. Citar premissas aplicadas e avisos do script. Informar que as abas de apoio estão ocultas.
